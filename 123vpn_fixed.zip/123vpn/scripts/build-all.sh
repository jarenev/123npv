#!/usr/bin/env bash
# Полная сборка APK «123 VPN» локально:
#   1. бинарники ядер (xray + sing-box) → jniLibs
#   2. Rust-библиотека libvpn123.so → jniLibs
#   3. Gradle assembleRelease
#
# Требования: JDK 17, Android SDK (+NDK), Rust ≥ 1.90, сеть.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "── 1/3: бинарники ядер ──"
bash scripts/fetch-binaries.sh

echo "── 2/3: Rust (libvpn123.so) ──"
bash scripts/build-rust.sh

echo "── 3/3: Gradle ──"
if [ -x "$ROOT/gradlew" ]; then
  "$ROOT/gradlew" assembleRelease
elif command -v gradle >/dev/null; then
  # создаём wrapper, чтобы дальше пользоваться ./gradlew
  gradle wrapper --gradle-version 8.11.1
  ./gradlew assembleRelease
else
  cat <<'EOF'
✗ Gradle не найден. Варианты:
  • Откройте проект в Android Studio → Build → Generate/Assemble
  • Или установите Gradle 8.11.1+ (https://gradle.org/install/) и повторите
EOF
  exit 1
fi

APK="$ROOT/app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK" ]; then
  echo
  echo "✓ APK готов: $APK"
  echo "  Установка: adb install -r \"$APK\""
else
  echo "✓ Сборка прошла, ищите APK в app/build/outputs/apk/"
fi
