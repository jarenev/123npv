#!/usr/bin/env python3
"""Генерирует app/src/main/assets/ui/world.json — точки суши для планеты.
Источник: публичный countries.geo.json (https://github.com/johan/world.geo.json, PD).
Точки — равномерная спираль Фибоначчи по сфере, оставляем только сушу
(точка в полигоне, лучевой тест в координатах lon/lat).
"""
import json
import math
import os
import sys

GEO = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(__file__), '..', 'scripts', 'research', 'world.geo.json')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
    os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'ui', 'world.json')

N_POINTS = 9000          # точек на сфере до фильтрации (останется ~2600 суши)
TARGET_DOTS = 2400

def load_polygons(path):
    data = json.load(open(path, encoding='utf-8'))
    polys = []
    for f in data['features']:
        g = f['geometry']
        if g['type'] == 'Polygon':
            polys.append(g['coordinates'][0])
        elif g['type'] == 'MultiPolygon':
            for p in g['coordinates']:
                polys.append(p[0])
    return polys

def bbox(poly):
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    return min(xs), min(ys), max(xs), max(ys)

POLYS = load_polygons(GEO)
BBOXES = [bbox(p) for p in POLYS]

def point_in_ring(x, y, ring):
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > y) != (yj > y):
            x_int = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < x_int:
                inside = not inside
        j = i
    return inside

def on_land(lon, lat):
    for poly, (x0, y0, x1, y1) in zip(POLYS, BBOXES):
        if lon < x0 or lon > x1 or lat < y0 or lat > y1:
            continue
        if point_in_ring(lon, lat, poly):
            return True
    return False

# спираль Фибоначчи: равномерно по сфере
pts = []
golden = math.pi * (3 - math.sqrt(5))
for i in range(N_POINTS):
    y = 1 - (i / (N_POINTS - 1)) * 2          # 1..-1
    radius = math.sqrt(max(0.0, 1 - y * y))
    theta = golden * i
    x = math.cos(theta) * radius
    z = math.sin(theta) * radius
    lat = math.degrees(math.asin(max(-1, min(1, y))))
    lon = math.degrees(math.atan2(z, x))
    pts.append((lon, lat))

land = [(round(lon, 1), round(lat, 1)) for lon, lat in pts if on_land(lon, lat)]
print(f"полигонов: {len(POLYS)}, точек сферы: {N_POINTS}, суши: {len(land)}")

# прореживание до TARGET_DOTS
step = max(1, len(land) // TARGET_DOTS)
land = land[::step]
os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump({'dots': [[l, b] for l, b in land]}, open(OUT, 'w'), separators=(',', ':'))
print(f"итог: {len(land)} точек → {OUT} ({os.path.getsize(OUT)} байт)")
