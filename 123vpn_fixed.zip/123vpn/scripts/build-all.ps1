﻿# Полная сборка APK «123 VPN» на Windows — БЕЗ Android Studio, БЕЗ winget, БЕЗ прав администратора.
#   1. бинарники ядер (xray + sing-box) → jniLibs        [если их ещё нет]
#   2. Rust libvpn123.so                                  [prebuilt в комплекте; пересборка после правок rust/]
#   3. JDK 17 и Android SDK                               [скачивает сама, если не установлены]
#   4. gradlew assembleRelease                            [Gradle скачает wrapper, ставить не надо]
#
# Gradle-wrapper в комплекте (gradlew.bat), поэтому отдельная установка Gradle НЕ нужна.
# Использование:  powershell -ExecutionPolicy Bypass -File scripts\build-all.ps1
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # ускоряет Expand-Archive на большом объёме

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $Root
$Tools = Join-Path $env:LOCALAPPDATA "vpn123-tools"

# ─────────────────────────────────────────────────────────────────────────────
function Get-File($Url, $Out) {
  Write-Host "↓ $Url"
  & curl.exe -fSL --retry 3 -o $Out $Url
  if ($LASTEXITCODE -ne 0) { throw "Не удалось скачать $Url" }
}

function Expand-Zip($Zip, $Dest) {
  New-Item -ItemType Directory -Path $Dest -Force | Out-Null
  Expand-Archive -Path $Zip -DestinationPath $Dest -Force
}

# ─────────────────────────────────────────────────────────────────────────────
# 1/4: бинарники ядер
# ─────────────────────────────────────────────────────────────────────────────
Write-Host "── 1/4: бинарники ядер (xray + sing-box) ──"
$NeedFetch = $false
foreach ($Abi in "arm64-v8a", "armeabi-v7a", "x86_64") {
  if (-not (Test-Path (Join-Path $Root "app\src\main\jniLibs\$Abi\libxray.so")) -or
      -not (Test-Path (Join-Path $Root "app\src\main\jniLibs\$Abi\libsingbox.so"))) { $NeedFetch = $true }
}
if ($NeedFetch) {
  & powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "fetch-binaries.ps1")
  if ($LASTEXITCODE -ne 0) { throw "fetch-binaries.ps1 завершился с ошибкой" }
} else {
  Write-Host "Ядра уже на месте — пропускаю"
}

# ─────────────────────────────────────────────────────────────────────────────
# 2/4: Rust (пересборка после правок rust/)
# ─────────────────────────────────────────────────────────────────────────────
Write-Host "── 2/4: Rust (libvpn123.so) ──"
$SoExisting = @(Get-ChildItem -Recurse (Join-Path $Root "app\src\main\jniLibs") -Filter "libvpn123.so" -ErrorAction SilentlyContinue)
if ($SoExisting.Count -ge 3) {
  Write-Host "libvpn123.so уже есть (prebuilt) — пропускаю. Пересобрать вручную: scripts\build-rust.ps1"
} else {
  & powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "build-rust.ps1")
  if ($LASTEXITCODE -ne 0) { throw "build-rust.ps1 завершился с ошибкой" }
}

# ─────────────────────────────────────────────────────────────────────────────
# 3/4: JDK 17 + Android SDK (автоустановка при отсутствии)
# ─────────────────────────────────────────────────────────────────────────────
Write-Host "── 3/4: JDK 17 и Android SDK ──"

# JDK 17: JAVA_HOME → Studio JBR → Adoptium → авто-скачивание ZIP в LOCALAPPDATA
if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\java.exe"))) {
  $JavaHome = $env:JAVA_HOME
} else {
  $JavaHome = $null
  foreach ($c in @(
    (Join-Path $env:ProgramFiles "Android\Android Studio\jbr"),
    (Get-ChildItem (Join-Path $env:ProgramFiles "Eclipse Adoptium") -Directory -ErrorAction SilentlyContinue |
      Where-Object Name -match "^jdk-17" | Sort-Object Name -Descending | Select-Object -First 1).FullName,
    (Get-ChildItem (Join-Path $env:ProgramFiles "Java") -Directory -ErrorAction SilentlyContinue |
      Where-Object Name -match "^jdk-17" | Sort-Object Name -Descending | Select-Object -First 1).FullName
  )) { if ($c -and (Test-Path (Join-Path $c "bin\java.exe"))) { $JavaHome = $c; break } }
}
if (-not $JavaHome) {
  $JavaHome = Join-Path $Tools "jdk-17"
  if (-not (Test-Path (Join-Path $JavaHome "bin\java.exe"))) {
    Write-Host "→ JDK 17 не найден, скачиваю Temurin 17 (ZIP, ~190 МБ)..."
    New-Item -ItemType Directory -Path $Tools -Force | Out-Null
    $Zip = Join-Path $Tools "jdk17.zip"
    Get-File "https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk" $Zip
    Expand-Zip $Zip $Tools
    $Unpacked = Get-ChildItem $Tools -Directory | Where-Object Name -like "jdk-17*" | Select-Object -First 1
    if ($Unpacked.FullName -ne $JavaHome) {
      if (Test-Path $JavaHome) { Remove-Item -Recurse -Force $JavaHome }
      Move-Item $Unpacked.FullName $JavaHome
    }
    Remove-Item -Force $Zip
  }
}
$env:JAVA_HOME = $JavaHome
$env:PATH = "$JavaHome\bin;$env:PATH"
Write-Host "→ JDK: $JavaHome"

# Android SDK: ANDROID_HOME → стандартная папка Studio → авто-установка cmdline-tools + пакеты
$Sdk = $null
foreach ($c in @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, (Join-Path $env:LOCALAPPDATA "Android\Sdk"))) {
  if ($c -and (Test-Path (Join-Path $c "platform-tools"))) { $Sdk = $c; break }
}
if (-not $Sdk) {
  $Sdk = Join-Path $env:LOCALAPPDATA "Android\Sdk"
  $CltBin = Join-Path $Sdk "cmdline-tools\latest\bin\sdkmanager.bat"
  if (-not (Test-Path $CltBin)) {
    Write-Host "→ Android SDK не найден, скачиваю cmdline-tools (~150 МБ)..."
    New-Item -ItemType Directory -Path (Join-Path $Sdk "cmdline-tools") -Force | Out-Null
    $Zip = Join-Path $env:TEMP "clt.zip"
    Get-File "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip" $Zip
    Expand-Zip $Zip (Join-Path $Sdk "cmdline-tools")
    Rename-Item (Join-Path $Sdk "cmdline-tools\cmdline-tools") "latest"
    Remove-Item -Force $Zip
  }
  Write-Host "→ sdkmanager: platform-tools + platforms;android-35 + build-tools;35.0.0 (лицензии — авто-согласие)..."
  $Yes = 1..100 | ForEach-Object { "y" }   # sdkmanager спрашивает y/n на каждую лицензию
  $Yes | & $CltBin --licenses --sdk_root=$Sdk | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "sdkmanager --licenses не удался" }
  & $CltBin --sdk_root=$Sdk "platform-tools" "platforms;android-35" "build-tools;35.0.0"
  if ($LASTEXITCODE -ne 0) { throw "sdkmanager: установка пакетов не удалась" }
}
$env:ANDROID_HOME = $Sdk
$env:ANDROID_SDK_ROOT = $Sdk
Write-Host "→ SDK: $Sdk"

# ─────────────────────────────────────────────────────────────────────────────
# 4/4: сборка APK через wrapper (Gradle скачается сам при первом запуске)
# ─────────────────────────────────────────────────────────────────────────────
Write-Host "── 4/4: Gradle assembleRelease ──"
if (Test-Path "$Root\gradlew.bat") {
  & "$Root\gradlew.bat" assembleRelease --no-daemon
  if ($LASTEXITCODE -ne 0) { throw "gradlew завершился с ошибкой" }
} else {
  throw "gradlew.bat не найден — скачайте актуальный ZIP проекта (в нём есть Gradle wrapper)"
}

$Apk = Join-Path $Root "app\build\outputs\apk\release\app-release.apk"
if (Test-Path $Apk) {
  Write-Host ""
  Write-Host "✓ APK готов: $Apk"
  Write-Host "  Установка: adb install -r `"$Apk`"  (или скопируйте файл на телефон и откройте)"
} else {
  throw "APK не появился — смотрите вывод Gradle выше"
}
