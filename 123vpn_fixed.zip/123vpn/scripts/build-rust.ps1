﻿# Сборка Rust-крейтов (vpn123-core + vpn123-bridge) под Android через cargo-ndk.
# Windows-версия scripts/build-rust.sh.
#
# Требования: Rust ≥ 1.90 (rustup-init.exe), Visual Studio Build Tools
# ("Разработка классических приложений C++"), Android NDK.
# Использование: powershell -ExecutionPolicy Bypass -File scripts\build-rust.ps1
$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

# Напоминание: в репозитории уже лежат собранные libvpn123.so.
$SoExisting = @(Get-ChildItem -Recurse (Join-Path $Root "app\src\main\jniLibs") -Filter "libvpn123.so" -ErrorAction SilentlyContinue)
if ($SoExisting.Count -ge 3) {
  Write-Host "INFO: в jniLibs уже есть готовые libvpn123.so ($($SoExisting.Count) из 3 ABI). Если Rust-код не менялся — прервите скрипт (Ctrl+C), этот шаг не нужен. Продолжаю принудительную пересборку..."
}

# 1. Цели Rust
if (-not (Get-Command rustup -ErrorAction SilentlyContinue)) {
  throw "rustup не найден. Установите Rust (https://rustup.rs или winget install Rustlang.Rustup) и откройте новую консоль"
}
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
if ($LASTEXITCODE -ne 0) {
  # Частая болячка rustup после прерванной загрузки: "detected conflict: ...rlib".
  # Снимаем конфликтующие компоненты и ставим заново.
  Write-Host "→ rustup не смог поставить цели (обычно конфликт остатков после прерванной загрузки). Переустанавливаю..."
  rustup component remove aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
  rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
  if ($LASTEXITCODE -ne 0) {
    throw ("rustup target add не удался дважды. Удалите остатки старых компонентов — вставьте в PowerShell и запустите скрипт снова:`n`n" +
      'Get-ChildItem "$env:USERPROFILE\.rustup\toolchains" | ForEach-Object { Remove-Item -Recurse -Force "$($_.FullName)\lib\rustlib\aarch64-linux-android","$($_.FullName)\lib\rustlib\armv7-linux-androideabi","$($_.FullName)\lib\rustlib\x86_64-linux-android" -ErrorAction SilentlyContinue }')
  }
}

# 2. cargo-ndk
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
  throw "cargo не найден. Установите Rust (https://rustup.rs) и откройте новую консоль"
}
# NB: детект через Get-Command, а не `cargo ndk --version 2>$null` —
# в PS 5.1 редирект stderr при Stop-режиме кидает NativeCommandError.
if (-not (Get-Command cargo-ndk -ErrorAction SilentlyContinue)) {
  Write-Host "→ cargo install cargo-ndk (один раз, ~2 минуты)"
  cargo install cargo-ndk --locked
  if ($LASTEXITCODE -ne 0) { throw "cargo install cargo-ndk не удался" }
}

# 3. Поиск NDK
if (-not $env:ANDROID_NDK_HOME) {
  $ndkRoots = @()
  if ($env:LOCALAPPDATA)     { $ndkRoots += Join-Path $env:LOCALAPPDATA "Android\Sdk\ndk" }
  if ($env:ANDROID_SDK_HOME) { $ndkRoots += Join-Path $env:ANDROID_SDK_HOME "ndk" }
  if ($env:USERPROFILE)      { $ndkRoots += Join-Path $env:USERPROFILE "AppData\Local\Android\Sdk\ndk" }
  $candidates = @($ndkRoots | Where-Object { Test-Path $_ })
  if ($candidates.Count -gt 0) {
    $env:ANDROID_NDK_HOME = (Get-ChildItem $candidates[0] | Sort-Object Name -Descending | Select-Object -First 1).FullName
  }
}
if (-not $env:ANDROID_NDK_HOME -or -not (Test-Path $env:ANDROID_NDK_HOME)) {
  throw "NDK не найден. Установите через Android Studio (SDK Manager → NDK (Side by side))`nи задайте: `$env:ANDROID_NDK_HOME = 'C:\путь\к\ndk\27.x'"
}
Write-Host "→ NDK: $env:ANDROID_NDK_HOME"

# 4. Сборка
Set-Location (Join-Path $Root "rust")
cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 --platform 26 -o "..\app\src\main\jniLibs" build --release
if ($LASTEXITCODE -ne 0) { throw "cargo ndk завершился с ошибкой" }

Write-Host ""
Write-Host "Готово:"
Get-ChildItem -Recurse (Join-Path $Root "app\src\main\jniLibs") -Filter "libvpn123.so" | ForEach-Object { Write-Host $_.FullName.Replace($Root, '') }
