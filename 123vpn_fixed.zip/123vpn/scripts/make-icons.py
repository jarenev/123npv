#!/usr/bin/env python3
"""Иконка «123 VPN»: глобус 🌍 (Европа/Африка) на чёрном фоне.
Рисуется программно из countries.geo.json (публичные данные, PD):
орфографическая проекция + обрезка по лимбу, градиентный океан,
блик, атмосферное свечение. Генерирует все densities + adaptive icon
+ белый ic_stat для уведомления.
"""
import json
import math
import os
import sys

from PIL import Image, ImageDraw, ImageFilter

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEO = sys.argv[1] if len(sys.argv) > 1 else os.path.join(BASE, '..', 'scripts', 'research', 'world.geo.json')
RES = os.path.join(BASE, 'app', 'src', 'main', 'res')

# центр обзора как у эмодзи 🌍: Европа сверху, Африка в центре
LAT0 = math.radians(22.0)
LON0 = math.radians(15.0)

OCEAN_LIGHT = (94, 178, 235)
OCEAN_MID = (47, 122, 214)
OCEAN_DEEP = (23, 76, 158)
LAND = (86, 184, 100)
LAND_DARK = (58, 148, 74)
ICE = (222, 238, 236)


def load_polys(path):
    data = json.load(open(path, encoding='utf-8'))
    polys = []
    for f in data['features']:
        g = f['geometry']
        name = f.get('properties', {}).get('name', '')
        if g['type'] == 'Polygon':
            polys.append((g['coordinates'][0], name))
        elif g['type'] == 'MultiPolygon':
            for p in g['coordinates']:
                polys.append((p[0], name))
    return polys


def project(lat, lon):
    """Орфографическая проекция: (X, Y, cosc) — cosc>0 = видимая сторона."""
    cos_p = math.cos(lat)
    d = lon - LON0
    x = cos_p * math.sin(d)
    y = math.sin(LAT0) * math.sin(lat) - math.cos(LAT0) * math.cos(lat) * math.cos(d)
    c = math.sin(LAT0) * math.sin(lat) + math.cos(LAT0) * math.cos(lat) * math.cos(d)
    return x, y, c


def densify(ring, step_deg=1.5):
    out = []
    n = len(ring)
    for i in range(n):
        x0, y0 = ring[i][0], ring[i][1]
        x1, y1 = ring[(i + 1) % n][0], ring[(i + 1) % n][1]
        # короткое замыкание через антимеридиан
        if abs(x1 - x0) > 180:
            continue
        d = math.hypot(x1 - x0, y1 - y0)
        steps = max(1, int(d / step_deg))
        for s in range(steps):
            t = s / steps
            out.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    return out


def visible_ring(ring_dens):
    """Обрезает по лимбу: возвращает список полилиний видимой части."""
    pts = []
    segs = []
    cur = []
    n = len(ring_dens)
    proj = [project(math.radians(p[1]), math.radians(p[0])) for p in ring_dens]
    for i in range(n):
        a = proj[i]
        b = proj[(i + 1) % n]
        ax, ay, ac = a
        bx, by, bc = b
        if ac > 0:
            cur.append((ax, ay))
        if (ac > 0) != (bc > 0):
            # пересечение лимба — интерполируем
            t = ac / (ac - bc)
            ix = ax + (bx - ax) * t
            iy = ay + (by - ay) * t
            cur.append((ix, iy))
            if ac > 0:  # уходили за горизонт
                segs.append(cur)
                cur = [(ix, iy)] if bc > 0 else []
            else:       # возвращались
                if bc > 0:
                    pass  # cur уже начата с точки пересечения
        elif ac <= 0 and cur:
            segs.append(cur)
            cur = []
    if cur:
        segs.append(cur)
    return segs


def draw_globe(size, ocean=True):
    """Рисует глобус на прозрачном холсте size×size."""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    cx = cy = size / 2
    R = size * 0.46

    # атмосферное свечение
    glow = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([cx - R * 1.08, cy - R * 1.08, cx + R * 1.08, cy + R * 1.08],
               fill=(120, 190, 255, 90))
    glow = glow.filter(ImageFilter.GaussianBlur(size * 0.045))
    img.alpha_composite(glow)

    # сфера-океан: радиальный градиент
    sphere = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    px = sphere.load()
    r2 = R * R
    for yy in range(size):
        for xx in range(size):
            dx = xx - cx + size * 0.10
            dy = yy - cy + size * 0.12
            d = math.sqrt(dx * dx + dy * dy)
            if d <= R:
                t = min(1.0, d / R)
                if t < 0.45:
                    k = t / 0.45
                    col = tuple(int(OCEAN_LIGHT[i] + (OCEAN_MID[i] - OCEAN_LIGHT[i]) * k) for i in range(3))
                else:
                    k = (t - 0.45) / 0.55
                    col = tuple(int(OCEAN_MID[i] + (OCEAN_DEEP[i] - OCEAN_MID[i]) * k) for i in range(3))
                px[xx, yy] = col + (255,)
    mask = Image.new('L', (size, size), 0)
    ImageDraw.Draw(mask).ellipse([cx - R, cy - R, cx + R, cy + R], fill=255)
    sphere.putalpha(mask)
    img.alpha_composite(sphere)

    # суша
    land = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    ld = ImageDraw.Draw(land)
    for ring, name in POLYS:
        vd = densify(ring)
        for seg in visible_ring(vd):
            if len(seg) < 3:
                continue
            pts = [(cx + x * R, cy - y * R) for x, y in seg]
            fill = ICE if name in ('Greenland', 'Antarctica') else (
                LAND_DARK if name in ('Russia', 'Canada', 'China', 'Brazil') else LAND)
            ld.polygon(pts, fill=fill + (255,))
    # обрезка суши по кругу
    lm = Image.new('L', (size, size), 0)
    ImageDraw.Draw(lm).ellipse([cx - R, cy - R, cx + R, cy + R], fill=255)
    land.putalpha(Image.composite(land.split()[3], Image.new('L', (size, size), 0), lm))
    img.alpha_composite(land)

    # блик сверху-слева у лимба (маленький и мягкий, чтобы не читался как артефакт)
    spec = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    sd = ImageDraw.Draw(spec)
    sd.ellipse([cx - R * 0.62, cy - R * 0.98, cx - R * 0.02, cy - R * 0.42],
               fill=(255, 255, 255, 75))
    spec = spec.filter(ImageFilter.GaussianBlur(size * 0.055))
    spec.putalpha(Image.composite(spec.split()[3], Image.new('L', (size, size), 0), lm))
    img.alpha_composite(spec)

    return img


def rounded_bg(size, radius_ratio=0.22):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=int(size * radius_ratio), fill=(0, 0, 0, 255))
    return img


def circle_bg(size):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([0, 0, size - 1, size - 1], fill=(0, 0, 0, 255))
    return img


def save(img, rel, size=None):
    path = os.path.join(RES, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if size:
        img = img.resize((size, size), Image.LANCZOS)
    img.save(path)
    print('→', rel, img.size)


def main():
    global POLYS
    POLYS = load_polys(GEO)
    print(f"полигонов: {len(POLYS)}")

    # образец высокого разрешения
    HI = 1024
    globe_hi = draw_globe(HI)
    sq_hi = rounded_bg(HI)
    sq_hi.alpha_composite(globe_hi.resize((int(HI * 0.86),) * 2, Image.LANCZOS),
                          (int(HI * 0.07),) * 2)
    ci_hi = circle_bg(HI)
    ci_hi.alpha_composite(globe_hi.resize((int(HI * 0.86),) * 2, Image.LANCZOS),
                          (int(HI * 0.07),) * 2)
    fg_hi = Image.new('RGBA', (HI, HI), (0, 0, 0, 0))
    gsz = int(HI * 0.58)
    fg_hi.alpha_composite(globe_hi.resize((gsz, gsz), Image.LANCZOS),
                          ((HI - gsz) // 2, (HI - gsz) // 2))

    densities = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    for dpi, s in densities.items():
        save(sq_hi, f'mipmap-{dpi}/ic_launcher.png', s)
        save(ci_hi, f'mipmap-{dpi}/ic_launcher_round.png', s)

    fg_sizes = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}
    for dpi, s in fg_sizes.items():
        save(fg_hi, f'mipmap-{dpi}/ic_launcher_foreground.png', s)

    # уведомление: белая пиктограмма-глобус (обводка)
    stat = Image.new('RGBA', (96, 96), (0, 0, 0, 0))
    d = ImageDraw.Draw(stat)
    d.ellipse([10, 10, 86, 86], outline=(255, 255, 255, 255), width=6)
    d.line([10, 48, 86, 48], fill=(255, 255, 255, 255), width=5)
    d.ellipse([34, 10, 62, 86], outline=(255, 255, 255, 255), width=5)
    save(stat, 'drawable/ic_stat.png', 96)

    print('готово')


if __name__ == '__main__':
    main()
