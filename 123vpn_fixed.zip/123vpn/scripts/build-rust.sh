#!/usr/bin/env bash
# Сборка Rust-крейтов (vpn123-core + vpn123-bridge) под Android ABI
# через cargo-ndk. Результат: app/src/main/jniLibs/<abi>/libvpn123.so
#
# Требования: rustup (Rust ≥ 1.90), Android NDK (ANDROID_NDK_HOME или
# найденный в ~/Android/Sdk/ndk/*), cargo-ndk (ставится автоматически).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/rust"

export PATH="$HOME/.cargo/bin:$PATH"

if ! command -v rustup >/dev/null; then
  echo "✗ rustup не найден. Установите: curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
  exit 1
fi

echo "→ rustup target add ..."
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android

if ! command -v cargo-ndk >/dev/null; then
  echo "→ cargo install cargo-ndk ..."
  cargo install cargo-ndk --locked
fi

# NDK
if [ -z "${ANDROID_NDK_HOME:-}" ]; then
  for d in "$HOME"/Android/Sdk/ndk/* "$HOME"/Library/Android/sdk/ndk/*; do
    [ -d "$d" ] && export ANDROID_NDK_HOME="$d" && break
  done
fi
if [ -z "${ANDROID_NDK_HOME:-}" ]; then
  echo "✗ Android NDK не найден. Установите через Android Studio (SDK Tools → NDK)"
  echo "  или задайте ANDROID_NDK_HOME=/путь/к/ndk"
  exit 1
fi
echo "→ NDK: $ANDROID_NDK_HOME"

cargo ndk \
  -t arm64-v8a \
  -t armeabi-v7a \
  -t x86_64 \
  --platform 26 \
  -o "$ROOT/app/src/main/jniLibs" \
  build --release

echo
echo "Готово:"
find "$ROOT/app/src/main/jniLibs" -name "libvpn123.so" | sort
