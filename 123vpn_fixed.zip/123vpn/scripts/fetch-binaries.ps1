﻿# Скачивает официальные бинарники xray-core и sing-box для Android
# и кладёт их в app\src\main\jniLibs\<abi>\ как libxray.so / libsingbox.so.
# Windows-версия scripts/fetch-binaries.sh — работает в PowerShell 5.1+
# (Windows 10/11: curl.exe и tar.exe уже встроены).
#
# Использование:  powershell -ExecutionPolicy Bypass -File scripts\fetch-binaries.ps1
$ErrorActionPreference = "Stop"

foreach ($Tool in "curl.exe", "tar.exe") {
  if (-not (Get-Command $Tool -ErrorAction SilentlyContinue)) {
    throw "$Tool не найден: нужны Windows 10 (1803+) или Windows 11, где curl.exe и tar.exe встроены. Альтернатива — Git for Windows и bash-версия scripts/fetch-binaries.sh"
  }
}

$XrayVersion    = "v26.11.9"
$SingBoxVersion = "1.14.4"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Jni  = Join-Path $Root "app\src\main\jniLibs"
$Tmp  = Join-Path $env:TEMP ("vpn123-" + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $Tmp -Force | Out-Null
New-Item -ItemType Directory -Path $Jni -Force | Out-Null

# abi → (xray-ассет, sing-box-ассет)
# Для armeabi-v7a у Xray нет android-сборки с 2025 года — берём статическую
# linux/arm32-v7a (чистый Go без cgo, корректно работает под Android).
$Assets = @{
  "arm64-v8a"   = @{ xray = "Xray-android-arm64-v8a.zip";  sb = "sing-box-$SingBoxVersion-android-arm64.tar.gz" }
  "armeabi-v7a" = @{ xray = "Xray-linux-arm32-v7a.zip";    sb = "sing-box-$SingBoxVersion-android-arm.tar.gz"   }
  "x86_64"      = @{ xray = "Xray-android-amd64.zip";      sb = "sing-box-$SingBoxVersion-android-amd64.tar.gz" }
}

function Get-File($Url, $Out) {
  Write-Host "↓ $Url"
  & curl.exe -fSL --retry 3 -o $Out $Url
  if ($LASTEXITCODE -ne 0) { throw "Не удалось скачать $Url" }
}

foreach ($Abi in $Assets.Keys) {
  $Dir = Join-Path $Jni $Abi
  New-Item -ItemType Directory -Path $Dir -Force | Out-Null
  $A = $Assets[$Abi]

  # ── xray ──
  try {
    Get-File "https://github.com/XTLS/Xray-core/releases/download/$XrayVersion/$($A.xray)" (Join-Path $Tmp "xray.zip")
    $ZipDir = Join-Path $Tmp "xray-$Abi"
    Expand-Archive -Path (Join-Path $Tmp "xray.zip") -DestinationPath $ZipDir -Force
    Copy-Item (Join-Path $ZipDir "xray") (Join-Path $Dir "libxray.so") -Force
    Write-Host "  ✓ $Abi\libxray.so"
  } catch { Write-Warning "xray для $Abi пропущен: $_" }

  # ── sing-box ──
  try {
    Get-File "https://github.com/SagerNet/sing-box/releases/download/v$SingBoxVersion/$($A.sb)" (Join-Path $Tmp "sb.tgz")
    $TarDir = Join-Path $Tmp "sb-$Abi"
    New-Item -ItemType Directory -Path $TarDir -Force | Out-Null
    & tar -xzf (Join-Path $Tmp "sb.tgz") -C $TarDir
    if ($LASTEXITCODE -ne 0) { throw "tar завершился с ошибкой" }
    $Bin = Get-ChildItem -Path $TarDir -Recurse -Filter "sing-box" | Select-Object -First 1
    if (-not $Bin) { throw "sing-box не найден в архиве" }
    Copy-Item $Bin.FullName (Join-Path $Dir "libsingbox.so") -Force
    Write-Host "  ✓ $Abi\libsingbox.so"
  } catch { Write-Warning "sing-box для $Abi пропущен: $_" }
}

Remove-Item -Recurse -Force $Tmp -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "Готово. Бинарники в $Jni :"
Get-ChildItem -Recurse $Jni | ForEach-Object { Write-Host $_.FullName.Replace($Root, '') }
