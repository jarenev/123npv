#!/usr/bin/env bash
# Хост-проверка конфига десктопной версии: SOCKS 2080 + HTTP 2081 inbound.
set -e
RUST=/home/z/my-project/download/123vpn/rust
mkdir -p /tmp/pccheck && cd /tmp/pccheck

# 1. подписка → декодированные ноды
URL="https://npv.jarenev.space/sub/1b790b00-b2fa-4d53-b663-9d045f632c73"
curl -fsS -m 20 -A "123VPN/1.0 (Windows)" -o sub.txt "$URL"
python3 -c "
import base64
b = open('/tmp/pccheck/sub.txt').read().strip()
open('/tmp/pccheck/nodes.txt','w').write(base64.urlsafe_b64decode(b + '=' * (-len(b) % 4)).decode())
print('nodes ok')
"

# 2. конфиг из кода приложения (dumpcfg) — собираем пример, если нет бинаря
if [ ! -x "$RUST/target/release/examples/dumpcfg" ]; then
  (cd "$RUST" && PATH="$HOME/.cargo/bin:$PATH" cargo build --release --example dumpcfg)
fi
"$RUST/target/release/examples/dumpcfg" /tmp/pccheck/nodes.txt 2080

# 3. добавляем HTTP inbound ровно как в backend.rs
python3 -c "
import json
c = json.load(open('/tmp/xray_cfg.json'))
c['inbounds'].append({'tag':'http-in','listen':'127.0.0.1','port':2081,'protocol':'http','settings':{}})
json.dump(c, open('/tmp/pccheck/cfg_http.json','w'))
print('inbounds:', [(i.get('tag'), i.get('port')) for i in c['inbounds']])
"

# 4. xray на хосте (тот же релиз, что и в APK/ПК-пакете)
[ -x /tmp/pccheck/xray ] || { curl -fsSL -m 300 -o xray.zip "https://github.com/XTLS/Xray-core/releases/download/v26.11.9/Xray-linux-64.zip" && unzip -oq xray.zip xray && chmod +x xray; }
(./xray run -c /tmp/pccheck/cfg_http.json > xray.log 2>&1 & echo $! > xray.pid)
sleep 3

echo "SOCKS 2080: $(curl -m 15 -s --socks5-hostname 127.0.0.1:2080 -o /dev/null -w '%{http_code}' https://connectivitycheck.gstatic.com/generate_204)"
echo "HTTP  2081: $(curl -m 15 -s -x http://127.0.0.1:2081 -o /dev/null -w '%{http_code}' https://connectivitycheck.gstatic.com/generate_204)"
echo "IP выхода:  $(curl -m 15 -s -x http://127.0.0.1:2081 https://api.ipify.org)"
kill $(cat /tmp/pccheck/xray.pid) 2>/dev/null || true
echo PC_CONFIG_OK
