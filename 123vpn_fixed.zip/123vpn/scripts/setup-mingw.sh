#!/usr/bin/env bash
# Ставит x86_64-w64-mingw32-gcc без root: скачивает .deb из Debian и распаковывает в ~/opt/mingw.
set -e
BASE="$HOME/opt/mingw"
rm -rf /tmp/debs "$BASE"; mkdir -p /tmp/debs "$BASE/usr"
cd /tmp/debs

pick() { # $1 = url каталога pool, $2 = префикс имени пакета
  curl -s "$1" | grep -oE "href=\"$2[^\"]*_(amd64|all)\.deb\"" \
    | sed 's/href="//; s/"$//' | sort -V | tail -1
}

M="https://deb.debian.org/debian/pool/main/m/mingw-w64/"
B="https://deb.debian.org/debian/pool/main/b/binutils-mingw-w64/"
G="https://deb.debian.org/debian/pool/main/g/gcc-mingw-w64/"

FILES=""
f=$(pick "$B" "binutils-mingw-w64-x86-64"); [ -n "$f" ] || { echo "MISS binutils"; exit 1; }
echo "get $f"; curl -fsSO "$B$f"; FILES="$FILES $f"
for n in mingw-w64-common mingw-w64-x86-64-dev; do
  f=$(pick "$M" "$n"); [ -n "$f" ] || { echo "MISS $n"; exit 1; }
  echo "get $f"; curl -fsSO "$M$f"; FILES="$FILES $f"
done
for n in gcc-mingw-w64-base cpp-mingw-w64-x86-64 gcc-mingw-w64-x86-64 \
         cpp-mingw-w64-x86-64-posix cpp-mingw-w64-x86-64-win32 \
         gcc-mingw-w64-x86-64-posix gcc-mingw-w64-x86-64-win32; do
  f=$(pick "$G" "$n")
  if [ -z "$f" ]; then echo "skip $n (нет в pool)"; continue; fi
  echo "get $f"; curl -fsSO "$G$f"; FILES="$FILES $f"
done

for f in $FILES; do dpkg -x "$f" "$BASE/usr"; done

# бинарники оказываются в $BASE/usr/usr/bin (deb содержит usr/bin); альтернатив-симлинки
# после dpkg -x битые — восстанавливаем вручную
BIN="$BASE/usr/usr/bin"
cd "$BIN"
for name in gcc g++ cpp; do
  if [ ! -e "x86_64-w64-mingw32-$name" ]; then
    for v in posix win32; do
      b="x86_64-w64-mingw32-$name-$v"
      [ -e "$b" ] && { ln -sf "$b" "x86_64-w64-mingw32-$name"; break; }
    done
  fi
done

echo "PATH entry: $(which x86_64-w64-mingw32-gcc 2>/dev/null || echo "$BIN/x86_64-w64-mingw32-gcc")"
"$BIN/x86_64-w64-mingw32-gcc" --version | head -1
echo 'int main(void){return 0;}' > /tmp/t-mingw.c && "$BIN/x86_64-w64-mingw32-gcc" /tmp/t-mingw.c -o /tmp/t-mingw.exe && file /tmp/t-mingw.exe
echo "MINGW_READY (путь: $BIN)"
