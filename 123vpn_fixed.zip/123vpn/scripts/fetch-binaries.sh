#!/usr/bin/env bash
# Скачивает официальные бинарники xray-core и sing-box для Android
# и кладёт их в app/src/main/jniLibs/<abi>/ как libxray.so / libsingbox.so.
# Имена *.so — чтобы Gradle упаковал их как нативные библиотеки:
# Android распаковывает их в nativeLibraryDir, откуда их можно запускать.
#
# Версии зафиксированы. Для обновления поменяйте переменные ниже
# (имена ассетов проверены для этих тегов).
set -euo pipefail

XRAY_VERSION="v26.11.9"
SINGBOX_VERSION="1.14.4"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JNILIBS="$ROOT/app/src/main/jniLibs"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$JNILIBS"

fetch() { # url → файл
    local url="$1" out="$2"
    echo "↓ $url"
    curl -fSL --retry 3 -o "$out" "$url"
}

# abi → (xray asset, singbox asset)
# Для armeabi-v7a у Xray нет android-сборки с 2025 года — берём статическую
# linux/arm32-v7a (чистый Go без cgo, корректно работает под Android).
declare -A XRAY_ASSET=(
  [arm64-v8a]="Xray-android-arm64-v8a.zip"
  [x86_64]="Xray-android-amd64.zip"
  [armeabi-v7a]="Xray-linux-arm32-v7a.zip"
)
declare -A SB_ASSET=(
  [arm64-v8a]="sing-box-${SINGBOX_VERSION}-android-arm64.tar.gz"
  [x86_64]="sing-box-${SINGBOX_VERSION}-android-amd64.tar.gz"
  [armeabi-v7a]="sing-box-${SINGBOX_VERSION}-android-arm.tar.gz"
)

for ABI in arm64-v8a armeabi-v7a x86_64; do
  DIR="$JNILIBS/$ABI"
  mkdir -p "$DIR"

  # ── xray ──
  XA="${XRAY_ASSET[$ABI]}"
  if fetch "https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/${XA}" "$TMP/xray.zip"; then
    rm -rf "$TMP/xrayx" && mkdir -p "$TMP/xrayx"
    unzip -oq "$TMP/xray.zip" -d "$TMP/xrayx"
    cp "$TMP/xrayx/xray" "$DIR/libxray.so"
    chmod 755 "$DIR/libxray.so"
    echo "  ✓ $ABI/libxray.so"
  else
    echo "  ⚠ xray для $ABI недоступен ($XA) — пропускаю"
  fi

  # ── sing-box ──
  SA="${SB_ASSET[$ABI]}"
  if fetch "https://github.com/SagerNet/sing-box/releases/download/v${SINGBOX_VERSION}/${SA}" "$TMP/sb.tgz"; then
    rm -rf "$TMP/sbx" && mkdir -p "$TMP/sbx"
    tar -xzf "$TMP/sb.tgz" -C "$TMP/sbx"
    cp "$TMP/sbx/sing-box-${SINGBOX_VERSION}-android-"*/sing-box "$DIR/libsingbox.so"
    chmod 755 "$DIR/libsingbox.so"
    echo "  ✓ $ABI/libsingbox.so"
  else
    echo "  ⚠ sing-box для $ABI недоступен ($SA) — пропускаю"
  fi
done

echo
echo "Готово. Бинарники в $JNILIBS:"
find "$JNILIBS" -type f | sort
