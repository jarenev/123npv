# 123 VPN

Мобильный VPN-клиент для Android в стиле [jarenev.space](https://jarenev.space):
чистый чёрный экран, типографика Unbounded, зерно и точечная сетка под пальцем —
и вращающаяся **планета из точек суши**, которая ускоряется при подключении
и отмечает пульсирующим маркером страну выбранного сервера.

Ядро логики написано на **Rust**, интерфейс — **HTML/CSS/JS** (WebView),
движки — **xray-core** и **sing-box** (официальные бинарники).

> Сервер **выбрать вручную нельзя** — по задумке. Приложение всегда само
> подключается к серверу с лучшим пингом, а если тот умирает — молча
> переключается на следующий.

---

## Как это работает

```
┌──────────────────────────────────────────────────────────────┐
│  WebView (assets/ui): HTML+CSS+JS, планета на canvas         │
│      ▲▼ window.Android.* (JS-мост, опрос статуса 500 мс)     │
│  MainActivity / Vpn123Service (Kotlin)                       │
│      ▲▼ JNI (libvpn123.so)                                   │
│  Rust: супервизор                                            │
│   1. загрузка подписки (ureq + rustls)                       │
│   2. парсинг всех ссылок (14 протоколов)                     │
│   3. TCP-пинг всех серверов параллельно                      │
│   4. выбор лучшего → генерация config.json                   │
│   5. запуск ядра: xray ИЛИ sing-box (по протоколу)           │
│      ▲▼                                                      │
│  tun2proxy (Rust): TUN-fd от VpnService → SOCKS5 ядра        │
│  монитор: пинг каждые 10 c, 2 промаха → failover             │
└──────────────────────────────────────────────────────────────┘
```

Ключевые решения:

* **Автоподбор ядра**: vmess/vless/trojan/ss/socks/http/wireguard → *xray*
  (fallback sing-box); hysteria/hysteria2/tuic/anytls/shadowtls/naive/ssh →
  *sing-box*. Переключать вручную не нужно — протокол сам определяет движок.
* **Failover без разрыва туннеля**: TUN-интерфейс не пересоздаётся. При смерти
  сервера супервизор убивает ядро, генерирует конфиг для следующего живого
  сервера (возможно, уже на другом ядре) и поднимает его на том же SOCKS-порту.
* **Без петель**: трафик самого приложения (UID) исключён из VPN
  (`addDisallowedApplication`), поэтому сокеты ядер идут напрямую в интернет.
* **DNS**: UDP:53 из TUN гонится через прокси как DNS-over-TCP (tun2proxy
  `ArgDns::OverTcp` → 1.1.1.1), домены резолвятся «на той стороне».

### Поддерживаемые протоколы

| Протокол | Ссылка | Ядро |
|---|---|---|
| vmess | `vmess://` (base64-JSON) | xray ⇄ sing-box |
| vless (+REALITY, uTLS, ws/grpc/http/httpupgrade/xhttp) | `vless://` | xray ⇄ sing-box |
| trojan | `trojan://` | xray ⇄ sing-box |
| shadowsocks (+plugin obfs/v2ray-plugin) | `ss://` (SIP002 и legacy) | xray ⇄ sing-box |
| socks5 / http(s) | `socks://`, `http(s)://` | xray ⇄ sing-box |
| wireguard | `wireguard://`, `wg://` | xray ⇄ sing-box |
| hysteria | `hysteria://` | sing-box |
| hysteria2 | `hysteria2://`, `hy2://` | sing-box |
| tuic | `tuic://` | sing-box |
| anytls | `anytls://` | sing-box |
| shadowtls | `shadowtls://` | sing-box |
| naive | `naive://` | sing-box |
| ssh | `ssh://` | sing-box |
| ssr | распознаётся, но помечен неподдерживаемым | — |

Подписка принимается в любом виде: base64-обёртка, открытый список ссылок,
SIP008/JSON (`{"servers":[...]}`). Ссылка запрашивается один раз — при первом
входе в приложение (потом доступна через «Подписка» в футере); тело качается
заново при каждом подключении.

### Экран приложения (один экран, без прокрутки)

* при **первом входе** — модальное окно «Подписка»: одно поле ссылки,
  кнопка «Сохранить и проверить» (покажет количество живых серверов и лучший
  с пингом). Пока ссылка не сохранена, подключение недоступно;
* планета (точки суши из реальных геоданных) с маркером сервера;
* статус: отключено / подключение / подключено / переключение / ошибка,
  причина последней ошибки показывается строкой под статусом;
* страна сервера с флагом, пинг, автоматически выбранное ядро и протокол;
* трафик: RX/TX и скорости (обновление раз в секунду);
* **Kill Switch** — тумблер: приложение само поднимает VPN заново при обрыве
  (до 3 попыток с паузой 3 с), чтобы трафик не ушёл мимо туннеля. Ручное
  отключение тумблером не прерывается. Для системной блокировки трафика
  без VPN включите «Always-on VPN» + «Блокировать соединения без VPN»
  в настройках Android (Настройки → Сети → VPN → 123 VPN);
* «События» и ручной выбор ядра убраны: ядро и сервер выбираются автоматически.

---

## Сборка APK локально

### Требования

* **JDK 17** (Temurin/OpenJDK)
* **Android SDK**: Platform 35, Build-Tools 35.x, **NDK r26+** — проще всего
  через Android Studio (SDK Manager), либо только командная строка
* **Rust ≥ 1.90** — <https://rustup.rs>
* **curl/unzip/tar** (для скачивания ядер)
* ~10 минут и ~2 ГБ на загрузки

### Три команды

```bash
# 1. Скачать официальные бинарники xray + sing-box (версии зафиксированы)
bash scripts/fetch-binaries.sh

# 2. Собрать Rust-библиотеку под 3 ABI (cargo-ndk поставится сам)
bash scripts/build-rust.sh

# 3. Собрать APK (Gradle 8.11+ / Android Studio)
bash scripts/build-all.sh        # или: gradle assembleRelease
```

Готовый APK: `app/build/outputs/apk/release/app-release.apk`
(подписан debug-ключом для удобства — для публикации в Google Play замените
`signingConfig` в `app/build.gradle.kts` на свой keystore).

Альтернатива шагу 3: открыть каталог проекта в **Android Studio** и нажать
▶ (Run) — Gradle-синхронизация подтянет AGP 8.7.3 и Kotlin 2.0.21 сама.

Если `./gradlew` ещё нет: `gradle wrapper --gradle-version 8.11.1` один раз.

### Что скачивается (проверенные источники)

| Компонент | Версия | Источник |
|---|---|---|
| xray-core | v26.11.9 | github.com/XTLS/Xray-core (`Xray-android-arm64-v8a.zip`, `Xray-android-amd64.zip`) |
| xray (armv7) | v26.11.9 | та же страница, `Xray-linux-arm32-v7a.zip` — у xray нет android-v7a ассета с 2025 г.; статическая Go-сборка корректно работает под Android |
| sing-box | 1.14.4 | github.com/SagerNet/sing-box (`sing-box-…-android-{arm64,arm,amd64}.tar.gz`) |

Бинарники кладутся в `app/src/main/jniLibs/<abi>/` под именами `libxray.so` /
`libsingbox.so`: Android распаковывает нативные библиотеки в
`nativeLibraryDir`, откуда их разрешено запускать через `exec()`.

---

## Сборка на Windows

В репозитории лежат старые **предсобранные** `libvpn123.so`, но код Rust с тех пор
изменился (см. CHANGES.md: закрепление IP, UDP-пинг, супервизор) — **шаг
`build-rust` обязателен**, иначе исправления в APK не попадут.

### Вариант 1 — Android Studio (самый простой)

1. Установите **Android Studio** (<https://developer.android.com/studio>) —
   внутри уже есть JDK, отдельно ничего ставить не нужно.
2. SDK Manager (Tools → SDK Manager):
   * **SDK Platforms** → Android 15 (API 35);
   * **SDK Tools** → Android SDK Build-Tools 35, Android SDK Platform-Tools.
   * NDK не обязателен, если используете prebuilt `libvpn123.so`.
3. Скачайте бинарники ядер — в PowerShell:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\fetch-binaries.ps1
   ```
   (использует встроенные в Windows 10/11 `curl.exe` и `tar.exe`).
4. Откройте папку проекта в Android Studio → дождитесь Gradle Sync →
   **Build → Build Bundle(s)/APK(s) → Build APK(s)** (или просто ▶ Run
   с подключённым телефоном).
5. APK появится в `app\build\outputs\apk\release\app-release.apk`
   (release подписан debug-ключом; для Play — свой keystore в
   `app/build.gradle.kts`).

### Вариант 2 — всё из PowerShell (без Studio, без winget)

Gradle-wrapper (`gradlew.bat`) входит в комплект; JDK 17 и Android SDK скрипт
скачает сам (ZIP, без прав администратора) при первом запуске. Ничего
устанавливать вручную не нужно — только Windows 10/11 с интернетом.

```powershell
# Всё сразу: ядра + (при необходимости) Rust + JDK/SDK + APK.
# Первый запуск скачает ~500 МБ (JDK 17, Android SDK, Gradle и зависимости).
powershell -ExecutionPolicy Bypass -File scripts\build-all.ps1
```

Отдельные шаги (обычно не нужны):

```powershell
# Только ядра (build-all делает это сам, если их нет)
powershell -ExecutionPolicy Bypass -File scripts\fetch-binaries.ps1

# Только пересборка Rust после правок в rust/.
# Нужны: Rust ≥ 1.90 (rustup.rs), MSVC Build Tools C++, Android NDK.
powershell -ExecutionPolicy Bypass -File scripts\build-rust.ps1
```

### Вариант 3 — WSL2 (Ubuntu) как Linux

Внутри WSL ставятся Linux-версии всего стека и работает штатная bash-сборка
из предыдущего раздела; APK — обычный файл, устанавливается с Windows
через `adb install` или копированием.

### Частые проблемы на Windows

* **`cargo ndk` не находит NDK** → `$env:ANDROID_NDK_HOME = "C:\...\ndk\<версия>"`.
* **Gradle Sync падает на JDK** → в Studio: Settings → Build Tools → Gradle →
  Gradle JDK → Embedded JDK (17+).
* **PowerShell блокирует скрипты** → запускайте с
  `-ExecutionPolicy Bypass` (как в командах выше) или выполните
  `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
* **Ошибки «отсутствует завершающий символ» при запуске .ps1** → файл сохранён
  без BOM: Windows PowerShell 5.1 читает его в системной кодировке (CP1251),
  и русские строки ломают парсер. В комплекте файлы уже в «UTF-8 с BOM» —
  если правите их сами, сохраняйте в том же режиме (Notepad++: Кодировки →
  «UTF-8 с BOM»; VS Code: «Save with Encoding → UTF-8 with BOM»).

---

## Настройка

1. Запустите приложение → при первом входе откроется «Подписка» — вставьте
   ссылку от провайдера (`https://…/sub`) **или одиночную ноду** —
   `vless://`, `vmess://`, `trojan://`, `ss://`, `hysteria2://`, `tuic://` и
   другие (схемы — в таблице выше; `http(s)://` считается подпиской) —
   → «Сохранить и проверить».
2. Тапните «Подключиться» → согласитесь на VPN.
3. Готово: пинг, выбор сервера и ядра — автоматические, трафик и Kill Switch
   — на экране. Сменить подписку: «Подписка» в футере.

Данные хранятся локально (SharedPreferences): ссылка подписки, язык (RU/EN —
кнопка в шапке), Kill Switch. Серверы не показываются и не выбираются.

Если подключение не проходит, причина показывается на главном экране и в
уведомлении. Частый случай: **Android допускает только один активный VPN** —
отключите другие VPN-приложения (Happ и т.п.), в том числе режим
«Always-on VPN», и повторите подключение.

---

## Версия для ПК (Windows)

Крейт `rust/vpn123-desktop` — то же приложение для Windows 10/11 x64: тёмный
одноэкранный GUI (Win32, без внешних зависимостей), та же логика подписки,
парсинга, пинга и выбора сервера (общий `vpn123-core`), ядро — `xray.exe`
(v26.11.9) рядом с `123vpn.exe`. На ПК работает в режиме **системного прокси**
(HTTP 127.0.0.1:2081 + SOCKS 2080) — как v2rayN: без прав администратора и без
TUN-драйвера; браузеры и большинство приложений идут через VPN автоматически.

Готовый дистрибутив — `123vpn-pc-v1.0.0.zip` (лежит рядом с проектом).
Кросс-сборка из Linux: `scripts/setup-mingw.sh` (входит в состав проекта)
→ `cargo build --release -p vpn123-desktop --target x86_64-pc-windows-gnu`
(подробности — в README-PC.md внутри дистрибутива).

---

## Структура проекта

```
123vpn/
├── app/                          Android-обёртка (Kotlin)
│   ├── build.gradle.kts          AGP 8.7.3, minSdk 26, targetSdk 35
│   └── src/main/
│       ├── AndroidManifest.xml   VpnService, FOREGROUND_SERVICE_SPECIAL_USE
│       ├── java/space/jarenev/vpn123/
│       │   ├── MainActivity.kt   WebView + согласие на VPN
│       │   ├── Bridge.kt         JS-мост window.Android
│       │   ├── Vpn123Service.kt  VpnService: establish() → fd → JNI
│       │   ├── Vpn123Jni.kt      объявления JNI-функций
│       │   ├── TrafficState.kt   TrafficStats (RX/TX, скорости)
│       │   └── Prefs.kt          настройки
│       ├── assets/ui/            интерфейс (HTML/CSS/JS + шрифты + world.json)
│       └── res/                  иконка 🌍 (все densities + adaptive)
├── rust/
│   ├── vpn123-core/              ядро логики (чистый Rust, 42 теста)
│   │   └── src/
│   │       ├── links.rs          парсер 14 протоколов + подписок
│   │       ├── ping.rs           параллельный TCP-пинг
│   │       ├── select.rs         автоподбор + выбор ядра
│   │       ├── config_xray.rs    генератор конфига xray
│   │       ├── config_singbox.rs генератор конфига sing-box
│   │       ├── geo.rs            страна/флаг/координаты по имени
│   │       └── model.rs          модель данных
│   └── vpn123-bridge/            cdylib → libvpn123.so
│       └── src/
│           ├── jni.rs            JNI-точки входа
│           ├── supervisor.rs     машина состояний + failover
│           ├── tun.rs            tun2proxy (TUN-fd → SOCKS5)
│           ├── net.rs            загрузка подписки
│           └── state.rs          статус для UI
├── scripts/
│   ├── fetch-binaries.sh         xray/sing-box → jniLibs
│   ├── build-rust.sh             cargo-ndk сборка libvpn123.so
│   ├── build-all.sh              всё + Gradle
│   ├── make-icons.py             регенерация иконки из GeoJSON
│   └── make-world-dots.py        регенерация world.json
└── README.md
```

## Диагностика

* лог супервизора: `adb shell run-as space.jarenev.vpn123 cat files/supervisor.log`
* лог ядра (stdout/stderr xray/sing-box): `… cat files/core.log`
* статус в живую: JS-мост `Android.status()` (виден в Chrome DevTools,
  `chrome://inspect` при debug-сборке WebView)

## Известные ограничения

* **IPv4-only**: TUN поднимается только с маршрутом `0.0.0.0/0`; AAAA-записи
  фильтруются, приложения работают через v4 (стандартное поведение ряда
  мобильных клиентов).
* **Трафик самого приложения идёт мимо VPN** (следствие защиты от петель через
  `addDisallowedApplication`): WebView-интерфейс и загрузка подписки не
  туннелируются. Трафик всех остальных приложений — через VPN.
* **xray на armeabi-v7a** собирается из linux-ассета (см. таблицу выше);
  на arm64/x86_64 — официальные android-сборки.
* Нет geoip/geosite-роутинга внутри конфига: всё, что попало в TUN, идёт в
  прокси (роутинг на стороне сервера).

## Лицензии и источники

* Дизайн-референс и шрифты: [jarenev.space](https://jarenev.space) —
  **Unbounded** и **Inter** распространяются по SIL OFL 1.1.
* Точки суши и континенты иконки: [countries.geo.json](https://github.com/johan/world.geo.json) (public domain).
* [tun2proxy 0.8](https://github.com/tun2proxy/tun2proxy) — MIT.
* [xray-core](https://github.com/XTLS/Xray-core) — MPL 2.0; [sing-box](https://github.com/SagerNet/sing-box) — GPL-3.0
  (используются как отдельные бинарники официальных релизов).
* Схемы конфигов выверены по официальной документации:
  [xtls.github.io](https://xtls.github.io/en/config/),
  [sing-box.sagernet.org](https://sing-box.sagernet.org/configuration/).
