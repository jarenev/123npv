//! 123 VPN — десктопная версия (Windows).
//! Тот же конвейер, что и на Android: подписка/нода → пинг → лучший сервер →
//! ядро (xray) → проксирование. На ПК — режим системного прокси (HTTP 2081):
//! браузеры и большинство приложений идут через VPN без прав администратора.
//!
//! GUI: тёмный одноэкранный Win32 — статус, сервер, трафик, Kill Switch,
//! подписка с проверкой, RU/EN.

#![windows_subsystem = "windows"]

mod backend;
mod i18n;
mod proxy;
mod settings;
mod traffic;

use backend::{Cmd, StatusView, UiMsg};
use i18n::{tr, Lang};
use settings::Settings;
use std::sync::atomic::{AtomicIsize, Ordering};
use std::sync::{mpsc, Mutex};
use windows_sys::Win32::Foundation::{COLORREF, HWND, LPARAM, LRESULT, RECT, WPARAM};
use windows_sys::Win32::Graphics::Gdi::{
    CreateFontW, CreateSolidBrush, DeleteObject, DrawTextW, FillRect, FrameRect, InvalidateRect,
    SelectObject, SetBkMode, SetTextColor, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
    DT_CENTER, DT_SINGLELINE, DT_VCENTER, DEFAULT_CHARSET, FW_BOLD, HDC, HGDIOBJ,
    TRANSPARENT,
};
use windows_sys::Win32::System::LibraryLoader::GetModuleHandleW;
use windows_sys::Win32::UI::Controls::{DRAWITEMSTRUCT, ODS_DISABLED, ODS_SELECTED};
use windows_sys::Win32::UI::WindowsAndMessaging::{
    AdjustWindowRect, CreateWindowExW, CW_USEDEFAULT, DefWindowProcW, DispatchMessageW,
    DestroyWindow, GetDlgCtrlID, GetMessageW, GetWindowTextW, LoadCursorW, PostMessageW,
    PostQuitMessage, RegisterClassExW, SendMessageW, SetProcessDPIAware, ShowWindow,
    TranslateMessage, IDC_ARROW, SW_SHOW, WNDCLASSEXW, WM_APP, WM_CLOSE, WM_COMMAND,
    WM_CREATE, WM_CTLCOLORBTN, WM_CTLCOLORDLG, WM_CTLCOLOREDIT, WM_CTLCOLORSTATIC,
    WM_DESTROY, WM_DRAWITEM, WM_SETFONT, WM_SETTEXT, WS_CHILD, WS_TABSTOP, WS_VISIBLE,
};

const VERSION: &str = env!("CARGO_PKG_VERSION");

// ── ID контролов ─────────────────────────────────────────────
const BTN_CONNECT: u32 = 100;
const BTN_LANG: u32 = 101;
const CHK_KILL: u32 = 102;
const EDIT_SUB: u32 = 103;
const BTN_SAVE: u32 = 104;
const ST_TITLE: u32 = 201;
const ST_STATUS: u32 = 202;
const ST_SERVER: u32 = 203;
const ST_TRAFFIC: u32 = 204;
const ST_SUBRES: u32 = 205;
const ST_ERR: u32 = 206;
const ST_FOOT: u32 = 207;
const ST_SUBLBL: u32 = 208;
const ST_HINT: u32 = 209;

const WM_APP_UI: u32 = WM_APP + 1;

// ── Палитра (COLORREF = 0x00BBGGRR) ──────────────────────────
const C_BG: COLORREF = 0x20100b; // #0b1020
const C_PANEL: COLORREF = 0x2e1a13; // #131a2e
const C_ACCENT: COLORREF = 0xf67c2f; // #2f7cf6
const C_BTN: COLORREF = 0x3e2a1e; // #1e2a3e
const C_BTN_SEL: COLORREF = 0x5a3a12;
const C_TEXT: COLORREF = 0xffffff;
const C_DIM: COLORREF = 0xb5a09a; // #9aa0b5
const C_OK: COLORREF = 0x59c735; // #35c759
const C_ERR: COLORREF = 0x3a45ff; // #ff453a

// ── Глобальное состояние UI (однопоточное: только UI-тред трогает) ──
struct Gui {
    lang: Lang,
    handles: Vec<(u32, isize)>,
    last: Option<StatusView>,
    subres: u8, // 0 — нет, 1 — ok, 2 — ошибка
    tx: mpsc::Sender<Cmd>,
    settings: Settings,
}
static G: Mutex<Option<Gui>> = Mutex::new(None);
static H_MAIN: AtomicIsize = AtomicIsize::new(0);
static F_TITLE: AtomicIsize = AtomicIsize::new(0);
static F_BODY: AtomicIsize = AtomicIsize::new(0);
static F_SMALL: AtomicIsize = AtomicIsize::new(0);
static F_BTN: AtomicIsize = AtomicIsize::new(0);
static BR_BG: AtomicIsize = AtomicIsize::new(0);
static BR_PANEL: AtomicIsize = AtomicIsize::new(0);
static BR_ACCENT: AtomicIsize = AtomicIsize::new(0);
static BR_BTN: AtomicIsize = AtomicIsize::new(0);
static BR_BTN_SEL: AtomicIsize = AtomicIsize::new(0);

/// UTF-16 с нулём на конце для WinAPI-строк.
fn pw(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}

/// Post из бэкенда в UI-поток: heap-бокс через WM_APP.
pub unsafe fn post_ui(hwnd: isize, msg: UiMsg) {
    let p = Box::into_raw(Box::new(msg));
    PostMessageW(hwnd as HWND, WM_APP_UI, 0, p as isize);
}

fn hwnd_of(gui: &Gui, id: u32) -> HWND {
    gui.handles.iter().find(|(i, _)| *i == id).map(|(_, h)| *h as HWND).unwrap_or(std::ptr::null_mut())
}

fn set_text(gui: &Gui, id: u32, text: &str) {
    let h = hwnd_of(gui, id);
    if !h.is_null() {
        let t = pw(text);
        unsafe { SendMessageW(h, WM_SETTEXT, 0, t.as_ptr() as isize) };
    }
}

fn is_active(sv: &Option<StatusView>) -> bool {
    matches!(
        sv,
        Some(
            StatusView::Fetching
                | StatusView::Pinging
                | StatusView::Starting { .. }
                | StatusView::Connected { .. }
                | StatusView::Reconnecting { .. }
        )
    )
}

/// Статусная строка по состоянию.
fn status_text(lang: Lang, sv: &Option<StatusView>) -> String {
    match sv {
        None => tr(lang, "idle").to_string(),
        Some(StatusView::Idle) => tr(lang, "idle").to_string(),
        Some(StatusView::Fetching) => tr(lang, "fetching").to_string(),
        Some(StatusView::Pinging) => tr(lang, "pinging").to_string(),
        Some(StatusView::Starting { name, core, proto }) => {
            format!("{} · {} · {} ({})", tr(lang, "starting"), name, core, proto)
        }
        Some(StatusView::Connected { name, core, proto: _proto, ms, fails }) => {
            let extra = if *fails > 0 { format!(" · +{}", fails) } else { String::new() };
            let ms = match ms {
                Some(v) => format!(" · {} {}", v, tr(lang, "ms")),
                None => String::new(),
            };
            format!("{} · {} · {}{}{}", tr(lang, "connected"), name, core, ms, extra)
        }
        Some(StatusView::Reconnecting { name }) => {
            if name.is_empty() {
                tr(lang, "reconnecting").to_string()
            } else {
                format!("{} · {}", tr(lang, "reconnecting"), name)
            }
        }
        Some(StatusView::Error { key, detail }) => {
            if detail.is_empty() {
                tr(lang, key).to_string()
            } else {
                format!("{} ({})", tr(lang, key), detail)
            }
        }
    }
}

/// Обновить все подписи под текущий язык/состояние.
fn apply_texts(gui: &mut Gui) {
    let hwnd = H_MAIN.load(Ordering::Relaxed) as HWND;
    let lang = gui.lang;

    set_text(gui, ST_TITLE, tr(lang, "title"));
    set_text(gui, ST_STATUS, &status_text(lang, &gui.last));
    set_text(gui, ST_SERVER, tr(lang, "server_none"));
    set_text(gui, ST_TRAFFIC, tr(lang, "traffic_idle"));
    set_text(gui, CHK_KILL, tr(lang, "killswitch"));
    set_text(gui, ST_SUBLBL, tr(lang, "sub_label"));
    set_text(gui, EDIT_SUB, &gui.settings.sub);
    set_text(gui, BTN_SAVE, tr(lang, "save_check"));
    set_text(gui, ST_HINT, tr(lang, "hint_proxy"));
    set_text(gui, ST_FOOT, &format!("{} {}", tr(lang, "version"), VERSION));
    // язык-кнопка показывает следующий язык
    set_text(gui, BTN_LANG, lang.label());
    // статус ошибок подписки перерисовываем с переводом
    gui.subres = match gui.subres {
        1 => 1,
        2 => 2,
        s => s,
    };

    // чекбокс Kill Switch из настроек
    let chk = if gui.settings.kill_switch { 1usize } else { 0usize };
    unsafe { SendMessageW(hwnd_of(gui, CHK_KILL), 0x00F1 /* BM_SETCHECK */, chk, 0) };

    unsafe {
        if !hwnd.is_null() {
            InvalidateRect(hwnd, std::ptr::null(), 1);
        }
        // owner-draw кнопки перерисуются на WM_DRAWITEM
        InvalidateRect(hwnd_of(gui, BTN_CONNECT), std::ptr::null(), 1);
    }
}

unsafe fn create_fonts() {
    let mk = |h: i32, bold: i32| -> isize {
        CreateFontW(
            h, 0, 0, 0, if bold != 0 { FW_BOLD as i32 } else { 400 }, 0, 0, 0,
            DEFAULT_CHARSET as u32, 0, CLIP_DEFAULT_PRECIS as u32, CLEARTYPE_QUALITY as u32, 0,
            pw("Segoe UI").as_ptr(),
        ) as isize
    };
    F_TITLE.store(mk(-26, 1), Ordering::Relaxed);
    F_BODY.store(mk(-15, 0), Ordering::Relaxed);
    F_SMALL.store(mk(-13, 0), Ordering::Relaxed);
    F_BTN.store(mk(-15, 1), Ordering::Relaxed);
}

unsafe fn create_brushes() {
    BR_BG.store(CreateSolidBrush(C_BG) as isize, Ordering::Relaxed);
    BR_PANEL.store(CreateSolidBrush(C_PANEL) as isize, Ordering::Relaxed);
    BR_ACCENT.store(CreateSolidBrush(C_ACCENT) as isize, Ordering::Relaxed);
    BR_BTN.store(CreateSolidBrush(C_BTN) as isize, Ordering::Relaxed);
    BR_BTN_SEL.store(CreateSolidBrush(C_BTN_SEL) as isize, Ordering::Relaxed);
}

unsafe fn add_child(
    handles: &mut Vec<(u32, isize)>, parent: HWND, class: &str, text: &str,
    style: u32, x: i32, y: i32, w: i32, h: i32, id: u32, font: isize,
) {
    let h = CreateWindowExW(
        0, pw(class).as_ptr(), pw(text).as_ptr(), style, x, y, w, h, parent,
        id as HMENU_ALIAS, GetModuleHandleW(std::ptr::null()), std::ptr::null_mut(),
    );
    if !h.is_null() {
        SendMessageW(h, WM_SETFONT, font as WPARAM, 1);
        handles.push((id, h as isize));
    }
}

// HMENU в windows-sys — отдельный тип; локальный алиас для порядка.
#[allow(non_camel_case_types)]
type HMENU_ALIAS = *mut std::ffi::c_void;

unsafe fn create_controls(hwnd: HWND) -> Vec<(u32, isize)> {
    let mut handles: Vec<(u32, isize)> = Vec::new();
    let (st_st, st_btn, st_edit) = (
        WS_CHILD | WS_VISIBLE,                                    // static
        WS_CHILD | WS_VISIBLE,                                    // button base
        WS_CHILD | WS_VISIBLE | WS_TABSTOP,                       // edit/checkbox base
    );
    let st = |g: &mut Vec<(u32, isize)>, id, t, x, y, w, h, f| {
        add_child(g, hwnd, "STATIC", t, st_st, x, y, w, h, id, f);
    };
    st(&mut handles, ST_TITLE, "123 VPN", 24, 18, 300, 36, F_TITLE.load(Ordering::Relaxed));
    st(&mut handles, ST_STATUS, "—", 24, 66, 412, 40, F_BODY.load(Ordering::Relaxed));
    st(&mut handles, ST_SERVER, "—", 24, 110, 412, 22, F_BODY.load(Ordering::Relaxed));
    st(&mut handles, ST_TRAFFIC, "—", 24, 134, 412, 22, F_SMALL.load(Ordering::Relaxed));
    st(&mut handles, ST_SUBLBL, "—", 24, 272, 412, 20, F_SMALL.load(Ordering::Relaxed));
    st(&mut handles, ST_SUBRES, "", 24, 408, 412, 22, F_SMALL.load(Ordering::Relaxed));
    st(&mut handles, ST_ERR, "", 24, 434, 412, 40, F_SMALL.load(Ordering::Relaxed));
    st(&mut handles, ST_HINT, "—", 24, 556, 412, 18, F_SMALL.load(Ordering::Relaxed));
    st(&mut handles, ST_FOOT, "—", 24, 578, 412, 18, F_SMALL.load(Ordering::Relaxed));

    add_child(&mut handles, hwnd, "BUTTON", "—", st_btn | 0xB, 24, 168, 412, 52, BTN_CONNECT, F_BTN.load(Ordering::Relaxed));
    add_child(&mut handles, hwnd, "BUTTON", "—", st_btn | 0xB, 396, 20, 40, 30, BTN_LANG, F_SMALL.load(Ordering::Relaxed));
    add_child(&mut handles, hwnd, "BUTTON", "—", st_btn | 0xB, 24, 364, 412, 38, BTN_SAVE, F_BTN.load(Ordering::Relaxed));
    add_child(
        &mut handles, hwnd, "BUTTON", "—",
        st_btn | 0x3 /* BS_AUTOCHECKBOX */ | WS_TABSTOP, 24, 234, 412, 22, CHK_KILL,
        F_SMALL.load(Ordering::Relaxed),
    );
    add_child(
        &mut handles, hwnd, "EDIT", "—",
        st_edit | 0x4 /* ES_MULTILINE */ | 0x40 /* ES_AUTOVSCROLL */ | 0x00200000 /* WS_VSCROLL */ | 0x00100000 /* WS_BORDER */,
        24, 294, 412, 62, EDIT_SUB, F_BODY.load(Ordering::Relaxed),
    );

    handles
}

unsafe extern "system" fn wnd_proc(hwnd: HWND, msg: u32, w: WPARAM, l: LPARAM) -> LRESULT {
    match msg {
        WM_CREATE => {
            create_fonts();
            create_brushes();
            0
        }
        WM_APP_UI => {
            let msg = Box::from_raw(l as *mut UiMsg);
            if let Ok(mut g) = G.lock() {
                if let Some(g) = g.as_mut() {
                    match *msg {
                        UiMsg::Status(sv) => {
                            g.last = Some(sv);
                            // строка сервера/ошибки
                            set_text(g, ST_STATUS, &status_text(g.lang, &g.last));
                            if let Some(StatusView::Error { .. }) = g.last {
                                set_text(g, ST_SERVER, "");
                            } else {
                                set_text(g, ST_SERVER, tr(g.lang, "server_none"));
                            }
                        }
                        UiMsg::Sub(res) => {
                            match res {
                                backend::SubRes::Ok { count, best, ms } => {
                                    g.subres = 1;
                                    let ms = match ms {
                                        Some(v) => format!(" · {} {}", v, tr(g.lang, "ms")),
                                        None => String::new(),
                                    };
                                    set_text(
                                        g, ST_SUBRES,
                                        &format!("{}: {} · {} «{}»{}", tr(g.lang, "sub_ok"), count, tr(g.lang, "best"), best, ms),
                                    );
                                }
                                backend::SubRes::Err { key, detail } => {
                                    g.subres = 2;
                                    let d = if detail.is_empty() { String::new() } else { format!(" ({})", detail) };
                                    set_text(g, ST_SUBRES, &format!("{}{}", tr(g.lang, key), d));
                                }
                            }
                        }
                        UiMsg::Traffic { rx_speed, tx_speed, rx_total, tx_total } => {
                            if rx_speed == 0 && tx_speed == 0 && rx_total == 0 && tx_total == 0 {
                                set_text(g, ST_TRAFFIC, tr(g.lang, "traffic_idle"));
                            } else {
                                set_text(
                                    g, ST_TRAFFIC,
                                    &format!("↓ {} ↑ {} · всего {} / {}",
                                        i18n::fmt_speed(rx_speed as f64), i18n::fmt_speed(tx_speed as f64),
                                        i18n::fmt_total(rx_total), i18n::fmt_total(tx_total)),
                                );
                            }
                        }
                    }
                    InvalidateRect(hwnd, std::ptr::null(), 1);
                }
            }
            0
        }
        WM_COMMAND => {
            let id = (w & 0xffff) as u32;
            if let Ok(mut g) = G.lock() {
                if let Some(g) = g.as_mut() {
                    match id {
                        BTN_CONNECT => {
                            let cmd = if is_active(&g.last) { Cmd::Disconnect } else { Cmd::Connect };
                            let _ = g.tx.send(cmd);
                        }
                        BTN_LANG => {
                            g.lang = g.lang.toggle();
                            g.settings.lang = match g.lang { Lang::Ru => "ru".into(), Lang::En => "en".into() };
                            g.settings.save();
                            apply_texts(g);
                        }
                        BTN_SAVE => {
                            let mut buf = [0u16; 4096];
                            let n = GetWindowTextW(hwnd_of(g, EDIT_SUB), buf.as_mut_ptr(), buf.len() as i32);
                            g.settings.sub = String::from_utf16_lossy(&buf[..n.max(0) as usize]).trim().to_string();
                            g.settings.save();
                            g.subres = 0;
                            set_text(g, ST_SUBRES, tr(g.lang, "checking"));
                            let _ = g.tx.send(Cmd::CheckSub);
                        }
                        CHK_KILL => {
                            let state = SendMessageW(hwnd_of(g, CHK_KILL), 0x00F0 /* BM_GETCHECK */, 0, 0);
                            g.settings.kill_switch = state == 1; // BST_CHECKED
                            g.settings.save();
                        }
                        _ => {}
                    }
                }
            }
            0
        }
        WM_DRAWITEM => {
            let dis = l as *const DRAWITEMSTRUCT;
            if !dis.is_null() {
                paint_button(&*dis);
                return 1;
            }
            DefWindowProcW(hwnd, msg, w, l)
        }
        WM_CTLCOLORSTATIC => {
            let hdc = w as HDC;
            let id = GetDlgCtrlID(l as HWND) as u32;
            SetTextColor(hdc, static_color(id));
            SetBkMode(hdc, TRANSPARENT as i32);
            return BR_BG.load(Ordering::Relaxed) as LRESULT;
        }
        WM_CTLCOLOREDIT => {
            let hdc = w as HDC;
            SetTextColor(hdc, C_TEXT);
            SetBkMode(hdc, TRANSPARENT as i32);
            return BR_PANEL.load(Ordering::Relaxed) as LRESULT;
        }
        WM_CTLCOLORBTN | WM_CTLCOLORDLG => BR_BG.load(Ordering::Relaxed) as LRESULT,
        WM_CLOSE => {
            if let Ok(g) = G.lock() {
                if let Some(g) = g.as_ref() {
                    let _ = g.tx.send(Cmd::Quit);
                }
            }
            DestroyWindow(hwnd);
            0
        }
        WM_DESTROY => {
            PostQuitMessage(0);
            0
        }
        _ => DefWindowProcW(hwnd, msg, w, l),
    }
}

fn static_color(id: u32) -> COLORREF {
    match id {
        ST_TITLE | ST_STATUS | ST_SERVER => C_TEXT,
        ST_SUBRES => {
            let st = G.lock().ok().and_then(|g| g.as_ref().map(|g| g.subres)).unwrap_or(0);
            match st { 1 => C_OK, 2 => C_ERR, _ => C_DIM }
        }
        ST_ERR => C_ERR,
        _ => C_DIM,
    }
}

// DRAWITEMSTRUCT пришёл из UI::Controls (windows-sys 0.59).

unsafe fn paint_button(d: &DRAWITEMSTRUCT) {
    let (id, hdc, rc) = (d.CtlID, d.hDC, d.rcItem);
    let (lang, active) = G.lock().ok().and_then(|g| {
        g.as_ref().map(|g| (g.lang, is_active(&g.last)))
    }).unwrap_or((Lang::Ru, false));

    let disabled = (d.itemState & ODS_DISABLED) != 0;
    let selected = (d.itemState & ODS_SELECTED) != 0;
    let (bg, fg) = if disabled {
        (C_BTN, C_DIM)
    } else if selected {
        (C_BTN_SEL, C_TEXT)
    } else if id == BTN_CONNECT {
        (C_ACCENT, C_TEXT)
    } else {
        (C_BTN, C_TEXT)
    };

    let brush = CreateSolidBrush(bg);
    FillRect(hdc, &rc, brush);
    DeleteObject(brush as HGDIOBJ);
    let border = CreateSolidBrush(if id == BTN_CONNECT && !disabled { C_ACCENT } else { C_BTN_SEL });
    FrameRect(hdc, &rc, border);
    DeleteObject(border as HGDIOBJ);

    let text = match id {
        BTN_CONNECT => {
            if active { tr(lang, "stop").to_string() } else { tr(lang, "connect").to_string() }
        }
        BTN_SAVE => tr(lang, "save_check").to_string(),
        BTN_LANG => lang.label().to_string(),
        _ => String::new(),
    };
    if !text.is_empty() {
        SetTextColor(hdc, fg);
        SetBkMode(hdc, TRANSPARENT as i32);
        let f = F_BTN.load(Ordering::Relaxed);
        let old = SelectObject(hdc, f as HGDIOBJ);
        let mut r = rc;
        let t = pw(&text);
        DrawTextW(hdc, t.as_ptr(), -1, &mut r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        SelectObject(hdc, old);
    }
}

fn main() {
    unsafe { SetProcessDPIAware(); }
    unsafe {
        let hinst = GetModuleHandleW(std::ptr::null());
        let class_name = pw("123VPNWnd");
        let wc = WNDCLASSEXW {
            cbSize: std::mem::size_of::<WNDCLASSEXW>() as u32,
            style: 0,
            lpfnWndProc: Some(wnd_proc),
            cbClsExtra: 0,
            cbWndExtra: 0,
            hInstance: hinst,
            hIcon: std::ptr::null_mut(),
            hCursor: LoadCursorW(std::ptr::null_mut(), IDC_ARROW),
            hbrBackground: std::ptr::null_mut(),
            lpszMenuName: std::ptr::null(),
            lpszClassName: class_name.as_ptr(),
            hIconSm: std::ptr::null_mut(),
        };
        if RegisterClassExW(&wc) == 0 {
            return;
        }

        // клиент 460x604 → внешние размеры
        let mut rect = RECT { left: 0, top: 0, right: 460, bottom: 604 };
        let style = 0x00CF0000u32 /* WS_OVERLAPPEDWINDOW */ & !0x00040000 & !0x00010000 /* без THICKFRAME и MAXIMIZEBOX */;
        AdjustWindowRect(&mut rect, style, 0);
        let w = rect.right - rect.left;
        let h = rect.bottom - rect.top;

        let title = pw(&format!("{} v{}", tr(Lang::Ru, "title"), VERSION));
        let hwnd = CreateWindowExW(
            0, class_name.as_ptr(), title.as_ptr(), style | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, w, h,
            std::ptr::null_mut(), std::ptr::null_mut(), hinst, std::ptr::null_mut(),
        );
        if hwnd.is_null() {
            return;
        }
        H_MAIN.store(hwnd as isize, Ordering::Relaxed);

        // контролы (после WM_CREATE — чтобы шрифты были готовы)
        let handles = create_controls(hwnd);

        // настройки + бэкенд
        let settings = Settings::load(VERSION);
        let lang = Lang::from_str(&settings.lang);
        let (tx, _join) = backend::spawn(hwnd as isize, settings.clone());
        let mut gui = Gui {
            lang,
            handles,
            last: None,
            subres: 0,
            tx,
            settings,
        };
        apply_texts(&mut gui);
        *G.lock().unwrap() = Some(gui);

        ShowWindow(hwnd, SW_SHOW);

        let mut msg: MSG_ALIAS = std::mem::zeroed();
        while GetMessageW(&mut msg, std::ptr::null_mut(), 0, 0) > 0 {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

#[allow(non_camel_case_types)]
type MSG_ALIAS = windows_sys::Win32::UI::WindowsAndMessaging::MSG;
