//! Системный прокси Windows: HKCU\...\Internet Settings + WinINET refresh.
//! reg.exe вместо прямых вызовов реестра — меньше unsafe, reg есть везде.

use std::os::windows::process::CommandExt;
use std::process::Command;

const CREATE_NO_WINDOW: u32 = 0x0800_0000;
const KEY: &str = r"HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings";

fn reg(args: &[&str]) -> Result<(), String> {
    let out = Command::new("reg")
        .args(args)
        .creation_flags(CREATE_NO_WINDOW)
        .output()
        .map_err(|e| format!("reg: {e}"))?;
    if !out.status.success() {
        return Err(format!("reg {}: {}", args[0], String::from_utf8_lossy(&out.stderr).trim()));
    }
    Ok(())
}

/// Включить/выключить системный прокси и попросить WinINET обновиться.
pub fn set_system_proxy(on: bool, addr: &str) -> Result<(), String> {
    reg(&["add", KEY, "/v", "ProxyEnable", "/t", "REG_DWORD", "/d", if on { "1" } else { "0" }, "/f"])?;
    if on {
        reg(&["add", KEY, "/v", "ProxyServer", "/t", "REG_SZ", "/d", addr, "/f"])?;
        reg(&["add", KEY, "/v", "ProxyOverride", "/t", "REG_SZ", "/d", "<local>", "/f"])?;
    }
    refresh_wininet();
    Ok(())
}

/// Броадкаст WinINET: браузеры (Chrome/Edge) и системные компоненты
/// подхватывают прокси без перезапуска.
fn refresh_wininet() {
    use windows_sys::Win32::Networking::WinInet::{
        InternetSetOptionW, INTERNET_OPTION_REFRESH, INTERNET_OPTION_SETTINGS_CHANGED,
    };
    unsafe {
        InternetSetOptionW(std::ptr::null_mut(), INTERNET_OPTION_SETTINGS_CHANGED, std::ptr::null_mut(), 0);
        InternetSetOptionW(std::ptr::null_mut(), INTERNET_OPTION_REFRESH, std::ptr::null_mut(), 0);
    }
}
