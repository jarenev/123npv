//! Строки интерфейса RU/EN (как в Android-версии).

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Lang {
    Ru,
    En,
}

impl Lang {
    pub fn from_str(s: &str) -> Self {
        if s == "en" { Lang::En } else { Lang::Ru }
    }
    pub fn toggle(self) -> Self {
        match self { Lang::Ru => Lang::En, Lang::En => Lang::Ru }
    }
    pub fn label(self) -> &'static str {
        match self { Lang::Ru => "EN", Lang::En => "RU" }
    }
}

pub fn tr(lang: Lang, key: &str) -> &'static str {
    let ru = match key {
        "title" => "123 VPN",
        "connect" => "Подключиться",
        "disconnect" => "Отключить",
        "stop" => "Остановить",
        "idle" => "Не подключено",
        "fetching" => "Загружаем подписку…",
        "pinging" => "Проверяем серверы…",
        "starting" => "Подключение…",
        "connected" => "Подключено",
        "reconnecting" => "Переподключаемся…",
        "server_none" => "Сервер подбирается автоматически",
        "traffic_idle" => "Трафик: —",
        "killswitch" => "Kill Switch (авто-переподключение при обрыве)",
        "sub_label" => "Подписка или нода (vless://, vmess://, trojan://, ss://…)",
        "save_check" => "Сохранить и проверить",
        "checking" => "Проверяем…",
        "sub_ok" => "Готово: серверов",
        "sub_none" => "Серверы не найдены",
        "sub_empty" => "Сначала вставьте ссылку",
        "err_load" => "Подписка недоступна",
        "err_no_alive" => "Ни один сервер не отвечает",
        "err_lost" => "Соединение потеряно",
        "err_attempts" => "Не удалось подключиться после 3 попыток",
        "err_empty_sub" => "Сначала вставьте ссылку подписки",
        "ms" => "мс",
        "best" => "лучший",
        "version" => "версия",
        "hint_proxy" => "Режим: системный прокси — браузеры и большинство приложений идут через VPN",
        _ => "",
    };
    let en = match key {
        "title" => "123 VPN",
        "connect" => "Connect",
        "disconnect" => "Disconnect",
        "stop" => "Stop",
        "idle" => "Not connected",
        "fetching" => "Fetching subscription…",
        "pinging" => "Checking servers…",
        "starting" => "Connecting…",
        "connected" => "Connected",
        "reconnecting" => "Reconnecting…",
        "server_none" => "Server is picked automatically",
        "traffic_idle" => "Traffic: —",
        "killswitch" => "Kill Switch (auto-reconnect on failure)",
        "sub_label" => "Subscription or node (vless://, vmess://, trojan://, ss://…)",
        "save_check" => "Save and check",
        "checking" => "Checking…",
        "sub_ok" => "Done: servers",
        "sub_none" => "No servers found",
        "sub_empty" => "Add a subscription link first",
        "err_load" => "Subscription unavailable",
        "err_no_alive" => "No server responds",
        "err_lost" => "Connection lost",
        "err_attempts" => "Failed to connect after 3 attempts",
        "err_empty_sub" => "Add a subscription link first",
        "ms" => "ms",
        "best" => "best",
        "version" => "version",
        "hint_proxy" => "Mode: system proxy — browsers and most apps go through the VPN",
        _ => "",
    };
    match lang { Lang::Ru => ru, Lang::En => en }
}

/// «12.3 МБ/с», «456 КБ/с» и т.п.
pub fn fmt_speed(v: f64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    if v >= GB { format!("{:.2} ГБ/с", v / GB) }
    else if v >= MB { format!("{:.1} МБ/с", v / MB) }
    else if v >= KB { format!("{:.0} КБ/с", v / KB) }
    else { format!("{:.0} Б/с", v) }
}

/// «1.2 ГБ», «345 МБ» и т.п.
pub fn fmt_total(v: u64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    let v = v as f64;
    if v >= GB { format!("{:.2} ГБ", v / GB) }
    else if v >= MB { format!("{:.1} МБ", v / MB) }
    else if v >= KB { format!("{:.0} КБ", v / KB) }
    else { format!("{v} Б") }
}
