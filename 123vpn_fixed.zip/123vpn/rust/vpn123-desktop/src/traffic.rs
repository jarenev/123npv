//! Трафик: дельты байт по сетевым интерфейсам (GetIfTable2) — как счётчик
//! скорости в мобильных клиентах. Loopback исключаем.

use windows_sys::Win32::NetworkManagement::IpHelper::{
    FreeMibTable, GetIfTable2, IF_TYPE_SOFTWARE_LOOPBACK, MIB_IF_TABLE2,
};

/// Суммарные (rx, tx) байты всех активных физических интерфейсов.
pub fn interface_bytes() -> Option<(u64, u64)> {
    unsafe {
        let mut table: *mut MIB_IF_TABLE2 = std::ptr::null_mut();
        if GetIfTable2(&mut table) != 0 || table.is_null() {
            return None;
        }
        let mut rx = 0u64;
        let mut tx = 0u64;
        let n = (*table).NumEntries as usize;
        if n > 0 {
            let rows = std::slice::from_raw_parts((*table).Table.as_ptr(), n);
            for r in rows {
                // USB-модемы/физические NIC считаем; loopback и «мягкие» интерфейсы нет.
                // OperStatus == 1 — IfOperStatusUp.
                if r.Type == IF_TYPE_SOFTWARE_LOOPBACK || r.OperStatus != 1 {
                    continue;
                }
                rx += r.InOctets;
                tx += r.OutOctets;
            }
        }
        FreeMibTable(table as *mut std::ffi::c_void);
        Some((rx, tx))
    }
}
