//! Настройки: %APPDATA%\123vpn\settings.json (подписка, язык, Kill Switch).

use serde_json::Value;
use std::fs;
use std::path::PathBuf;

#[derive(Clone)]
pub struct Settings {
    pub sub: String,
    pub lang: String,
    pub kill_switch: bool,
    #[allow(dead_code)]
    pub version: String,
}

pub fn app_dir() -> PathBuf {
    let base = std::env::var("APPDATA").unwrap_or_else(|_| ".".into());
    let dir = PathBuf::from(base).join("123vpn");
    let _ = fs::create_dir_all(&dir);
    dir
}

impl Settings {
    pub fn load(version: &str) -> Self {
        let mut s = Settings { sub: String::new(), lang: "ru".into(), kill_switch: true, version: version.into() };
        if let Ok(text) = fs::read_to_string(app_dir().join("settings.json")) {
            if let Ok(v) = serde_json::from_str::<Value>(&text) {
                s.sub = v.get("sub").and_then(|x| x.as_str()).unwrap_or("").to_string();
                s.lang = v.get("lang").and_then(|x| x.as_str()).unwrap_or("ru").to_string();
                s.kill_switch = v.get("kill_switch").and_then(|x| x.as_bool()).unwrap_or(true);
            }
        }
        s
    }

    pub fn save(&self) {
        let v = serde_json::json!({
            "sub": self.sub,
            "lang": self.lang,
            "kill_switch": self.kill_switch,
        });
        if let Ok(text) = serde_json::to_string_pretty(&v) {
            let _ = fs::write(app_dir().join("settings.json"), text);
        }
    }
}
