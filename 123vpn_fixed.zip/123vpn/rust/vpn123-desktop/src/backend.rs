//! Бэкенд: подписка → парсинг → пинг → выбор → xray.exe → системный прокси →
//! мониторинг + failover + Kill Switch + трафик. Один поток, команды из UI.

use crate::settings::{app_dir, Settings};
use serde_json::Value;
use std::net::TcpStream;
use std::os::windows::process::CommandExt;
use std::process::{Child, Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{mpsc, Arc, Mutex};
use std::thread::JoinHandle;
use std::time::Duration;
use vpn123_core::links;
use vpn123_core::model::{CoreKind, Server};
use vpn123_core::{config_xray, ping, select};

pub const SOCKS_PORT: u16 = 2080;
pub const HTTP_PORT: u16 = 2081;
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

/// Команды UI → бэкенд.
pub enum Cmd {
    Connect,
    Disconnect,
    CheckSub,
    Quit,
}

/// Снимок состояния для UI.
#[derive(Clone)]
pub enum StatusView {
    Idle,
    Fetching,
    Pinging,
    Starting { name: String, core: &'static str, proto: String },
    Connected { name: String, core: &'static str, proto: String, ms: Option<u32>, fails: u32 },
    Reconnecting { name: String },
    Error { key: &'static str, detail: String },
}

pub enum SubRes {
    Ok { count: usize, best: String, ms: Option<u32> },
    Err { key: &'static str, detail: String },
}

pub enum UiMsg {
    Status(StatusView),
    Sub(SubRes),
    Traffic { rx_speed: u64, tx_speed: u64, rx_total: u64, tx_total: u64 },
}

/// Тот же источник, что и на Android: URL подписки или готовая нода/список нод.
fn load_subscription(src: &str) -> Result<String, String> {
    if links::is_node_text(src) {
        return Ok(src.to_string());
    }
    let agent = ureq::AgentBuilder::new()
        .timeout(Duration::from_secs(20))
        .user_agent("123VPN/1.0 (Windows)")
        .redirects(5)
        .build();
    let resp = agent.get(src).call().map_err(|e| format!("http: {e}"))?;
    resp.into_string().map_err(|e| format!("body: {e}"))
}

struct RunHandle {
    stop: Arc<AtomicBool>,
    child: Arc<Mutex<Option<Child>>>,
}

impl RunHandle {
    fn new() -> Self {
        RunHandle { stop: Arc::new(AtomicBool::new(false)), child: Arc::new(Mutex::new(None)) }
    }

    fn kill(&self) {
        self.stop.store(true, Ordering::SeqCst);
        if let Ok(mut slot) = self.child.lock() {
            if let Some(c) = slot.as_mut() {
                let _ = c.kill();
                let _ = c.wait();
            }
            *slot = None;
        }
    }
}

/// Запустить бэкенд-поток. Возвращает Sender для команд.
pub fn spawn(hwnd: isize, settings: Settings) -> (mpsc::Sender<Cmd>, JoinHandle<()>) {
    let (tx, rx) = mpsc::channel::<Cmd>();
    let hwnd = hwnd as isize;
    let handle = std::thread::Builder::new()
        .name("backend".into())
        .spawn(move || loop {
            match rx.recv() {
                Ok(Cmd::Quit) => break,
                Ok(Cmd::Connect) => run_connect(&rx, hwnd, &settings),
                Ok(Cmd::Disconnect) => {} // вне сессии не бывает
                Ok(Cmd::CheckSub) => run_check(hwnd, &settings),
                Err(_) => break,
            }
        })
        .expect("backend thread");
    (tx, handle)
}

fn post(hwnd: isize, msg: UiMsg) {
    unsafe { crate::post_ui(hwnd, msg) };
}

fn xray_path() -> std::path::PathBuf {
    let exe = std::env::current_exe().unwrap_or_default();
    exe.parent().unwrap_or(std::path::Path::new(".")).join("xray.exe")
}

/// Конфиг xray: SOCKS (для tun-подобных клиентов) + HTTP (для системного прокси).
fn build_config(srv: &Server, core: CoreKind) -> Value {
    let mut cfg = match core {
        CoreKind::Xray => config_xray::build(srv, SOCKS_PORT),
        CoreKind::Singbox => config_xray::build(srv, SOCKS_PORT), // на ПК бандлим только xray
    };
    if let Some(arr) = cfg["inbounds"].as_array_mut() {
        arr.push(serde_json::json!({
            "tag": "http-in",
            "listen": "127.0.0.1",
            "port": HTTP_PORT,
            "protocol": "http",
            "settings": {}
        }));
    }
    cfg
}

fn spawn_core(xray: &std::path::Path, config_path: &str, run: &RunHandle) -> Result<(), String> {
    let log = std::fs::File::create(app_dir().join("xray.log")).map_err(|e| format!("log: {e}"))?;
    let child = Command::new(xray)
        .args(["run", "-c", config_path])
        .stdout(Stdio::null())
        .stderr(Stdio::from(log))
        .creation_flags(CREATE_NO_WINDOW)
        .spawn()
        .map_err(|e| format!("spawn xray: {e}"))?;
    *run.child.lock().unwrap() = Some(child);
    Ok(())
}

fn wait_socks(stop: &AtomicBool) -> bool {
    for _ in 0..60 {
        if stop.load(Ordering::SeqCst) {
            return false;
        }
        if TcpStream::connect(("127.0.0.1", SOCKS_PORT)).is_ok() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(500));
    }
    false
}

fn core_alive(run: &RunHandle) -> bool {
    match run.child.lock() {
        Ok(mut slot) => match slot.as_mut() {
            Some(c) => matches!(c.try_wait(), Ok(None)), // процесс жив
            None => false,
        },
        Err(_) => false,
    }
}

/// Полный цикл подключения: подготовка → попытки → монитор.
fn run_connect(rx: &mpsc::Receiver<Cmd>, hwnd: isize, settings: &Settings) {
    let run = RunHandle::new();
    let result = connect_inner(&run, rx, hwnd, settings);
    // cleanup при любом исходе (кроме продолжающейся сессии — она внутри)
    if result.needs_cleanup {
        run.kill();
        let _ = crate::proxy::set_system_proxy(false, "");
    }
    if result.post_idle {
        post(hwnd, UiMsg::Status(StatusView::Idle));
    }
}

struct FlowOutcome {
    needs_cleanup: bool,
    post_idle: bool,
}

fn connect_inner(run: &RunHandle, rx: &mpsc::Receiver<Cmd>, hwnd: isize, settings: &Settings) -> FlowOutcome {
    // ── Подготовка ──
    if settings.sub.trim().is_empty() {
        post(hwnd, UiMsg::Status(StatusView::Error { key: "err_empty_sub", detail: String::new() }));
        return FlowOutcome { needs_cleanup: false, post_idle: true };
    }
    post(hwnd, UiMsg::Status(StatusView::Fetching));
    let body = match load_subscription(settings.sub.trim()) {
        Ok(b) => b,
        Err(e) => {
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_load", detail: e }));
            return FlowOutcome { needs_cleanup: false, post_idle: true };
        }
    };
    let servers = links::parse_subscription(&body);
    if servers.is_empty() {
        post(hwnd, UiMsg::Status(StatusView::Error { key: "err_no_alive", detail: "подписка пуста".into() }));
        return FlowOutcome { needs_cleanup: false, post_idle: true };
    }
    post(hwnd, UiMsg::Status(StatusView::Pinging));
    let measured = ping::ping_all(&servers);
    let alive_cnt = select::rank_alive(&measured).len();
    if alive_cnt == 0 {
        post(hwnd, UiMsg::Status(StatusView::Error { key: "err_no_alive", detail: String::new() }));
        return FlowOutcome { needs_cleanup: false, post_idle: true };
    }

    let xray = xray_path();
    if !xray.exists() {
        post(hwnd, UiMsg::Status(StatusView::Error { key: "err_load", detail: "xray.exe не найден рядом с 123vpn.exe".into() }));
        return FlowOutcome { needs_cleanup: false, post_idle: true };
    }

    let config_path = app_dir().join("config.json");
    let cfg_path_str = config_path.to_string_lossy().into_owned();

    // ── Попытки + Kill Switch (до 3 переподключений всей сессии) ──
    let mut tried: Vec<Server> = Vec::new();
    let mut session_fails = 0u32;
    let mut connected_once = false;

    loop {
        if run.stop.load(Ordering::SeqCst) {
            return FlowOutcome { needs_cleanup: true, post_idle: false };
        }
        let candidate = if tried.is_empty() { select::best(&measured) } else { select::next_best(&measured, &tried) };
        let Some(cand) = candidate else {
            if settings.kill_switch && connected_once && session_fails < 3 {
                session_fails += 1;
                tried.clear();
                post(hwnd, UiMsg::Status(StatusView::Reconnecting { name: String::new() }));
                continue;
            }
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_attempts", detail: String::new() }));
            return FlowOutcome { needs_cleanup: true, post_idle: true };
        };
        let srv = cand.server.clone();
        let latency = cand.latency_ms;
        tried.push(srv.clone());

        let core = match select::choose_core(&srv, true, false) {
            Some(c) => c,
            None => continue, // протокол недоступным ядром не поддерживается
        };
        let core_label = if matches!(core, CoreKind::Xray) { "xray" } else { "sing-box" };

        post(hwnd, UiMsg::Status(StatusView::Starting { name: srv.name.clone(), core: core_label, proto: srv.protocol.label().to_string() }));

        let cfg = build_config(&srv, core);
        if let Err(e) = std::fs::write(&config_path, serde_json::to_string_pretty(&cfg).unwrap_or_default()) {
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_load", detail: format!("config: {e}") }));
            return FlowOutcome { needs_cleanup: true, post_idle: true };
        }
        if let Err(e) = spawn_core(&xray, &cfg_path_str, run) {
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_load", detail: e }));
            return FlowOutcome { needs_cleanup: true, post_idle: true };
        }
        if !wait_socks(&run.stop) {
            run.kill();
            continue;
        }

        let addr = format!("127.0.0.1:{HTTP_PORT}");
        if let Err(e) = crate::proxy::set_system_proxy(true, &addr) {
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_load", detail: e }));
            return FlowOutcome { needs_cleanup: true, post_idle: true };
        }

        connected_once = true;
        post(hwnd, UiMsg::Status(StatusView::Connected { name: srv.name.clone(), core: core_label, proto: srv.protocol.label().to_string(), ms: latency, fails: 0 }));

        // ── Монитор: команды UI, живость ядра/сервера, трафик ──
        let mut srv_fail_streak = 0u32;
        let mut core_fail_streak = 0u32;
        let mut last_bytes: Option<(u64, u64)> = crate::traffic::interface_bytes();
        let mut totals = (0u64, 0u64);
        let mut tick = 0u32;

        let dropped = 'monitor: loop {
            for _ in 0..10 {
                std::thread::sleep(Duration::from_millis(100));
                if run.stop.load(Ordering::SeqCst) {
                    break 'monitor false;
                }
            }
            // команды UI во время сессии
            match rx.try_recv() {
                Ok(Cmd::Disconnect) => break 'monitor false,
                Ok(Cmd::Quit) => break 'monitor false,
                Ok(_) => {} // Connect/CheckSub вне сессии не обрабатываем
                Err(mpsc::TryRecvError::Disconnected) => break 'monitor false,
                Err(mpsc::TryRecvError::Empty) => {}
            }
            tick += 1;

            // живость ядра
            if !core_alive(run) {
                core_fail_streak += 1;
                if core_fail_streak >= 2 {
                    break 'monitor true;
                }
            } else {
                core_fail_streak = 0;
            }
            // живость сервера (раз в ~3 с)
            if tick % 3 == 0 && !ping::is_alive(&srv, Duration::from_secs(3)) {
                srv_fail_streak += 1;
                if srv_fail_streak >= 3 {
                    break 'monitor true;
                }
            } else if tick % 3 == 0 {
                srv_fail_streak = 0;
            }
            // трафик
            if let Some((rx_b, tx_b)) = crate::traffic::interface_bytes() {
                if let Some((prx, ptx)) = last_bytes {
                    let (drx, dtx) = (rx_b.saturating_sub(prx), tx_b.saturating_sub(ptx));
                    totals.0 += drx;
                    totals.1 += dtx;
                    post(hwnd, UiMsg::Traffic { rx_speed: drx, tx_speed: dtx, rx_total: totals.0, tx_total: totals.1 });
                }
                last_bytes = Some((rx_b, tx_b));
            }
        };

        run.kill();
        let _ = crate::proxy::set_system_proxy(false, "");

        if let Ok(Cmd::Disconnect) | Ok(Cmd::Quit) = rx.try_recv() {
            return FlowOutcome { needs_cleanup: false, post_idle: true };
        }
        if !dropped {
            // ручная остановка / выход
            return FlowOutcome { needs_cleanup: false, post_idle: true };
        }
        // внезапный обрыв
        if !settings.kill_switch || !connected_once {
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_lost", detail: String::new() }));
            return FlowOutcome { needs_cleanup: false, post_idle: true };
        }
        post(hwnd, UiMsg::Status(StatusView::Reconnecting { name: srv.name.clone() }));
        tried.clear();
        session_fails += 1;
        if session_fails >= 3 {
            post(hwnd, UiMsg::Status(StatusView::Error { key: "err_attempts", detail: String::new() }));
            return FlowOutcome { needs_cleanup: false, post_idle: true };
        }
    }
}

/// Проверка подписки без подключения (как «Сохранить и проверить» на Android).
fn run_check(hwnd: isize, settings: &Settings) {
    let sub = settings.sub.trim().to_string();
    if sub.is_empty() {
        post(hwnd, UiMsg::Sub(SubRes::Err { key: "sub_empty", detail: String::new() }));
        return;
    }
    let body = match load_subscription(&sub) {
        Ok(b) => b,
        Err(e) => {
            post(hwnd, UiMsg::Sub(SubRes::Err { key: "err_load", detail: e }));
            return;
        }
    };
    let servers = links::parse_subscription(&body);
    if servers.is_empty() {
        post(hwnd, UiMsg::Sub(SubRes::Err { key: "sub_none", detail: String::new() }));
        return;
    }
    let measured = ping::ping_all(&servers);
    let ranked = select::rank_alive(&measured);
    if ranked.is_empty() {
        post(hwnd, UiMsg::Sub(SubRes::Err { key: "err_no_alive", detail: String::new() }));
        return;
    }
    let best = &ranked[0];
    post(
        hwnd,
        UiMsg::Sub(SubRes::Ok { count: ranked.len(), best: best.server.name.clone(), ms: best.latency_ms }),
    );
}
