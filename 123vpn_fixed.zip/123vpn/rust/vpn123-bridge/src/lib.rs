//! 123 VPN bridge — cdylib, загружаемая Android-приложением как libvpn123.so.
//!
//! Слои:
//!  * jni.rs       — JNI-точки входа (Kotlin -> Rust)
//!  * supervisor.rs— машина состояний: подписка -> пинг -> выбор -> ядро -> failover
//!  * net.rs       — загрузка подписки (ureq + rustls)
//!  * tun.rs       — запуск tun2proxy на fd от VpnService

pub mod jni;
pub mod net;
pub mod state;
pub mod supervisor;
pub mod tun;

use std::io::Write;
use std::sync::OnceLock;

/// Путь к файлу лога супервизора (задаётся при запуске).
pub static LOG_PATH: OnceLock<String> = OnceLock::new();

pub fn log_line(msg: &str) {
    if let Some(p) = LOG_PATH.get() {
        if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(p) {
            let _ = writeln!(f, "{msg}");
        }
    }
}
