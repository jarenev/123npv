//! tun2proxy: превращает TUN-интерфейс (fd от VpnService) в SOCKS5-клиент
//! к локальному порту ядра (xray/sing-box).

use std::sync::atomic::AtomicBool;
use std::sync::Arc;

/// Запускает tun2proxy в отдельном потоке; возвращает токен остановки.
pub fn start(fd: i32, socks_port: u16, mtu: u16, tun_started: Arc<AtomicBool>) -> tun2proxy::CancellationToken {
    let token = tun2proxy::CancellationToken::new();
    let stop_token = token.clone();

    std::thread::Builder::new()
        .name("tun2proxy".into())
        .spawn(move || {
            let rt = match tokio::runtime::Builder::new_multi_thread()
                .worker_threads(2)
                .enable_all()
                .build()
            {
                Ok(rt) => rt,
                Err(e) => {
                    crate::state::push_event(format!("tokio runtime: {e}"));
                    return;
                }
            };
            rt.block_on(async move {
                let mut args = tun2proxy::Args::default();
                args.proxy = match format!("socks5://127.0.0.1:{socks_port}").try_into() {
                    Ok(p) => p,
                    Err(_) => {
                        crate::state::push_event("socks5 proxy params error");
                        return;
                    }
                };
                args.tun_fd = Some(fd);
                // fd владеет Kotlin (ParcelFileDescriptor) — не закрываем сами.
                args.close_fd_on_drop = Some(false);
                // DNS-запросы из TUN (UDP:53) гоним TCP'ом через прокси на 1.1.1.1:
                // получаем корректный remote-resolve без root и без UDP-петель.
                args.dns = tun2proxy::ArgDns::OverTcp;
                args.dns_addr = "1.1.1.1".parse().unwrap();
                args.mtu = mtu;
                args.udp_timeout = 60;
                args.ipv6_enabled = false;

                crate::state::push_event("tun2proxy запущен");
                if let Err(e) = tun2proxy::general_run_async(args, mtu, false, stop_token).await {
                    crate::state::push_event(format!("tun2proxy остановлен: {e}"));
                }
            });
            tun_started.store(false, std::sync::atomic::Ordering::Relaxed);
            crate::state::push_event("tun2proxy завершён");
        })
        .expect("spawn tun2proxy thread");

    token
}
