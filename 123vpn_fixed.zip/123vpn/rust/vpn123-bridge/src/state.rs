//! Общее состояние супервизора + JSON-статус для UI.

use serde::Serialize;
use std::collections::VecDeque;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

/// Снимок текущего сервера для UI.
#[derive(Debug, Clone, Serialize)]
pub struct ServerSnapshot {
    pub name: String,
    pub protocol: String,
    pub core: String,
    pub host: String,
    pub port: u16,
    pub latency_ms: Option<u32>,
    pub country: Option<String>,
    pub cc: Option<String>,
    pub flag: Option<String>,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
}

/// Полное состояние, читаемое из JNI.
#[derive(Debug)]
pub struct RunState {
    pub state: String,
    pub server: Option<ServerSnapshot>,
    pub servers_total: usize,
    pub servers_alive: usize,
    pub failover_count: u32,
    pub started_at: Option<std::time::Instant>,
    pub error: Option<String>,
    /// Последняя ошибка сессии: не сбрасывается stop_all, чтобы UI показал причину.
    pub last_error: Option<String>,
    pub events: VecDeque<String>,
}

impl RunState {
    fn new() -> Self {
        RunState {
            state: "idle".into(),
            server: None,
            servers_total: 0,
            servers_alive: 0,
            failover_count: 0,
            started_at: None,
            error: None,
            last_error: None,
            events: VecDeque::with_capacity(32),
        }
    }
}

static STATE: std::sync::LazyLock<Mutex<RunState>> =
    std::sync::LazyLock::new(|| Mutex::new(RunState::new()));

/// Дескриптор активного запуска (в Arc, чтобы жить вне блокировки).
pub struct RunHandle {
    pub stop: Arc<AtomicBool>,
    pub core_child: Arc<Mutex<Option<std::process::Child>>>,
    pub tun_token: Mutex<Option<tun2proxy::CancellationToken>>,
    pub tun_started: Arc<AtomicBool>,
}

pub static RUN: Mutex<Option<Arc<RunHandle>>> = Mutex::new(None);

pub fn update<F: FnOnce(&mut RunState)>(f: F) {
    if let Ok(mut st) = STATE.lock() {
        f(&mut st);
    }
}

pub fn set_state(state: &str) {
    update(|st| {
        st.state = state.into();
        if state == "error" || state == "idle" {
            if state == "idle" {
                st.started_at = None;
            }
        }
        if state == "connected" {
            st.last_error = None; // успешное подключение гасит прошлую ошибку
            if st.started_at.is_none() {
                st.started_at = Some(std::time::Instant::now());
            }
        }
    });
}

pub fn push_event(msg: impl Into<String>) {
    let msg = msg.into();
    crate::log_line(&format!("[event] {msg}"));
    update(|st| {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        st.events.push_back(format!("{now} {msg}"));
        while st.events.len() > 30 {
            st.events.pop_front();
        }
    });
}

/// Статус одним JSON (уходит в Kotlin -> JS).
pub fn status_json() -> String {
    let st = STATE.lock().unwrap();
    let uptime = st.started_at.map(|t| t.elapsed().as_secs());
    serde_json::json!({
        "state": st.state,
        "server": st.server,
        "servers_total": st.servers_total,
        "servers_alive": st.servers_alive,
        "failover_count": st.failover_count,
        "uptime_s": uptime,
        "error": st.error,
        "last_error": st.last_error,
        "events": st.events.iter().rev().take(8).collect::<Vec<_>>(),
    })
    .to_string()
}

pub fn fail(err: impl Into<String>) {
    let err = err.into();
    crate::log_line(&format!("[error] {err}"));
    update(|st| {
        st.state = "error".into();
        st.error = Some(err.clone());
        st.last_error = Some(err.clone());
    });
    push_event(format!("ошибка: {err}"));
}

pub fn is_stopped(stop: &Arc<AtomicBool>) -> bool {
    stop.load(Ordering::Relaxed)
}
