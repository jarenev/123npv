//! Супервизор: подписка → пинг → автоподбор → запуск ядра → failover.

use crate::state::{self, RunHandle, ServerSnapshot, RUN};
use std::net::TcpStream;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, AtomicU16, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use vpn123_core::model::{CoreKind, MeasuredServer, Server};
use vpn123_core::{config_singbox, config_xray, geo, links, pin, ping, select};

pub struct SupCtx {
    pub sub_url: String,
    pub config_dir: String,
    pub bin_dir: String,
    pub work_dir: String,
    pub socks_port: u16,
}

const SOCKS_WAIT_POLLS: u32 = 50; // 50 * 300ms = 15s
const CORE_CHECK_STEP: Duration = Duration::from_secs(2); // как часто проверяем, жив ли процесс ядра
const STABLE_AFTER: Duration = Duration::from_secs(60); // дольше — соединение считается стабильным
const MONITOR_INTERVAL: Duration = Duration::from_secs(10);
const MONITOR_FAILS_TO_SWITCH: u32 = 2;
const TUN_WAIT_POLLS: u32 = 600; // 600 * 200ms = 120s
const MAX_ATTEMPTS: u32 = 6;     // предел перебора серверов, дальше — error

static SUPERVISOR_SOCKS_PORT: AtomicU16 = AtomicU16::new(1080);

pub fn start_core(ctx: SupCtx) -> bool {
    {
        let run = RUN.lock().unwrap();
        if run.is_some() {
            return true; // уже работает
        }
    }

    let handle = Arc::new(RunHandle {
        stop: Arc::new(AtomicBool::new(false)),
        core_child: Arc::new(Mutex::new(None)),
        tun_token: Mutex::new(None),
        tun_started: Arc::new(AtomicBool::new(false)),
    });
    *RUN.lock().unwrap() = Some(Arc::clone(&handle));

    // Состояние выставляем синхронно, ДО запуска потока: Kotlin опрашивает статус
    // сразу после startCore() и иначе мог прочитать устаревшие idle/error.
    state::update(|st| {
        st.state = "fetching".into();
        st.error = None;
        // Прошлая причина неактуальна; иначе Bridge.status() показал бы её поверх
        // новой ошибки Kotlin-стороны (establish_failed и т.п.).
        st.last_error = None;
        st.failover_count = 0;
        st.servers_total = 0;
        st.servers_alive = 0;
        st.server = None;
        st.started_at = None;
    });

    crate::LOG_PATH
        .set(format!("{}/supervisor.log", ctx.work_dir))
        .ok();

    std::thread::Builder::new()
        .name("supervisor".into())
        .spawn(move || run_supervisor(ctx, handle))
        .expect("spawn supervisor");
    true
}

pub fn start_tun(fd: i32, mtu: u16) -> bool {
    let handle = {
        let run = RUN.lock().unwrap();
        match run.as_ref() {
            Some(h) => Arc::clone(h),
            None => return false,
        }
    };
    let port = SUPERVISOR_SOCKS_PORT.load(Ordering::Relaxed);
    let token = crate::tun::start(fd, port, mtu, Arc::clone(&handle.tun_started));
    *handle.tun_token.lock().unwrap() = Some(token);
    handle.tun_started.store(true, Ordering::Relaxed);
    true
}

pub fn stop_all() {
    let handle = RUN.lock().unwrap().take();
    if let Some(h) = handle {
        h.stop.store(true, Ordering::Relaxed);
        if let Ok(mut guard) = h.core_child.lock() {
            if let Some(mut child) = guard.take() {
                let _ = child.kill();
                let _ = child.wait();
            }
        }
        if let Some(t) = h.tun_token.lock().unwrap().take() {
            t.cancel();
        }
    }
    state::update(|st| {
        st.state = "idle".into();
        st.server = None;
        st.error = None;
        st.started_at = None;
    });
    state::push_event("остановлено");
}

// ────────────────────────── внутренности ──────────────────────────

fn bin_path(bin_dir: &str, core: CoreKind) -> String {
    format!("{}/{}", bin_dir, core.lib_name())
}

fn snapshot_of(server: &Server, core: CoreKind, latency: Option<u32>) -> ServerSnapshot {
    let g = geo::detect(&server.name);
    ServerSnapshot {
        name: server.name.clone(),
        protocol: server.protocol.label().into(),
        core: core.label().into(),
        host: server.host.clone(),
        port: server.port,
        latency_ms: latency,
        country: g.as_ref().map(|g| g.name_ru.clone()),
        cc: g.as_ref().map(|g| g.cc.clone()),
        flag: g.as_ref().map(|g| geo::flag_emoji(&g.cc)),
        lat: g.as_ref().map(|g| g.lat),
        lon: g.as_ref().map(|g| g.lon),
    }
}

fn spawn_core(ctx: &SupCtx, core: CoreKind, config_path: &str, handle: &RunHandle) -> Result<(), String> {
    let path = bin_path(&ctx.bin_dir, core);
    let log_file = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(format!("{}/core.log", ctx.work_dir))
        .map_err(|e| format!("log: {e}"))?;
    let log_err = log_file.try_clone().map_err(|e| format!("log: {e}"))?;

    let child = Command::new(&path)
        .args(core.run_args(config_path))
        .current_dir(&ctx.work_dir)
        // На Android нет /tmp: Go-ядра (xray/sing-box) без доступного TMPDIR
        // падают при старте. HOME и каталог ассетов тоже переносим в filesDir.
        .env("TMPDIR", &ctx.work_dir)
        .env("HOME", &ctx.work_dir)
        .env("XRAY_LOCATION_ASSET", &ctx.work_dir)
        .env("SINGBOX_WORK_DIRECTORY", &ctx.work_dir)
        .stdout(Stdio::from(log_file))
        .stderr(Stdio::from(log_err))
        .spawn()
        .map_err(|e| format!("exec {}: {e}", core.lib_name()))?;

    *handle.core_child.lock().unwrap() = Some(child);
    Ok(())
}

fn wait_socks_ready(port: u16, handle: &RunHandle) -> bool {
    for _ in 0..SOCKS_WAIT_POLLS {
        if handle.stop.load(Ordering::Relaxed) {
            return false;
        }
        // Ядро умерло раньше времени?
        if let Ok(mut guard) = handle.core_child.lock() {
            if let Some(child) = guard.as_mut() {
                match child.try_wait() {
                    Ok(Some(status)) => {
                        state::push_event(format!("ядро завершилось: {status}"));
                        *guard = None;
                        return false;
                    }
                    Ok(None) => {}
                    Err(_) => {}
                }
            }
        }
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(300));
    }
    false
}

/// true, если процесс ядра уже завершился (или его нет).
fn core_exited(handle: &RunHandle) -> bool {
    match handle.core_child.lock() {
        Ok(mut guard) => match guard.as_mut() {
            Some(child) => match child.try_wait() {
                Ok(Some(_)) => {
                    *guard = None;
                    true
                }
                Ok(None) => false,
                Err(_) => false,
            },
            None => !handle.stop.load(Ordering::Relaxed),
        },
        Err(_) => false,
    }
}

fn kill_core(handle: &RunHandle) {
    if let Ok(mut guard) = handle.core_child.lock() {
        if let Some(mut child) = guard.take() {
            let _ = child.kill();
            let _ = child.wait();
        }
    }
}

/// Спит с проверкой stop-флага; true — прошло без остановки.
fn sleep_interruptible(total: Duration, stop: &Arc<AtomicBool>) -> bool {
    let mut waited = Duration::ZERO;
    while waited < total {
        if stop.load(Ordering::Relaxed) {
            return false;
        }
        let step = Duration::from_millis(400).min(total - waited);
        std::thread::sleep(step);
        waited += step;
    }
    !stop.load(Ordering::Relaxed)
}

fn run_supervisor(ctx: SupCtx, handle: Arc<RunHandle>) {
    // Логи прошлой сессии не нужны — обнуляем, чтобы файлы не росли бесконечно.
    let _ = std::fs::write(format!("{}/core.log", ctx.work_dir), b"");
    let _ = std::fs::write(format!("{}/supervisor.log", ctx.work_dir), b"");
    SUPERVISOR_SOCKS_PORT.store(ctx.socks_port, Ordering::Relaxed);
    state::push_event("загрузка подписки…");

    // ── 1. Подписка ──
    let body = match crate::net::load_subscription(&ctx.sub_url) {
        Ok(b) => b,
        Err(e) => {
            state::fail(format!("подписка недоступна ({e})"));
            finalize_stop();
            return;
        }
    };
    let servers = links::parse_subscription(&body);
    state::update(|st| st.servers_total = servers.len());
    if servers.is_empty() {
        state::fail("в подписке не найдено ни одного сервера");
        finalize_stop();
        return;
    }
    state::push_event(format!("серверов в подписке: {}", servers.len()));

    // ── 2. Пинг ──
    state::set_state("pinging");
    state::push_event("проверка пинга серверов…");
    let mut measured: Vec<MeasuredServer> = ping::ping_all(&servers);
    let alive = select::rank_alive(&measured).len();
    state::update(|st| st.servers_alive = alive);
    if alive == 0 {
        state::fail("ни один сервер не отвечает");
        finalize_stop();
        return;
    }
    state::push_event(format!("живых серверов: {alive}"));

    let has_xray = std::path::Path::new(&bin_path(&ctx.bin_dir, CoreKind::Xray)).exists();
    let has_singbox = std::path::Path::new(&bin_path(&ctx.bin_dir, CoreKind::Singbox)).exists();
    state::push_event(format!("ядра доступны: xray={has_xray} sing-box={has_singbox}"));

    // ── 3. Конвейер попыток (автоподбор + failover) ──
    let mut tried: Vec<Server> = Vec::new();
    let mut attempt: u32 = 0;
    let mut connected_once = false;

    loop {
        if handle.stop.load(Ordering::Relaxed) {
            break;
        }
        if attempt >= MAX_ATTEMPTS {
            state::fail(format!("не удалось подключиться после {MAX_ATTEMPTS} попыток"));
            break;
        }

        // Выбор кандидата: лучший живой, не из уже пробованных.
        let candidate = if attempt == 0 {
            select::best(&measured)
        } else {
            select::next_best(&measured, &tried)
        };
        let Some(cand) = candidate else {
            state::fail("не осталось доступных серверов");
            break;
        };
        let srv = cand.server.clone();
        let latency = cand.latency_ms;
        tried.push(srv.clone());

        let Some(core) = select::choose_core(&srv, has_xray, has_singbox) else {
            state::push_event(format!(
                "{}: протокол {} не поддерживается доступными ядрами",
                srv.name,
                srv.protocol.label()
            ));
            attempt += 1;
            continue;
        };

        state::update(|st| {
            st.server = Some(snapshot_of(&srv, core, latency));
            st.state = "starting".into();
        });
        state::push_event(format!(
            "подключение к «{}» ({}, {}, {} мс)",
            srv.name,
            core.label(),
            srv.protocol.label(),
            latency.unwrap_or(0)
        ));

        // Домен сервера резолвим сами: Go-ядра на Android не имеют /etc/resolv.conf
        // и не могут разрешить его самостоятельно (см. vpn123_core::pin).
        let cfg_srv = match ping::resolve_ip(&srv.host, srv.port) {
            Some(ip) => pin::pin_ip(&srv, ip),
            None => {
                state::push_event(format!("«{}»: не удалось разрешить адрес {}", srv.name, srv.host));
                attempt += 1;
                continue;
            }
        };

        // ── Конфиг ──
        let config_path = format!("{}/config.json", ctx.config_dir);
        let cfg = match core {
            CoreKind::Xray => config_xray::build(&cfg_srv, ctx.socks_port),
            CoreKind::Singbox => config_singbox::build(&cfg_srv, ctx.socks_port),
        };
        if let Err(e) = std::fs::write(&config_path, serde_json::to_string_pretty(&cfg).unwrap_or_default()) {
            state::fail(format!("запись конфига: {e}"));
            break;
        }

        if let Err(e) = spawn_core(&ctx, core, &config_path, &handle) {
            state::push_event(format!("запуск ядра не удался: {e}"));
            attempt += 1;
            continue;
        }

        if !wait_socks_ready(ctx.socks_port, &handle) {
            if handle.stop.load(Ordering::Relaxed) {
                break;
            }
            kill_core(&handle);
            state::push_event(format!("«{}» не поднялся, пробуем другой сервер", srv.name));
            attempt += 1;
            continue;
        }

        // ── 4. TUN: при первом коннекте ждём, пока Kotlin отдаст fd ──
        if !handle.tun_started.load(Ordering::Relaxed) {
            state::set_state("ready_for_tun");
            state::push_event("ядро готово, поднимаем туннель…");
            let mut ok = false;
            for _ in 0..TUN_WAIT_POLLS {
                if handle.stop.load(Ordering::Relaxed) {
                    ok = false;
                    break;
                }
                if handle.tun_started.load(Ordering::Relaxed) {
                    ok = true;
                    break;
                }
                std::thread::sleep(Duration::from_millis(200));
            }
            if !ok {
                if handle.stop.load(Ordering::Relaxed) {
                    break;
                }
                state::fail("туннель не был поднят приложением");
                break;
            }
        }

        state::set_state("connected");
        if !connected_once {
            connected_once = true;
        } else {
            state::update(|st| st.failover_count += 1);
        }
        state::push_event(format!("подключено: {} ({} мс)", srv.name, latency.unwrap_or(0)));

        // ── 5. Монитор живости + failover ──
        // Каждые CORE_CHECK_STEP проверяем, что процесс ядра жив (мгновенная реакция
        // на падение), а раз в MONITOR_INTERVAL — доступность сервера.
        let connected_at = Instant::now();
        let mut last_probe = Instant::now();
        let mut fail_streak: u32 = 0;
        'monitor: loop {
            if !sleep_interruptible(CORE_CHECK_STEP, &handle.stop) {
                break 'monitor;
            }
            if core_exited(&handle) {
                state::push_event(format!("ядро завершилось, переключаемся с «{}»", srv.name));
                state::set_state("reconnecting");
                attempt += 1;
                break 'monitor;
            }
            if last_probe.elapsed() < MONITOR_INTERVAL {
                continue;
            }
            last_probe = Instant::now();
            if ping::is_alive(&srv, Duration::from_secs(3)) {
                fail_streak = 0;
                continue;
            }
            fail_streak += 1;
            state::push_event(format!(
                "сервер «{}» не отвечает ({}/{})",
                srv.name, fail_streak, MONITOR_FAILS_TO_SWITCH
            ));
            if fail_streak >= MONITOR_FAILS_TO_SWITCH {
                state::set_state("reconnecting");
                kill_core(&handle);
                attempt += 1;
                break 'monitor;
            }
        }
        if handle.stop.load(Ordering::Relaxed) {
            break;
        }

        // Соединение жило долго — сбой «новый»: счётчик попыток и список
        // пробованных серверов обнуляем, иначе за долгую сессию лимит выбирается.
        if connected_at.elapsed() >= STABLE_AFTER {
            attempt = 0;
            tried.clear();
        }
        // Пинг устарел: перемеряем, чтобы не выбрать только что упавший сервер.
        measured = ping::ping_all(&servers);
        let alive_now = select::rank_alive(&measured).len();
        state::update(|st| st.servers_alive = alive_now);
    }

    kill_core(&handle);

    // Сессия закончилась сама (ошибка / серверы исчерпаны), а не по stop().
    // Если туннеля ещё нет — освобождаем RUN, иначе следующий start_core()
    // решит, что «уже работает», и повторное подключение невозможно.
    // Если туннель поднят — RUN оставляем: его снимет stop() из Kotlin, который
    // заодно остановит tun2proxy (токен лежит в handle).
    if !handle.stop.load(Ordering::Relaxed) && handle.tun_token.lock().unwrap().is_none() {
        let mut run = RUN.lock().unwrap();
        if run.as_ref().map(|h| Arc::ptr_eq(h, &handle)).unwrap_or(false) {
            *run = None;
        }
    }
}

fn finalize_stop() {
    // Ошибка на этапе подготовки: останавливаем всё, чтобы UI вернулся в idle.
    stop_all();
}
