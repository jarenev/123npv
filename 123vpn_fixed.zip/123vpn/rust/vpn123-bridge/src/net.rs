//! Источник серверов: URL подписки (HTTPS через ureq + rustls) или готовый
//! текст с нодой/нодами — одиночные ссылки скачивать не нужно.

use vpn123_core::links;

/// Подготовить тело: если это нода/список нод (vless://, vmess://, ss://, …),
/// вернуть текст как есть, иначе скачать по HTTPS.
pub fn load_subscription(src: &str) -> Result<String, String> {
    if links::is_node_text(src) {
        Ok(src.to_string())
    } else {
        fetch(src)
    }
}

pub fn fetch(url: &str) -> Result<String, String> {
    let agent = ureq::AgentBuilder::new()
        .timeout(std::time::Duration::from_secs(20))
        .user_agent("123VPN/1.0 (Android)")
        .redirects(5)
        .build();
    let resp = agent.get(url).call().map_err(|e| format!("http: {e}"))?;
    // Подписки бывают большими; ограничение ureq.into_string() — 10 МБ, достаточно.
    resp.into_string().map_err(|e| format!("body: {e}"))
}

#[cfg(test)]
mod live_tests {
    use super::fetch;
    use vpn123_core::{config_singbox, config_xray, links, ping, select};

    /// Живая проверка всего пути приложения на реальной подписке:
    /// VPN123_TEST_URL=https://… cargo test -- --ignored --nocapture
    /// Без переменной тест молча завершается (в обычных прогонах не мешает).
    #[test]
    #[ignore]
    fn live_subscription_end_to_end() {
        let url = match std::env::var("VPN123_TEST_URL") {
            Ok(u) if !u.is_empty() => u,
            _ => return,
        };

        // 1. Загрузка — тем же клиентом, что и в приложении (ureq + rustls).
        let body = fetch(&url).expect("загрузка подписки");
        println!("=== 1. Загрузка: {} байт", body.len());

        // 2. Парсинг.
        let servers = links::parse_subscription(&body);
        println!("=== 2. Серверов распознано: {}", servers.len());
        assert!(!servers.is_empty(), "парсер не нашёл серверов в теле подписки!");
        for s in &servers {
            let tr = s
                .params
                .transport
                .as_ref()
                .map(|t| format!("{t:?}"))
                .unwrap_or_else(|| "tcp".into());
            let reality = s
                .params
                .tls
                .as_ref()
                .map(|t| t.reality_pub.is_some())
                .unwrap_or(false);
            println!("    {:?} {}:{} transport={} reality={}", s.protocol, s.host, s.port, tr, reality);
        }

        // 3. Пинг.
        let measured = ping::ping_all(&servers);
        for m in &measured {
            println!("=== 3. пинг {}:{} = {:?} мс", m.server.host, m.server.port, m.latency_ms);
        }
        let ranked = select::rank_alive(&measured);
        println!("=== живых нод: {}", ranked.len());
        assert!(!ranked.is_empty(), "все ноды недоступны (сеть?)");

        // 4. Выбор ядра и конфиги для лучшей ноды.
        let best = &ranked[0].server;
        println!("=== 4. лучшая: {}:{} {:?}", best.host, best.port, best.protocol);
        println!("    choose_core(has both): {:?}", select::choose_core(best, true, true));
        let cx = config_xray::build(best, 10808);
        let cs = config_singbox::build(best, 10808);
        println!("=== xray конфиг ===\n{}", serde_json::to_string_pretty(&cx).unwrap());
        println!("=== sing-box конфиг ===\n{}", serde_json::to_string_pretty(&cs).unwrap());

        // 5. Ключевые проверки: reality дошёл до конфига.
        let out = &cx["outbounds"][0];
        assert_eq!(out["protocol"], "vless");
        let ss = &out["streamSettings"];
        assert_eq!(ss["security"], "reality", "security должен быть reality");
        assert!(
            ss["realitySettings"]["publicKey"].as_str().unwrap_or("").len() > 10,
            "publicKey пуст"
        );
        println!("=== 5. OK: reality в конфиге ===");
    }
}
