//! JNI-точки входа: имена должны совпадать со space.jarenev.vpn123.Vpn123Jni.

use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jint, jstring};
use jni::JNIEnv;
use vpn123_core::links;

fn jstr(env: &mut JNIEnv, s: &JString) -> String {
    env.get_string(s)
        .map(|x| x.to_string_lossy().into_owned())
        .unwrap_or_default()
}

fn jout(env: &mut JNIEnv, s: &str) -> jstring {
    match env.new_string(s) {
        Ok(js) => js.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub unsafe extern "system" fn Java_space_jarenev_vpn123_Vpn123Jni_startCore<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    sub_url: JString<'local>,
    config_dir: JString<'local>,
    bin_dir: JString<'local>,
    work_dir: JString<'local>,
    socks_port: jint,
) -> jboolean {
    let sub = jstr(&mut env, &sub_url);
    let config = jstr(&mut env, &config_dir);
    let bins = jstr(&mut env, &bin_dir);
    let work = jstr(&mut env, &work_dir);
    let ctx = crate::supervisor::SupCtx {
        sub_url: sub,
        config_dir: config,
        bin_dir: bins,
        work_dir: work,
        socks_port: socks_port as u16,
    };
    crate::supervisor::start_core(ctx) as jboolean
}

#[no_mangle]
pub unsafe extern "system" fn Java_space_jarenev_vpn123_Vpn123Jni_startTun<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    fd: jint,
) -> jboolean {
    // MTU согласован с Vpn123Service.MTU (1500).
    crate::supervisor::start_tun(fd, 1500) as jboolean
}

#[no_mangle]
pub unsafe extern "system" fn Java_space_jarenev_vpn123_Vpn123Jni_stop<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) {
    crate::supervisor::stop_all();
}

#[no_mangle]
pub unsafe extern "system" fn Java_space_jarenev_vpn123_Vpn123Jni_status<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    jout(&mut env, &crate::state::status_json())
}

#[no_mangle]
pub unsafe extern "system" fn Java_space_jarenev_vpn123_Vpn123Jni_refresh<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    sub_url: JString<'local>,
) -> jstring {
    let sub = jstr(&mut env, &sub_url);
    let out = refresh_impl(&sub);
    jout(&mut env, &out)
}

/// Проверка подписки без запуска VPN: загрузка, парсинг, пинг.
fn refresh_impl(sub_url: &str) -> String {
    use serde_json::json;
    if sub_url.trim().is_empty() {
        return json!({"ok": false, "error": "empty_sub", "count": 0}).to_string();
    }
    let body = match crate::net::load_subscription(sub_url) {
        Ok(b) => b,
        Err(e) => return json!({"ok": false, "error": format!("{e}"), "count": 0}).to_string(),
    };
    let servers = links::parse_subscription(&body);
    let measured = vpn123_core::ping::ping_all(&servers);
    let ranked = vpn123_core::select::rank_alive(&measured);

    let list: Vec<serde_json::Value> = ranked
        .iter()
        .take(200)
        .map(|m| {
            let g = vpn123_core::geo::detect(&m.server.name);
            json!({
                "name": m.server.name,
                "protocol": m.server.protocol.label(),
                "core": m.server.protocol.preferred_core().label(),
                "ms": m.latency_ms,
                "country": g.as_ref().map(|g| g.name_ru.clone()),
                "cc": g.as_ref().map(|g| g.cc.clone()),
                "flag": g.as_ref().map(|g| vpn123_core::geo::flag_emoji(&g.cc)),
            })
        })
        .collect();

    json!({
        "ok": true,
        "count": ranked.len(),
        "total": servers.len(),
        "servers": list,
    })
    .to_string()
}
