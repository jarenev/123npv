//! Интеграционный тест супервизора на хосте с настоящим xray.
//! Запуск: VPN123_TEST_XRAY=/путь/к/xray cargo test -p vpn123-bridge --test supervisor_flow -- --nocapture
//! Без переменной окружения тест молча пропускается.
//!
//! Проверяет цепочку: подписка (одиночная нода с доменом localhost) → пинг →
//! закрепление IP → запуск ядра → ready_for_tun → connected → реальный HTTP через
//! SOCKS → смерть ядра → автоматический failover → stop().

use std::io::Write;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};
use vpn123::state::{status_json, RUN};
use vpn123::supervisor::{start_core, stop_all, SupCtx};

fn state() -> serde_json::Value {
    serde_json::from_str(&status_json()).unwrap()
}

fn wait_for(what: &str, timeout: Duration, mut pred: impl FnMut(&serde_json::Value) -> bool) {
    let t0 = Instant::now();
    loop {
        let s = state();
        if pred(&s) {
            return;
        }
        if t0.elapsed() > timeout {
            panic!("таймаут ожидания «{what}»; статус: {s}");
        }
        std::thread::sleep(Duration::from_millis(200));
    }
}

fn http_via_socks(port: u16, target: &str) -> String {
    let out = Command::new("curl")
        .args(["-sS", "-m", "8", "--socks5-hostname", &format!("127.0.0.1:{port}"), target])
        .output()
        .expect("curl");
    String::from_utf8_lossy(&out.stdout).into_owned()
}

struct Guard(Vec<Child>);
impl Drop for Guard {
    fn drop(&mut self) {
        for c in &mut self.0 {
            let _ = c.kill();
            let _ = c.wait();
        }
    }
}

#[test]
fn full_supervisor_flow_with_real_xray() {
    let Ok(xray) = std::env::var("VPN123_TEST_XRAY") else {
        eprintln!("VPN123_TEST_XRAY не задан — тест пропущен");
        return;
    };
    let dir = std::env::temp_dir().join(format!("vpn123-flow-{}", std::process::id()));
    let bins = dir.join("bin");
    std::fs::create_dir_all(&bins).unwrap();
    std::os::unix::fs::symlink(&xray, bins.join("libxray.so")).unwrap();
    let mut guard = Guard(Vec::new());

    // «Удалённый» сервер: xray vless + HTTP-цель
    let uuid = "11111111-1111-1111-1111-111111111111";
    let srv_cfg = serde_json::json!({
        "inbounds": [{"listen":"127.0.0.1","port":22001,"protocol":"vless",
            "settings":{"clients":[{"id":uuid}],"decryption":"none"},"streamSettings":{"network":"tcp"}}],
        "outbounds": [{"protocol":"freedom","settings":{"finalRules":[{"action":"allow"}]}}]
    });
    let srv_path = dir.join("server.json");
    std::fs::write(&srv_path, srv_cfg.to_string()).unwrap();
    guard.0.push(
        Command::new(&xray).args(["run", "-c"]).arg(&srv_path)
            .stdout(Stdio::null()).stderr(Stdio::null()).spawn().unwrap(),
    );
    let www = dir.join("www");
    std::fs::create_dir_all(&www).unwrap();
    std::fs::File::create(www.join("index.html")).unwrap().write_all(b"HELLO-FROM-TARGET").unwrap();
    guard.0.push(
        Command::new("python3").args(["-m", "http.server", "22100", "--bind", "127.0.0.1"])
            .current_dir(&www).stdout(Stdio::null()).stderr(Stdio::null()).spawn().unwrap(),
    );
    std::thread::sleep(Duration::from_millis(1500));

    // Нода с ДОМЕНОМ localhost — проверяет закрепление IP
    let sub = format!("vless://{uuid}@localhost:22001?encryption=none&type=tcp#flow-test");
    const SOCKS: u16 = 22080;
    let ctx = SupCtx {
        sub_url: sub,
        config_dir: dir.to_string_lossy().into(),
        bin_dir: bins.to_string_lossy().into(),
        work_dir: dir.to_string_lossy().into(),
        socks_port: SOCKS,
    };

    assert!(start_core(ctx));
    // Гонка из прошлой версии: сразу после start_core статус не должен быть idle/error
    let first = state()["state"].as_str().unwrap().to_string();
    assert!(
        !matches!(first.as_str(), "idle" | "error"),
        "сразу после start_core состояние = {first}"
    );

    wait_for("ready_for_tun", Duration::from_secs(40), |s| s["state"] == "ready_for_tun");
    assert_eq!(state()["server"]["core"], "xray");

    // Имитируем Kotlin: «TUN поднят»
    RUN.lock().unwrap().as_ref().unwrap().tun_started.store(true, std::sync::atomic::Ordering::Relaxed);
    wait_for("connected", Duration::from_secs(10), |s| s["state"] == "connected");

    assert_eq!(http_via_socks(SOCKS, "http://127.0.0.1:22100/"), "HELLO-FROM-TARGET", "трафик через ядро");

    // Убиваем процесс ядра → супервизор должен сам переподключиться
    let pid = RUN.lock().unwrap().as_ref().unwrap().core_child.lock().unwrap().as_ref().unwrap().id();
    Command::new("kill").arg(pid.to_string()).status().unwrap();
    wait_for("failover", Duration::from_secs(45), |s| {
        s["state"] == "connected" && s["failover_count"].as_u64().unwrap_or(0) >= 1
    });
    assert_eq!(http_via_socks(SOCKS, "http://127.0.0.1:22100/"), "HELLO-FROM-TARGET", "трафик после failover");

    stop_all();
    assert_eq!(state()["state"], "idle");
    assert!(RUN.lock().unwrap().is_none());
    let _ = std::fs::remove_dir_all(&dir);
}
