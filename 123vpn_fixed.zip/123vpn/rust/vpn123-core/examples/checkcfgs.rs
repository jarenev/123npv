//! Генерирует конфиги для набора тестовых ссылок под «своё» ядро каждого
//! протокола (и под fallback-ядро, если есть) — для проверки настоящими
//! бинарниками: `xray run -test` и `sing-box check`.
//! Использование: checkcfgs <файл "имя ссылка" построчно> <каталог-вывода>

use vpn123_core::{config_singbox, config_xray, links, model::CoreKind, select};

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let text = std::fs::read_to_string(&args[1]).expect("файл со ссылками");
    let out = &args[2];
    std::fs::create_dir_all(out).unwrap();
    for line in text.lines().filter(|l| !l.trim().is_empty() && !l.starts_with('#')) {
        let (name, link) = line.split_once(' ').expect("имя и ссылка через пробел");
        let Some(srv) = links::parse_link(link) else {
            println!("{name}: PARSE FAIL");
            continue;
        };
        let Some(core) = select::choose_core(&srv, true, true) else {
            println!("{name}: UNSUPPORTED");
            continue;
        };
        let cfg = match core {
            CoreKind::Xray => config_xray::build(&srv, 10808),
            CoreKind::Singbox => config_singbox::build(&srv, 10808),
        };
        let path = format!("{out}/{name}.{}.json", core.label());
        std::fs::write(&path, serde_json::to_vec_pretty(&cfg).unwrap()).unwrap();
        println!("{name} {} {path}", core.label());
    }
}
