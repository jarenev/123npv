//! Хостовая проверка: генерирует xray-конфиг ровно так же, как приложение,
//! и пишет его в файл. Аргументы: <файл-с-линками> <socks_port> [индекс_ноды]
//! Пример: dumpcfg /tmp/sub_decoded.txt 10808 0

use vpn123_core::{config_xray, links, ping, select};

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let text = std::fs::read_to_string(&args[1]).expect("файл с линками");
    let port: u16 = args[2].parse().expect("порт");
    let idx: usize = args.get(3).map(|s| s.parse().unwrap()).unwrap_or(0);

    let servers = links::parse_subscription(&text);
    println!("серверов: {}", servers.len());
    let measured = ping::ping_all(&servers);
    for (i, m) in measured.iter().enumerate() {
        println!(
            "  [{i}] {}:{} {:?} latency={:?}",
            m.server.host, m.server.port, m.server.protocol, m.latency_ms
        );
    }
    let ranked = select::rank_alive(&measured);
    let best = ranked
        .get(idx)
        .or_else(|| ranked.first())
        .expect("нет живых нод")
        .server
        .clone();
    println!(
        "лучший [{idx}]: {}:{} {:?}",
        best.host, best.port, best.protocol
    );

    let cfg = config_xray::build(&best, port);
    std::fs::write("/tmp/xray_cfg.json", serde_json::to_vec_pretty(&cfg).unwrap()).unwrap();
    println!("конфиг → /tmp/xray_cfg.json (socks :{port})");
}
