//! Ядро «123 VPN»: модель данных подписок и протоколов.

use serde::{Deserialize, Serialize};

/// Два поддерживаемых ядра-бинарника.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CoreKind {
    Xray,
    Singbox,
}

impl CoreKind {
    /// Имя бинарника внутри nativeLibraryDir (замаскирован под .so).
    pub fn lib_name(self) -> &'static str {
        match self {
            CoreKind::Xray => "libxray.so",
            CoreKind::Singbox => "libsingbox.so",
        }
    }

    /// Аргументы запуска ядра с конфигом.
    pub fn run_args(self, config_path: &str) -> Vec<String> {
        match self {
            CoreKind::Xray => vec!["run".into(), "-c".into(), config_path.into()],
            CoreKind::Singbox => vec!["run".into(), "-c".into(), config_path.into()],
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            CoreKind::Xray => "xray",
            CoreKind::Singbox => "sing-box",
        }
    }
}

/// Протоколы, поддерживаемые связкой xray + sing-box.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
pub enum Protocol {
    #[default]
    Vmess,
    Vless,
    Trojan,
    Shadowsocks,
    Socks,
    Http,
    Hysteria,
    Hysteria2,
    Tuic,
    Wireguard,
    Anytls,
    Shadowtls,
    Naive,
    Ssh,
    Ssr,
    Unknown,
}

impl Protocol {
    /// Какое ядро предпочитаем для этого протокола.
    /// Готовые ядра умеют больше: vmess/vless/trojan/ss/socks/http/wireguard
    /// есть в обоих, остальное — только sing-box.
    pub fn preferred_core(self) -> CoreKind {
        match self {
            Protocol::Hysteria
            | Protocol::Hysteria2
            | Protocol::Tuic
            | Protocol::Anytls
            | Protocol::Shadowtls
            | Protocol::Naive
            | Protocol::Ssh => CoreKind::Singbox,
            _ => CoreKind::Xray,
        }
    }

    /// Альтернативное ядро, если основное бинарника нет в системе.
    pub fn fallback_core(self) -> Option<CoreKind> {
        match self {
            Protocol::Vmess
            | Protocol::Vless
            | Protocol::Trojan
            | Protocol::Shadowsocks
            | Protocol::Socks
            | Protocol::Http
            | Protocol::Wireguard => Some(if self.preferred_core() == CoreKind::Xray {
                CoreKind::Singbox
            } else {
                CoreKind::Xray
            }),
            _ => None,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Protocol::Vmess => "vmess",
            Protocol::Vless => "vless",
            Protocol::Trojan => "trojan",
            Protocol::Shadowsocks => "shadowsocks",
            Protocol::Socks => "socks",
            Protocol::Http => "http",
            Protocol::Hysteria => "hysteria",
            Protocol::Hysteria2 => "hysteria2",
            Protocol::Tuic => "tuic",
            Protocol::Wireguard => "wireguard",
            Protocol::Anytls => "anytls",
            Protocol::Shadowtls => "shadowtls",
            Protocol::Naive => "naive",
            Protocol::Ssh => "ssh",
            Protocol::Ssr => "ssr",
            Protocol::Unknown => "unknown",
        }
    }

    /// Протокол жив ли вообще в нашем стеке.
    /// ssr выпилен из современных ядер; naive в официальной сборке sing-box
    /// требует внешнюю libcronet («cronet: library not found» при инициализации),
    /// поэтому такие сервера не выбираем — failover возьмёт следующий.
    pub fn supported(self) -> bool {
        !matches!(self, Protocol::Ssr | Protocol::Naive | Protocol::Unknown)
    }
}

/// Транспорт (network) для vmess/vless/trojan.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Transport {
    pub kind: TransportKind,
    pub path: Option<String>,
    pub host: Option<String>,
    pub service_name: Option<String>,
    pub http_method: Option<String>,
    /// xhttp: режим (auto / packet-up / stream-up / stream-one).
    pub mode: Option<String>,
    /// xhttp: «extra» — сырой JSON с доп. настройками (xmux, padding…).
    pub extra: Option<String>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum TransportKind {
    #[default]
    Tcp,
    Ws,
    Grpc,
    Http,
    HttpUpgrade,
    Xhttp,
}

/// TLS/REALITY параметры.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct TlsParams {
    pub sni: Option<String>,
    pub alpn: Vec<String>,
    pub fingerprint: Option<String>,
    pub insecure: bool,
    pub reality_pub: Option<String>,
    pub reality_sid: Option<String>,
    pub spider_x: Option<String>,
    /// Пин сертификата (xray `pcs`): SHA-256, hex, через запятую.
    pub pinned_sha256: Option<String>,
    /// Имя для проверки сертификата (xray `vcn`).
    pub verify_name: Option<String>,
}

/// Всё, что вытащено из ссылки конкретного протокола.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ServerParams {
    pub uuid: Option<String>,
    pub password: Option<String>,
    pub method: Option<String>,
    pub alter_id: Option<u16>,
    pub security: Option<String>,
    pub encryption: Option<String>,
    pub flow: Option<String>,
    pub transport: Option<Transport>,
    pub tls: Option<TlsParams>,
    pub plugin: Option<String>,
    pub plugin_opts: Option<String>,
    pub username: Option<String>,
    // hysteria / hysteria2
    pub auth_str: Option<String>,
    pub up_mbps: Option<u32>,
    pub down_mbps: Option<u32>,
    pub obfs: Option<String>,
    pub obfs_password: Option<String>,
    // tuic
    pub congestion_control: Option<String>,
    pub udp_relay_mode: Option<String>,
    // wireguard
    pub local_addrs: Vec<String>,
    pub peer_public: Option<String>,
    pub private_key: Option<String>,
    pub reserved: Vec<u8>,
    pub psk: Option<String>,
    // ssh
    pub user: Option<String>,
    pub private_key_file: Option<String>,
    pub host_key: Option<String>,
}

/// Один сервер из подписки.
#[derive(Debug, Clone, Default, Serialize)]
pub struct Server {
    pub name: String,
    pub protocol: Protocol,
    pub host: String,
    pub port: u16,
    pub params: ServerParams,
    #[serde(skip)]
    pub raw: String,
}

impl Server {
    pub fn is_tls(&self) -> bool {
        self.params.tls.is_some()
    }
}

/// Сервер с измеренной задержкой.
#[derive(Debug, Clone, Serialize)]
pub struct MeasuredServer {
    pub server: Server,
    /// Миллисекунды TCP-подключения; None — сервер недоступен.
    pub latency_ms: Option<u32>,
}
