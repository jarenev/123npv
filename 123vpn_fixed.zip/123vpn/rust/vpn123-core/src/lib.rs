//! 123 VPN — ядро: подписки, пинг, автоподбор, конфиги.

pub mod config_singbox;
pub mod config_xray;
pub mod geo;
pub mod links;
pub mod model;
pub mod ping;
pub mod pin;
pub mod select;

pub use model::{CoreKind, MeasuredServer, Protocol, Server, ServerParams, Transport, TransportKind, TlsParams};

/// Сгенерировать конфиг под выбранное ядро.
pub fn build_config(server: &Server, core: CoreKind, socks_port: u16) -> serde_json::Value {
    match core {
        CoreKind::Xray => config_xray::build(server, socks_port),
        CoreKind::Singbox => config_singbox::build(server, socks_port),
    }
}
