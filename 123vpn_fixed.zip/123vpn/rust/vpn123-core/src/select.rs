//! Автоподбор: выбираем сервер с лучшим (минимальным) TCP-пингом.
//! Ручной выбор сервера в приложении сознательно отсутствует — ТЗ.

use crate::model::{CoreKind, MeasuredServer, Server};

/// Отсортированный по пингу список живых серверов.
pub fn rank_alive(measured: &[MeasuredServer]) -> Vec<&MeasuredServer> {
    let mut alive: Vec<&MeasuredServer> = measured
        .iter()
        .filter(|m| m.latency_ms.is_some() && m.server.protocol.supported())
        .collect();
    alive.sort_by_key(|m| m.latency_ms.unwrap_or(u32::MAX));
    alive
}

/// Лучший сервер вообще (для старта).
pub fn best(measured: &[MeasuredServer]) -> Option<&MeasuredServer> {
    rank_alive(measured).first().copied()
}

/// Следующий сервер при failover: живые, отсортированные, кроме исключённых.
pub fn next_best<'a>(
    measured: &'a [MeasuredServer],
    exclude: &[Server],
) -> Option<&'a MeasuredServer> {
    rank_alive(measured)
        .into_iter()
        .find(|m| !exclude.iter().any(|s| s.host == m.server.host && s.port == m.server.port))
        .or_else(|| rank_alive(measured).first().copied())
}

fn needs_insecure_tls(server: &Server) -> bool {
    use crate::model::{Protocol, TransportKind};
    let Some(tls) = &server.params.tls else { return false };
    if !tls.insecure || tls.reality_pub.is_some() {
        return false;
    }
    if matches!(
        server.params.transport.as_ref().map(|t| t.kind),
        Some(TransportKind::Xhttp)
    ) {
        return false; // sing-box не знает xhttp
    }
    matches!(
        server.protocol,
        Protocol::Vmess | Protocol::Vless | Protocol::Trojan | Protocol::Http
    )
}

/// Выбор ядра для сервера: предпочитаемый протоколом, иначе fallback,
/// иначе None (протокол не поддержан ни одним доступным ядром).
pub fn choose_core(server: &Server, has_xray: bool, has_singbox: bool) -> Option<CoreKind> {
    if !server.protocol.supported() {
        return None;
    }
    let mut preferred = server.protocol.preferred_core();
    // xray 26.x не умеет «пропускать проверку сертификата» (allowInsecure удалён).
    // Для нод с insecure (самоподписанные сертификаты) берём sing-box, где это есть,
    // если нода не использует то, чего в sing-box нет (reality-пин не нужен, xhttp нет).
    if preferred == CoreKind::Xray && has_singbox && needs_insecure_tls(server) {
        preferred = CoreKind::Singbox;
    }
    if match preferred {
        CoreKind::Xray => has_xray,
        CoreKind::Singbox => has_singbox,
    } {
        return Some(preferred);
    }
    match server.protocol.fallback_core() {
        Some(CoreKind::Xray) if has_xray => Some(CoreKind::Xray),
        Some(CoreKind::Singbox) if has_singbox => Some(CoreKind::Singbox),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{Protocol, ServerParams};

    fn srv(name: &str, proto: Protocol) -> Server {
        Server {
            name: name.into(),
            protocol: proto,
            host: format!("{name}.example.com"),
            port: 443,
            params: ServerParams::default(),
            raw: name.into(),
        }
    }

    fn measured(pairs: &[(&str, Option<u32>)]) -> Vec<MeasuredServer> {
        pairs
            .iter()
            .map(|(n, ms)| MeasuredServer {
                server: srv(n, Protocol::Vless),
                latency_ms: *ms,
            })
            .collect()
    }

    #[test]
    fn sorts_by_latency_and_skips_dead() {
        let m = measured(&[("a", Some(200)), ("b", Some(50)), ("c", None), ("d", Some(80))]);
        let ranked = rank_alive(&m);
        let names: Vec<&str> = ranked.iter().map(|x| x.server.name.as_str()).collect();
        assert_eq!(names, vec!["b", "d", "a"]);
    }

    #[test]
    fn best_picks_min() {
        let m = measured(&[("a", Some(200)), ("b", Some(50))]);
        assert_eq!(best(&m).unwrap().server.name, "b");
    }

    #[test]
    fn next_best_excludes_failed() {
        let m = measured(&[("a", Some(30)), ("b", Some(70)), ("c", Some(90))]);
        let cur = m[0].server.clone();
        let nxt = next_best(&m, std::slice::from_ref(&cur)).unwrap();
        assert_eq!(nxt.server.name, "b");
    }

    #[test]
    fn core_choice_by_protocol() {
        let mut s = srv("hy", Protocol::Hysteria2);
        assert_eq!(choose_core(&s, true, true), Some(CoreKind::Singbox));
        // бинарника sing-box нет — hysteria2 никуда не fallback'ается
        assert_eq!(choose_core(&s, true, false), None);
        s.protocol = Protocol::Vless;
        // vless: предпочитаем xray, при отсутствии — sing-box
        assert_eq!(choose_core(&s, false, true), Some(CoreKind::Singbox));
        assert_eq!(choose_core(&s, true, true), Some(CoreKind::Xray));
        s.protocol = Protocol::Ssr;
        assert_eq!(choose_core(&s, true, true), None);
    }

    #[test]
    fn insecure_tls_goes_to_singbox() {
        use crate::links::parse_link;
        // xray 26.x не поддерживает allowInsecure → такие ноды уходят в sing-box
        let s = parse_link("trojan://pw@1.2.3.4:443?sni=a.com&allowInsecure=1#t").unwrap();
        assert_eq!(choose_core(&s, true, true), Some(CoreKind::Singbox));
        // если sing-box нет — остаёмся на xray (с проверкой сертификата)
        assert_eq!(choose_core(&s, true, false), Some(CoreKind::Xray));
        // без insecure — обычный xray
        let ok = parse_link("trojan://pw@1.2.3.4:443?sni=a.com#t").unwrap();
        assert_eq!(choose_core(&ok, true, true), Some(CoreKind::Xray));
        // reality и xhttp остаются на xray
        let x = parse_link("vless://u@1.2.3.4:443?type=xhttp&security=tls&sni=a.com&allowInsecure=1#x").unwrap();
        assert_eq!(choose_core(&x, true, true), Some(CoreKind::Xray));
    }

    #[test]
    fn naive_is_not_selected() {
        use crate::links::parse_link;
        let n = parse_link("naive://u:p@1.2.3.4:443#n").unwrap();
        assert_eq!(choose_core(&n, true, true), None);
    }
}
