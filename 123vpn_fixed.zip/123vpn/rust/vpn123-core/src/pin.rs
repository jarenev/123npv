//! Закрепление IP сервера в конфиге.
//!
//! xray/sing-box запускаются как отдельные Go-бинарники. На Android у них нет
//! /etc/resolv.conf, и встроенный резолвер Go уходит на 127.0.0.1:53 — домен
//! сервера не разрешается, ядро поднимается, но не подключается. Поэтому домен
//! резолвим сами (системным резолвером приложения) и подставляем IP в конфиг,
//! а исходное имя сохраняем как SNI / Host, чтобы TLS и CDN работали как раньше.

use crate::model::Server;
use std::net::IpAddr;

/// Копия сервера с `host = ip`; прежнее имя хоста уходит в SNI и Host-заголовок,
/// если они не заданы явно. Для IP-литерала возвращает копию без изменений.
pub fn pin_ip(srv: &Server, ip: IpAddr) -> Server {
    let mut out = srv.clone();
    let ip_s = ip.to_string();
    if srv.host == ip_s || srv.host.parse::<IpAddr>().is_ok() {
        return out;
    }
    let orig = srv.host.clone();
    out.host = ip_s;
    if let Some(tls) = out.params.tls.as_mut() {
        if tls.sni.is_none() {
            tls.sni = Some(orig.clone());
        }
    }
    if let Some(tr) = out.params.transport.as_mut() {
        if tr.host.is_none() {
            tr.host = Some(orig);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config_singbox, config_xray, links};

    #[test]
    fn domain_becomes_ip_and_keeps_sni() {
        let s = links::parse_link("trojan://pw@example.com:443#t").unwrap();
        let p = pin_ip(&s, "93.184.216.34".parse().unwrap());
        assert_eq!(p.host, "93.184.216.34");
        assert_eq!(p.params.tls.as_ref().unwrap().sni.as_deref(), Some("example.com"));
        let cfg = config_xray::build(&p, 1080);
        let o = &cfg["outbounds"][0];
        assert_eq!(o["settings"]["servers"][0]["address"], "93.184.216.34");
        assert_eq!(o["streamSettings"]["tlsSettings"]["serverName"], "example.com");
    }

    #[test]
    fn ws_host_header_is_preserved() {
        let s = links::parse_link("vless://u@cdn.example.com:443?type=ws&path=%2Fw&security=tls#w").unwrap();
        let p = pin_ip(&s, "1.2.3.4".parse().unwrap());
        let t = p.params.transport.as_ref().unwrap();
        assert_eq!(t.host.as_deref(), Some("cdn.example.com"));
        let cfg = config_singbox::build(&p, 1080);
        assert_eq!(cfg["outbounds"][0]["server"], "1.2.3.4");
        assert_eq!(cfg["outbounds"][0]["tls"]["server_name"], "cdn.example.com");
        assert_eq!(cfg["outbounds"][0]["transport"]["headers"]["Host"], "cdn.example.com");
    }

    #[test]
    fn explicit_sni_is_not_overwritten_and_ip_literal_untouched() {
        let s = links::parse_link("vless://u@host.com:443?security=tls&sni=front.com#x").unwrap();
        let p = pin_ip(&s, "5.5.5.5".parse().unwrap());
        assert_eq!(p.params.tls.unwrap().sni.as_deref(), Some("front.com"));
        let lit = links::parse_link("vless://u@5.5.5.5:443?security=tls#x").unwrap();
        let q = pin_ip(&lit, "5.5.5.5".parse().unwrap());
        assert_eq!(q.host, "5.5.5.5");
        assert!(q.params.tls.unwrap().sni.is_none());
    }
}
