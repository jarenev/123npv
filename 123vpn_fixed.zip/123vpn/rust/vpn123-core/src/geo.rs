//! Определение страны сервера по имени из подписки.
//! Используется для флажка, названия страны в UI и точки-маркера на планете.

use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
pub struct GeoInfo {
    /// ISO-код страны.
    pub cc: String,
    pub name_ru: String,
    pub name_en: String,
    pub lat: f64,
    pub lon: f64,
}

/// Флаг-эмодзи из ISO-кода (региональные индикаторы).
pub fn flag_emoji(cc: &str) -> String {
    cc.to_uppercase()
        .chars()
        .filter_map(|c| {
            let b = c as u32;
            if (b'A' as u32..=b'Z' as u32).contains(&b) {
                Some(char::from_u32(0x1F1E6 + (b - b'A' as u32)).unwrap_or('🌍'))
            } else {
                None
            }
        })
        .collect()
}

/// (ключевые слова в имени, ISO, RU-имя, EN-имя, широта, долгота)
const TABLE: &[(&str, &str, &str, &str, f64, f64)] = &[
    ("россия|ru|russia|moscow|москва|msk|spb|питер|saint|vlg|влг|khv|новосиб|nsk|tula|самара|ekb|екб", "RU", "Россия", "Russia", 55.75, 37.62),
    ("германия|de|germany|frankfurt|ffm|берлин|berlin|munich|gunn|nuremberg|dusseldorf|hamburg", "DE", "Германия", "Germany", 50.11, 8.68),
    ("нидерланды|nl|netherlands|holland|amsterdam|ams|rotterdam", "NL", "Нидерланды", "Netherlands", 52.37, 4.90),
    ("сша|us|usa|united states|america|америка|new york|nyc|los angeles|la-|dallas|seattle|miami|ashburn|chicago|phoenix|san jose|atlanta|denver|virginia|сан-фран|buffalo|boston|portland|houston|lax|jfk", "US", "США", "USA", 38.90, -77.03),
    ("gb|uk|united kingdom|британия|англи|england|london|лондон|scotland", "GB", "Великобритания", "United Kingdom", 51.51, -0.13),
    ("франция|fr|france|paris|париж|strasbourg|marseille", "FR", "Франция", "France", 48.86, 2.35),
    ("швеция|se|sweden|stockholm|стокгольм", "SE", "Швеция", "Sweden", 59.33, 18.07),
    ("польша|pl|poland|warsaw|варшава|gdansk", "PL", "Польша", "Poland", 52.23, 21.01),
    ("украина|ua|ukraine|kyiv|kiev|киев", "UA", "Украина", "Ukraine", 50.45, 30.52),
    ("турция|tr|turkey|istanbul|стамбул|turkiye", "TR", "Турция", "Turkey", 41.01, 28.98),
    ("казахстан|kz|kazakhstan|almaty|алматы|astana|астана|karaganda|aktobe|uralsk|atyrau|shymkent", "KZ", "Казахстан", "Kazakhstan", 51.17, 71.45),
    ("сингапур|sg|singapore", "SG", "Сингапур", "Singapore", 1.35, 103.82),
    ("япония|jp|japan|tokyo|токио|osaka|surfshark|seoul", "JP", "Япония", "Japan", 35.68, 139.69),
    ("гонконг|hk|hong kong|hongkong", "HK", "Гонконг", "Hong Kong", 22.32, 114.17),
    ("канада|ca|canada|toronto|montreal|vancouver|quebec", "CA", "Канада", "Canada", 45.42, -75.70),
    ("оаэ|ae|united arab|emirates|dubai|дубай", "AE", "ОАЭ", "UAE", 25.20, 55.27),
    ("швейцария|ch|switzerland|zurich|цюрих|geneva", "CH", "Швейцария", "Switzerland", 47.38, 8.54),
    ("австрия|at|austria|vienna|вена", "AT", "Австрия", "Austria", 48.21, 16.37),
    ("италия|it|italy|milan|милан|rome|italy", "IT", "Италия", "Italy", 45.46, 9.19),
    ("испания|es|spain|madrid|мадрид|barcelona", "ES", "Испания", "Spain", 40.42, -3.70),
    ("финляндия|fi|finland|helsinki|хельсинки", "FI", "Финляндия", "Finland", 60.17, 24.94),
    ("норвегия|no|norway|oslo", "NO", "Норвегия", "Norway", 59.91, 10.75),
    ("чехия|cz|czech|prague|прага", "CZ", "Чехия", "Czechia", 50.09, 14.42),
    ("латвия|lv|latvia|riga|рига", "LV", "Латвия", "Latvia", 56.95, 24.11),
    ("литва|lt|lithuania|vilnius|вильнюс", "LT", "Литва", "Lithuania", 54.69, 25.28),
    ("эстония|ee|estonia|tallinn|таллин", "EE", "Эстония", "Estonia", 59.44, 24.75),
    ("молдова|md|moldova|chisinau", "MD", "Молдова", "Moldova", 47.01, 28.86),
    ("румыния|ro|romania|bucharest|бухарест", "RO", "Румыния", "Romania", 44.43, 26.10),
    ("болгария|bg|bulgaria|sofia", "BG", "Болгария", "Bulgaria", 42.70, 23.32),
    ("сербия|rs|serbia|belgrade|белград", "RS", "Сербия", "Serbia", 44.79, 20.45),
    ("венгрия|hu|hungary|budapest|будапешт", "HU", "Венгрия", "Hungary", 47.50, 19.04),
    ("греция|gr|greece|athens|афины", "GR", "Греция", "Greece", 37.98, 23.73),
    ("ирландия|ie|ireland|dublin|дублин", "IE", "Ирландия", "Ireland", 53.35, -6.26),
    ("бельгия|be|belgium|brussels|брюссель", "BE", "Бельгия", "Belgium", 50.85, 4.35),
    ("дания|dk|denmark|copenhagen|копенгаген", "DK", "Дания", "Denmark", 55.68, 12.57),
    ("португалия|pt|portugal|lisbon|лиссабон", "PT", "Португалия", "Portugal", 38.72, -9.14),
    ("израиль|il|israel|tel aviv|изра", "IL", "Израиль", "Israel", 32.08, 34.78),
    ("индия|in|india|mumbai|delhi|bombay", "IN", "Индия", "India", 19.08, 72.88),
    ("южная корея|kr|korea|seoul|сеул", "KR", "Южная Корея", "South Korea", 37.57, 126.98),
    ("тайвань|tw|taiwan|taipei", "TW", "Тайвань", "Taiwan", 25.03, 121.56),
    ("вьетнам|vn|vietnam|hanoi|ho chi minh", "VN", "Вьетнам", "Vietnam", 21.03, 105.85),
    ("таиланд|th|thailand|bangkok|бангкок", "TH", "Таиланд", "Thailand", 13.76, 100.50),
    ("малайзия|my|malaysia|kuala lumpur", "MY", "Малайзия", "Malaysia", 3.14, 101.69),
    ("индонезия|id|indonesia|jakarta", "ID", "Индонезия", "Indonesia", -6.21, 106.85),
    ("австралия|au|australia|sydney|melbourne", "AU", "Австралия", "Australia", -33.87, 151.21),
    ("новая зеландия|nz|new zealand|auckland", "NZ", "Новая Зеландия", "New Zealand", -36.85, 174.76),
    ("бразилия|br|brazil|sao paulo|сан-паулу", "BR", "Бразилия", "Brazil", -23.55, -46.63),
    ("аргентина|ar|argentina|buenos aires", "AR", "Аргентина", "Argentina", -34.60, -58.38),
    ("мексика|mx|mexico|mexico city", "MX", "Мексика", "Mexico", 19.43, -99.13),
    ("юар|za|south africa|johannesburg", "ZA", "ЮАР", "South Africa", -26.20, 28.05),
    ("грузия|ge|georgia|tbilisi|тбилиси", "GE", "Грузия", "Georgia", 41.72, 44.79),
    ("армения|am|armenia|yerevan|ереван", "AM", "Армения", "Armenia", 40.18, 44.51),
    ("азербайджан|az|azerbaijan|baku|баку", "AZ", "Азербайджан", "Azerbaijan", 40.41, 49.87),
    ("узбекистан|uz|uzbekistan|tashkent|ташкент", "UZ", "Узбекистан", "Uzbekistan", 41.30, 69.24),
    ("киргизия|kg|kyrgyzstan|bishkek|бишкек", "KG", "Киргизия", "Kyrgyzstan", 42.87, 74.59),
    ("таджикистан|tj|tajikistan|dushanbe", "TJ", "Таджикистан", "Tajikistan", 38.56, 68.79),
    ("китай|cn|china|shanghai|beijing|китай", "CN", "Китай", "China", 31.23, 121.47),
    ("беларусь|by|belarus|minsk|минск", "BY", "Беларусь", "Belarus", 53.90, 27.57),
];

/// Определяет страну по имени сервера (подписки часто пишут "DE 1", "Франкфурт #2"...).
/// Короткие ключи (≤3 символов, типа "de", "us") ищутся только целыми словами,
/// чтобы "bar" не превратился в Аргентину.
pub fn detect(name: &str) -> Option<GeoInfo> {
    let lower = name.to_lowercase();
    let tokens: Vec<&str> = lower
        .split(|c: char| !c.is_ascii_alphanumeric())
        .filter(|t| !t.is_empty())
        .collect();
    for (keys, cc, ru, en, lat, lon) in TABLE {
        for key in keys.split('|') {
            if key.len() <= 3 {
                if tokens.contains(&key) {
                    return Some(GeoInfo {
                        cc: cc.to_string(),
                        name_ru: ru.to_string(),
                        name_en: en.to_string(),
                        lat: *lat,
                        lon: *lon,
                    });
                }
            } else if lower.contains(key) {
                return Some(GeoInfo {
                    cc: cc.to_string(),
                    name_ru: ru.to_string(),
                    name_en: en.to_string(),
                    lat: *lat,
                    lon: *lon,
                });
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_by_code() {
        let g = detect("DE-01").unwrap();
        assert_eq!(g.cc, "DE");
        assert_eq!(flag_emoji("DE"), "🇩🇪");
    }

    #[test]
    fn detects_by_city() {
        let g = detect("Frankfurt #2 10G").unwrap();
        assert_eq!(g.cc, "DE");
    }

    #[test]
    fn russia_beats_other_matches() {
        // "ru" встречается раньше "de" в строке, но приоритет задан порядком таблицы
        assert_eq!(detect("ru-1").unwrap().cc, "RU");
    }

    #[test]
    fn short_keys_need_word_boundaries() {
        // "ar" внутри слова — не Аргентина
        assert!(detect("foo bar baz 12345").is_none());
        // но отдельный токен "ar" — Аргентина
        assert_eq!(detect("ar #3").unwrap().cc, "AR");
    }

    #[test]
    fn flag_fallback() {
        // цифры и пустота не дают флага
        assert_eq!(flag_emoji("12"), "");
        assert_eq!(flag_emoji(""), "");
    }
}
