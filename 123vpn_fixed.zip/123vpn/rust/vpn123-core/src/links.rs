//! Парсинг ссылок-подписок и отдельных нод.
//!
//! Поддерживаются все протоколы, доступные в связке xray + sing-box:
//! vmess, vless, trojan, shadowsocks, socks, http(s), hysteria, hysteria2,
//! tuic, wireguard, anytls, shadowtls, naive, ssh. ssr распознаётся,
//! но помечается неподдерживаемым (выпилен из современных ядер).

use crate::model::*;
use base64::Engine;
use std::collections::HashMap;

// ────────────────────────── утилиты ──────────────────────────

fn b64_decode_any(s: &str) -> Option<Vec<u8>> {
    let cleaned: String = s.chars().filter(|c| !c.is_whitespace()).collect();
    let try_with = |alphabet: &base64::engine::GeneralPurpose, mut v: String| -> Option<Vec<u8>> {
        let pad = (4 - v.len() % 4) % 4;
        for _ in 0..pad {
            v.push('=');
        }
        alphabet.decode(v.as_bytes()).ok()
    };
    use base64::engine::general_purpose::{STANDARD, STANDARD_NO_PAD, URL_SAFE, URL_SAFE_NO_PAD};
    try_with(&STANDARD, cleaned.clone())
        .or_else(|| try_with(&URL_SAFE, cleaned.clone()))
        .or_else(|| try_with(&STANDARD_NO_PAD, cleaned.clone()))
        .or_else(|| try_with(&URL_SAFE_NO_PAD, cleaned.clone()))
}

fn b64_str(s: &str) -> Option<String> {
    b64_decode_any(s).and_then(|v| String::from_utf8(v).ok())
}

fn pct_decode(s: &str) -> String {
    percent_encoding::percent_decode_str(s)
        .decode_utf8_lossy()
        .into_owned()
}

/// Карта query-параметров (url уже декодирует percent-encoding).
fn query_map(u: &url::Url) -> HashMap<String, String> {
    u.query_pairs().into_owned().collect()
}

fn opt(map: &HashMap<String, String>, key: &str) -> Option<String> {
    map.get(key).map(|v| v.trim().to_string()).filter(|v| !v.is_empty())
}

fn bool_param(map: &HashMap<String, String>, key: &str) -> bool {
    matches!(opt(map, key).as_deref(), Some("1") | Some("true") | Some("true?"))
}

fn split_alpn(v: Option<String>) -> Vec<String> {
    v.map(|s| s.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect())
        .unwrap_or_default()
}

fn transport_from(map: &HashMap<String, String>, net: &str) -> Option<Transport> {
    let mut t = Transport {
        kind: match net {
            "ws" => TransportKind::Ws,
            "grpc" | "gun" | "grpc+multi" => TransportKind::Grpc,
            "http" | "h2" => TransportKind::Http,
            "httpupgrade" => TransportKind::HttpUpgrade,
            "xhttp" | "splithttp" => TransportKind::Xhttp,
            _ => TransportKind::Tcp,
        },
        ..Default::default()
    };
    if net == "http" && opt(map, "headerType").as_deref() == Some("http") {
        // tcp + http-обфускация: маркер в http_method, чтобы генераторы
        // отличали её от настоящего h2-транспорта
        t.http_method = Some("GET".into());
    }
    match t.kind {
        TransportKind::Tcp => None, // обычный TCP: транспорт не задаём
        _ => {
            t.path = opt(map, "path");
            t.host = opt(map, "host");
            t.service_name = opt(map, "serviceName").or_else(|| opt(map, "service_name"));
            if let TransportKind::Http = t.kind {
                if t.path.is_none() {
                    t.path = Some("/".into());
                }
            }
            if let TransportKind::Xhttp = t.kind {
                t.mode = opt(map, "mode");
                t.extra = opt(map, "extra").filter(|e| e.trim_start().starts_with('{'));
            }
            Some(t)
        }
    }
}

fn tls_from(map: &HashMap<String, String>) -> Option<TlsParams> {
    let security = opt(map, "security").unwrap_or_default();
    let reality = security == "reality"
        || opt(map, "pbk").is_some();
    let tls_enabled = security == "tls" || security == "reality" || reality
        || opt(map, "sni").is_some() && (security.is_empty() || security == "tls");
    if !tls_enabled && !reality {
        return None;
    }
    Some(TlsParams {
        sni: opt(map, "sni").or_else(|| opt(map, "peer")).or_else(|| opt(map, "host")),
        alpn: split_alpn(opt(map, "alpn")),
        fingerprint: opt(map, "fp").or_else(|| {
            if reality { Some("chrome".into()) } else { None }
        }),
        insecure: bool_param(map, "insecure") || bool_param(map, "allowInsecure"),
        reality_pub: opt(map, "pbk"),
        reality_sid: opt(map, "sid"),
        spider_x: opt(map, "spx"),
        pinned_sha256: opt(map, "pcs"),
        verify_name: opt(map, "vcn"),
    })
}

fn base_server(name: &str, host: &str, port: u16, protocol: Protocol, raw: &str) -> Server {
    Server {
        name: if name.trim().is_empty() { format!("{host}:{port}") } else { name.trim().to_string() },
        protocol,
        host: host.trim_start_matches('[').trim_end_matches(']').to_string(),
        port,
        params: ServerParams::default(),
        raw: raw.to_string(),
    }
}

// ────────────────────────── диспетчер ──────────────────────────

pub fn parse_link(link: &str) -> Option<Server> {
    let link = link.trim();
    if link.is_empty() || link.starts_with('#') || link.starts_with("//") {
        return None;
    }
    let (scheme, _rest) = link.split_once("://")?;
    let server = match scheme.to_ascii_lowercase().as_str() {
        "vmess" => parse_vmess(link),
        "vless" => parse_url_scheme(link, Protocol::Vless),
        "trojan" | "trojan-go" => parse_url_scheme(link, Protocol::Trojan),
        "ss" => parse_ss(link),
        "socks" | "socks5" => parse_url_scheme(link, Protocol::Socks),
        "http" | "https" => parse_url_scheme(link, Protocol::Http),
        "hysteria" => parse_hysteria1(link),
        "hysteria2" | "hy2" => parse_hysteria2(link),
        "tuic" => parse_tuic(link),
        "wireguard" | "wg" => parse_wireguard(link),
        "anytls" => parse_anytls(link),
        "shadowtls" => parse_shadowtls(link),
        "naive" | "naive+https" => parse_naive(link),
        "ssh" => parse_ssh(link),
        "ssr" => parse_ssr(link),
        _ => None,
    }?;
    if server.port == 0 || server.host.is_empty() {
        return None;
    }
    Some(server)
}

/// Схемы, однозначно указывающие на одиночную ноду (не URL подписки).
/// http(s):// сюда не входит: это одновременно и схема подписки —
/// такие адреса всегда скачиваются.
const NODE_SCHEMES: &[&str] = &[
    "vmess", "vless", "trojan", "trojan-go", "ss", "ssr", "socks", "socks5",
    "hysteria", "hysteria2", "hy2", "tuic", "wireguard", "wg",
    "anytls", "shadowtls", "naive", "naive+https", "ssh",
];

/// true, если источник — не ссылка подписки, а готовый текст с нодой/нодами
/// (одиночная ссылка или построчный список): его не нужно скачивать по HTTP.
pub fn is_node_text(src: &str) -> bool {
    src.lines()
        .map(str::trim)
        .find(|l| !l.is_empty() && !l.starts_with('#') && !l.starts_with("//"))
        .and_then(|l| l.split_once("://"))
        .map(|(scheme, rest)| {
            !rest.is_empty()
                && NODE_SCHEMES.iter().any(|s| scheme.eq_ignore_ascii_case(s))
        })
        .unwrap_or(false)
}

#[cfg(test)]
mod node_text_tests {
    use super::is_node_text;

    #[test]
    fn single_vless_is_node_text() {
        assert!(is_node_text("vless://uuid@host:443?security=tls&type=ws#Node"));
        assert!(is_node_text("  trojan://pass@host:443#T "));
        assert!(is_node_text("HY2://pass@host:443"));
    }

    #[test]
    fn subscription_url_is_not_node_text() {
        assert!(!is_node_text("https://example.com/sub"));
        assert!(!is_node_text("http://example.com/sub"));
    }

    #[test]
    fn multiline_node_list_is_node_text() {
        let src = "\n\n  vless://a@b:1#x\nvmess://eyJ2IjoiMiJ9\n";
        assert!(is_node_text(src));
    }

    #[test]
    fn garbage_is_not_node_text() {
        assert!(!is_node_text("просто текст"));
        assert!(!is_node_text(""));
        assert!(!is_node_text("vless://"));
        assert!(!is_node_text("https-only://nope"));
    }
}

/// Тело подписки → список серверов.
/// Умеет: base64-обёртка, открытый текст (одна ссылка в строке), SIP008 JSON.
pub fn parse_subscription(body: &str) -> Vec<Server> {
    let body = body.trim();
    if body.is_empty() {
        return Vec::new();
    }

    // SIP008 / clash-подобный JSON
    if body.starts_with('{') {
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(body) {
            if let Some(arr) = v.get("servers").and_then(|s| s.as_array()) {
                let out = arr.iter().filter_map(sip008_server).collect::<Vec<_>>();
                if !out.is_empty() {
                    return out;
                }
            }
        }
    }

    let mut text = body.to_string();
    // Целиком base64?
    let flat: String = text.chars().filter(|c| !c.is_whitespace()).collect();
    if !flat.contains("://") {
        if let Some(decoded) = b64_str(&flat) {
            if decoded.contains("://") {
                text = decoded;
            }
        }
    }

    // Одна ссылка в строке. Имена нод часто содержат пробелы без percent-кодирования
    // («#🇩🇪 Germany 1»), поэтому делить по пробелам можно только если построчный
    // разбор ничего не дал (все ссылки склеены через пробел в одну строку).
    let out: Vec<Server> = text
        .lines()
        .flat_map(split_inline_links)
        .filter_map(|l| parse_link(&l))
        .collect();
    dedup(out)
}

/// Делит строку на ссылки, только если после пробела начинается новая ссылка
/// известной схемы («vless://… vless://…»). Пробелы внутри имени ноды
/// («#Germany 1») строку не режут.
fn split_inline_links(line: &str) -> Vec<String> {
    let mut parts: Vec<String> = Vec::new();
    for tok in line.split(' ') {
        let starts_new = tok
            .split_once("://")
            .map(|(sch, _)| NODE_SCHEMES.iter().any(|x| sch.eq_ignore_ascii_case(x)))
            .unwrap_or(false);
        match parts.last_mut() {
            Some(last) if !starts_new => {
                last.push(' ');
                last.push_str(tok);
            }
            _ => parts.push(tok.to_string()),
        }
    }
    parts
}

/// Ссылки встречаются дубликатами — оставляем первое вхождение.
fn dedup(servers: Vec<Server>) -> Vec<Server> {
    let mut seen = std::collections::HashSet::new();
    servers
        .into_iter()
        .filter(|s| seen.insert((s.protocol, s.host.clone(), s.port, s.name.clone())))
        .collect()
}

fn sip008_server(v: &serde_json::Value) -> Option<Server> {
    let get = |k: &str| v.get(k).and_then(|x| x.as_str()).map(|s| s.to_string());
    let num = |k: &str| v.get(k).and_then(|x| x.as_u64()).map(|x| x as u16);
    let proto = match get("type").as_deref().unwrap_or("") {
        "vmess" => Protocol::Vmess,
        "vless" => Protocol::Vless,
        "trojan" => Protocol::Trojan,
        "shadowsocks" | "ss" => Protocol::Shadowsocks,
        "hysteria2" => Protocol::Hysteria2,
        "hysteria" => Protocol::Hysteria,
        "tuic" => Protocol::Tuic,
        "socks" => Protocol::Socks,
        "http" => Protocol::Http,
        "wireguard" => Protocol::Wireguard,
        "anytls" => Protocol::Anytls,
        "ssh" => Protocol::Ssh,
        _ => Protocol::Unknown,
    };
    let host = get("server")?;
    let port = num("server_port")?;
    let mut s = base_server(&get("remarks").or_else(|| get("name")).unwrap_or_default(), &host, port, proto, "");
    s.params.uuid = get("uuid");
    s.params.password = get("password");
    s.params.method = get("method");
    s.params.security = get("security");
    s.params.flow = get("flow");
    if let Some(aid) = v.get("alter_id").and_then(|x| x.as_u64()) {
        s.params.alter_id = Some(aid as u16);
    }
    s.params.tls = Some(TlsParams {
        sni: get("sni").or_else(|| get("server_name")),
        ..Default::default()
    });
    Some(s)
}

// ────────────────────────── vmess ──────────────────────────

fn parse_vmess(link: &str) -> Option<Server> {
    let payload = link.strip_prefix("vmess://")?;
    let json = b64_str(payload)?;
    let v: serde_json::Value = serde_json::from_str(&json).ok()?;
    let s = |k: &str| v.get(k).and_then(|x| x.as_str()).map(|x| x.to_string());
    let n = |k: &str| -> Option<u16> {
        v.get(k).and_then(|x| {
            x.as_u64()
                .map(|y| y as u16)
                .or_else(|| x.as_str().and_then(|y| y.trim().parse().ok()))
        })
    };
    let host = s("add")?;
    let port = n("port")?;
    let mut srv = base_server(&s("ps").unwrap_or_default(), &host, port, Protocol::Vmess, link);

    srv.params.uuid = s("id");
    srv.params.alter_id = Some(n("aid").unwrap_or(0));
    srv.params.security = Some(s("scy").unwrap_or_else(|| "auto".into()));
    srv.params.method = None;
    let mut net = s("net").unwrap_or_else(|| "tcp".into());
    // Заголовки из vmess-JSON: host/path/tls/sni/alpn/fp
    let mut map = HashMap::new();
    for key in ["path", "host", "sni", "fp", "type", "serviceName"] {
        if let Some(val) = s(key) {
            map.insert(key.to_string(), val);
        }
    }
    // В vmess-JSON поле «type» — это headerType; tcp+type=http = http-обфускация.
    if let Some(ht) = s("type") {
        map.insert("headerType".to_string(), ht.clone());
        if net == "tcp" && ht == "http" {
            net = "http".into();
        }
    }
    srv.params.transport = transport_from(&map, &net);
    if let Some(tls) = s("tls") {
        if tls == "tls" || tls == "reality" {
            let mut tp = TlsParams {
                sni: s("sni").or_else(|| s("host")),
                alpn: split_alpn(s("alpn")),
                fingerprint: s("fp"),
                insecure: s("allowInsecure").as_deref() == Some("1"),
                reality_pub: s("pbk"),
                reality_sid: s("sid"),
                spider_x: s("spx"),
                pinned_sha256: s("pcs"),
                verify_name: s("vcn"),
            };
            if tls == "reality" {
                tp.fingerprint.get_or_insert_with(|| "chrome".into());
            }
            srv.params.tls = Some(tp);
        }
    }
    Some(srv)
}

// ────────────────────────── ss ──────────────────────────

fn parse_ss(link: &str) -> Option<Server> {
    // Формат 1 (SIP002): ss://BASE64(method:pass)@host:port?plugin=...#name
    // Формат 2 (legacy): ss://BASE64(method:pass@host:port)#name
    let rest = link.strip_prefix("ss://")?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };

    // Формат 1: пробуем как URL. Если это не похоже на SIP002 (нет порта
    // или userinfo не декодируется) — проваливаемся в legacy-формат.
    if let Ok(u) = url::Url::parse(&format!("ss://{body}")) {
        if let (Some(host), Some(port)) = (u.host_str(), u.port()) {
            let userinfo = match u.password() {
                // SIP002 без base64: ss://method:password@host:port (в т.ч. SS-2022)
                Some(pw) => Some((pct_decode(u.username()), pct_decode(pw))),
                None => decode_ss_userinfo(&pct_decode(u.username())),
            };
            if let Some((method, password)) = userinfo {
                let map = query_map(&u);
                let mut srv = base_server(&name, host, port, Protocol::Shadowsocks, link);
                srv.params.method = Some(method);
                srv.params.password = Some(password);
                if let Some(p) = opt(&map, "plugin") {
                    // "obfs-local;obfs=http;obfs-host=..." → (plugin, opts)
                    let mut parts = p.splitn(2, ';');
                    srv.params.plugin = parts.next().map(|x| x.trim().to_string());
                    srv.params.plugin_opts = parts.next().map(|x| x.trim().to_string());
                }
                return Some(srv);
            }
        }
    }

    // Формат 2: всё тело — base64
    let decoded = b64_str(&body)?;
    let (userinfo, hostport) = decoded.rsplit_once('@')?;
    let (method, password) = decode_ss_userinfo(userinfo)?;
    let (host, port) = split_hostport(hostport)?;
    let mut srv = base_server(&name, &host, port, Protocol::Shadowsocks, link);
    srv.params.method = Some(method);
    srv.params.password = Some(password);
    Some(srv)
}

fn decode_ss_userinfo(userinfo: &str) -> Option<(String, String)> {
    if userinfo.contains(':') && !is_b64_only(userinfo) {
        let (m, p) = userinfo.split_once(':')?;
        return Some((m.to_string(), pct_decode(p)));
    }
    let decoded = b64_str(userinfo)?;
    let (m, p) = decoded.split_once(':')?;
    Some((m.to_string(), p.to_string()))
}

fn is_b64_only(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '+' || c == '/' || c == '-' || c == '_' || c == '=')
}

fn split_hostport(s: &str) -> Option<(String, u16)> {
    let s = s.trim();
    if let Some(rest) = s.strip_prefix('[') {
        // [::1]:443
        let (host, tail) = rest.split_once(']')?;
        let port = tail.strip_prefix(':')?.parse().ok()?;
        return Some((host.to_string(), port));
    }
    let (host, port) = s.rsplit_once(':')?;
    Some((host.to_string(), port.parse().ok()?))
}

// ────────────────────────── URL-схемы ──────────────────────────

/// vless, trojan, socks, http(s) — раскладывают параметры одинаково.
fn parse_url_scheme(link: &str, protocol: Protocol) -> Option<Server> {
    let scheme_end = link.find("://")? + 3;
    let (scheme, rest) = link.split_at(scheme_end);
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("{scheme}{body}")).ok()?;
    let host = u.host_str()?.to_string();
    let port = u.port().unwrap_or(if protocol == Protocol::Http { 80 } else { 443 });

    let mut srv = base_server(&name, &host, port, protocol, link);

    // userinfo: uuid или user:pass
    let userinfo = u.username();
    if !userinfo.is_empty() {
        match protocol {
            Protocol::Vless => srv.params.uuid = Some(pct_decode(userinfo)),
            Protocol::Trojan => srv.params.password = Some(pct_decode(userinfo)),
            Protocol::Socks | Protocol::Http => {
                srv.params.username = Some(pct_decode(userinfo));
                srv.params.password = u.password().map(pct_decode);
            }
            _ => srv.params.uuid = Some(pct_decode(userinfo)),
        }
    }
    if let Some(p) = u.password() {
        srv.params.password = Some(pct_decode(p));
    }

    let map = query_map(&u);
    srv.params.flow = opt(&map, "flow");
    srv.params.security = opt(&map, "security");
    if protocol == Protocol::Vless {
        // VLESS Encryption (mlkem768x25519plus…); «none» — обычный случай.
        srv.params.encryption = opt(&map, "encryption").filter(|e| e != "none");
    }

    let net = opt(&map, "type").unwrap_or_else(|| "tcp".into());
    srv.params.transport = transport_from(&map, &net);
    srv.params.tls = match protocol {
        Protocol::Trojan => {
            // trojan всегда TLS; sni может прийти в query
            let mut tp = tls_from(&map).unwrap_or_default();
            tp.sni = tp.sni.or_else(|| opt(&map, "sni"));
            tp.insecure = tp.insecure || bool_param(&map, "allowInsecure");
            Some(tp)
        }
        Protocol::Http if scheme.to_ascii_lowercase().starts_with("https") => {
            Some(TlsParams { sni: opt(&map, "sni"), ..Default::default() })
        }
        Protocol::Vless => tls_from(&map),
        _ => tls_from(&map),
    };
    // Обфускация hysteria2-стиля не для этих схем; но obfs для ss уже отдельно.
    Some(srv)
}

// ────────────────────────── hysteria / hysteria2 / tuic ──────────────────────────

fn parse_hysteria1(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("hysteria://")?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("hysteria://{body}")).ok()?;
    let host = u.host_str()?.to_string();
    let port = u.port().unwrap_or(443);
    let map = query_map(&u);
    let mut srv = base_server(&name, &host, port, Protocol::Hysteria, link);
    srv.params.auth_str = opt(&map, "auth").or_else(|| opt(&map, "auth_str"));
    srv.params.up_mbps = opt(&map, "upmbps").and_then(|v| v.parse().ok());
    srv.params.down_mbps = opt(&map, "downmbps").and_then(|v| v.parse().ok());
    srv.params.obfs = opt(&map, "obfs");
    srv.params.tls = Some(TlsParams {
        sni: opt(&map, "peer").or_else(|| opt(&map, "sni")).or_else(|| opt(&map, "host")),
        alpn: split_alpn(opt(&map, "alpn")).pipe(|mut a| {
            if a.is_empty() { a.push("h3".into()); }
            a
        }),
        fingerprint: None,
        insecure: bool_param(&map, "insecure"),
        ..Default::default()
    });
    Some(srv)
}

fn parse_hysteria2(link: &str) -> Option<Server> {
    let scheme_len = if link.starts_with("hysteria2://") { "hysteria2://".len() } else { "hy2://".len() };
    let (body, name) = match link[scheme_len..].split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (link[scheme_len..].to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("hysteria2://{body}")).ok()?;
    let host = u.host_str()?.to_string();
    let port = u.port().unwrap_or(443);
    let map = query_map(&u);
    let mut srv = base_server(&name, &host, port, Protocol::Hysteria2, link);
    srv.params.password = Some(pct_decode(u.username()));
    srv.params.obfs = opt(&map, "obfs");
    srv.params.obfs_password = opt(&map, "obfs-password").or_else(|| opt(&map, "obfs_password"));
    srv.params.up_mbps = opt(&map, "up").and_then(|v| v.parse().ok());
    srv.params.down_mbps = opt(&map, "down").and_then(|v| v.parse().ok());
    srv.params.tls = Some(TlsParams {
        sni: opt(&map, "sni").or_else(|| opt(&map, "peer")),
        alpn: split_alpn(opt(&map, "alpn")).pipe(|mut a| {
            if a.is_empty() { a.push("h3".into()); }
            a
        }),
        fingerprint: None,
        insecure: bool_param(&map, "insecure") || bool_param(&map, "allowInsecure"),
        ..Default::default()
    });
    Some(srv)
}

fn parse_tuic(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("tuic://")?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("tuic://{body}")).ok()?;
    let host = u.host_str()?.to_string();
    let port = u.port().unwrap_or(443);
    let map = query_map(&u);
    let mut srv = base_server(&name, &host, port, Protocol::Tuic, link);
    srv.params.uuid = Some(pct_decode(u.username()));
    srv.params.password = u.password().map(pct_decode);
    srv.params.congestion_control = opt(&map, "congestion_control").or_else(|| opt(&map, "congestioncontrol"));
    srv.params.udp_relay_mode = opt(&map, "udp_relay_mode");
    srv.params.tls = Some(TlsParams {
        sni: opt(&map, "sni"),
        alpn: split_alpn(opt(&map, "alpn")).pipe(|mut a| {
            if a.is_empty() { a.push("h3".into()); }
            a
        }),
        fingerprint: None,
        insecure: bool_param(&map, "allow_insecure") || bool_param(&map, "insecure"),
        ..Default::default()
    });
    Some(srv)
}

// ────────────────────────── wireguard ──────────────────────────

fn parse_wireguard(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("wireguard://").or_else(|| link.strip_prefix("wg://"))?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("wireguard://{body}")).ok()?;
    let host = u.host_str()?.to_string();
    let port = u.port().unwrap_or(51820);
    let map = query_map(&u);
    let mut srv = base_server(&name, &host, port, Protocol::Wireguard, link);
    srv.params.private_key = Some(pct_decode(u.username()));
    srv.params.peer_public = opt(&map, "peerpubkey").or_else(|| opt(&map, "publickey"));
    srv.params.psk = opt(&map, "presharedkey").or_else(|| opt(&map, "psk"));
    if let Some(addrs) = opt(&map, "address") {
        srv.params.local_addrs = addrs.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect();
    }
    if let Some(res) = opt(&map, "reserved") {
        srv.params.reserved = res
            .split(&[',', '/'][..])
            .filter_map(|x| x.trim().parse::<u8>().ok())
            .collect();
    }
    Some(srv)
}

// ────────────────────────── прочие sing-box протоколы ──────────────────────────

fn parse_anytls(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("anytls://")?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("anytls://{body}")).ok()?;
    let map = query_map(&u);
    let mut srv = base_server(&name, u.host_str()?, u.port().unwrap_or(443), Protocol::Anytls, link);
    srv.params.password = Some(pct_decode(u.username()));
    srv.params.tls = Some(TlsParams {
        sni: opt(&map, "sni"),
        fingerprint: opt(&map, "fp"),
        insecure: bool_param(&map, "insecure"),
        ..Default::default()
    });
    Some(srv)
}

fn parse_shadowtls(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("shadowtls://")?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("shadowtls://{body}")).ok()?;
    let map = query_map(&u);
    let mut srv = base_server(&name, u.host_str()?, u.port().unwrap_or(443), Protocol::Shadowtls, link);
    srv.params.password = Some(pct_decode(u.username()));
    srv.params.tls = Some(TlsParams {
        sni: opt(&map, "sni"),
        fingerprint: opt(&map, "fp"),
        insecure: bool_param(&map, "insecure"),
        ..Default::default()
    });
    if let Some(v) = opt(&map, "version") {
        // хранится в congestion_control как временное поле не хочется —
        // кладём версию в method (sv 3/2/1 используется только sing-box)
        srv.params.method = Some(v);
    }
    Some(srv)
}

fn parse_naive(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("naive://").or_else(|| link.strip_prefix("naive+https://"))?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("naive://{body}")).ok()?;
    let map = query_map(&u);
    let mut srv = base_server(&name, u.host_str()?, u.port().unwrap_or(443), Protocol::Naive, link);
    srv.params.username = Some(pct_decode(u.username()));
    srv.params.password = u.password().map(pct_decode);
    srv.params.tls = Some(TlsParams {
        sni: opt(&map, "sni"),
        insecure: bool_param(&map, "insecure"),
        ..Default::default()
    });
    Some(srv)
}

fn parse_ssh(link: &str) -> Option<Server> {
    let rest = link.strip_prefix("ssh://")?;
    let (body, name) = match rest.split_once('#') {
        Some((b, n)) => (b.to_string(), pct_decode(n)),
        None => (rest.to_string(), String::new()),
    };
    let u = url::Url::parse(&format!("ssh://{body}")).ok()?;
    let map = query_map(&u);
    let mut srv = base_server(&name, u.host_str()?, u.port().unwrap_or(22), Protocol::Ssh, link);
    srv.params.user = Some(pct_decode(u.username()));
    srv.params.password = u.password().map(pct_decode);
    srv.params.host_key = opt(&map, "hostKey").or_else(|| opt(&map, "host-key"));
    Some(srv)
}

fn parse_ssr(link: &str) -> Option<Server> {
    // Распознаём, но помечаем неподдерживаемым (не входит в современные ядра).
    let payload = link.strip_prefix("ssr://")?;
    let decoded = b64_str(payload)?;
    let (main, name) = match decoded.split_once('/') {
        Some((m, tail)) => (m.to_string(), tail.split(':').last().unwrap_or("").to_string()),
        None => (decoded.clone(), String::new()),
    };
    // main: host:port:proto:method:obfs:b64pass/?obfsparam=&protoparam=
    let parts: Vec<&str> = main.split(':').collect();
    if parts.len() < 6 {
        return None;
    }
    let mut srv = base_server(&name, parts[0], parts[1].parse().ok()?, Protocol::Ssr, link);
    srv.params.method = Some(parts[3].to_string());
    srv.params.password = b64_str(parts[5]);
    Some(srv)
}

// Небольшой трейт для выражений вида `x.pipe(f)` в стиле конвейера.
trait Pipe: Sized {
    fn pipe<F: FnOnce(Self) -> Self>(self, f: F) -> Self {
        f(self)
    }
}
impl<T> Pipe for T {}

// ────────────────────────── тесты ──────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vmess_json_link() {
        let json = serde_json::json!({
            "v":"2","ps":"Тест DE","add":"de.example.com","port":"443","id":"b831381d-6324-4d53-ad4f-8cda48b30811",
            "aid":"0","scy":"auto","net":"ws","type":"none","host":"cdn.example.com","path":"/ws","tls":"tls","sni":"de.example.com","fp":"chrome"
        }).to_string();
        use base64::Engine;
        let b64 = base64::engine::general_purpose::STANDARD.encode(json);
        let s = parse_link(&format!("vmess://{b64}")).unwrap();
        assert_eq!(s.protocol, Protocol::Vmess);
        assert_eq!(s.host, "de.example.com");
        assert_eq!(s.port, 443);
        assert_eq!(s.name, "Тест DE");
        assert_eq!(s.params.uuid.unwrap(), "b831381d-6324-4d53-ad4f-8cda48b30811");
        assert_eq!(s.params.alter_id.unwrap(), 0);
        assert_eq!(s.params.transport.unwrap().kind, TransportKind::Ws);
        let tls = s.params.tls.unwrap();
        assert_eq!(tls.sni.unwrap(), "de.example.com");
        assert_eq!(tls.fingerprint.unwrap(), "chrome");
    }

    #[test]
    fn vless_reality() {
        let link = "vless://b831381d-6324-4d53-ad4f-8cda48b30811@1.2.3.4:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.microsoft.com&fp=chrome&pbk=SOu7M8PU&sid=6ba85179&type=tcp#RU%20Reality";
        let s = parse_link(link).unwrap();
        assert_eq!(s.protocol, Protocol::Vless);
        assert_eq!(s.params.flow.as_deref(), Some("xtls-rprx-vision"));
        let tls = s.params.tls.unwrap();
        assert_eq!(tls.reality_pub.as_deref(), Some("SOu7M8PU"));
        assert_eq!(tls.reality_sid.as_deref(), Some("6ba85179"));
        assert_eq!(tls.sni.as_deref(), Some("www.microsoft.com"));
        assert_eq!(s.name, "RU Reality");
    }

    #[test]
    fn vless_ws() {
        let link = "vless://uuid@cd.example.com:2053?security=tls&type=ws&path=%2Fray&host=cd.example.com&fp=firefox&alpn=h2%2Chttp%2F1.1#CF%20ws";
        let s = parse_link(link).unwrap();
        let t = s.params.transport.unwrap();
        assert_eq!(t.kind, TransportKind::Ws);
        assert_eq!(t.path.as_deref(), Some("/ray"));
        assert_eq!(t.host.as_deref(), Some("cd.example.com"));
        let tls = s.params.tls.unwrap();
        assert_eq!(tls.alpn, vec!["h2", "http/1.1"]);
        assert_eq!(tls.fingerprint.as_deref(), Some("firefox"));
    }

    #[test]
    fn trojan_grpc() {
        let link = "trojan://passw0rd@9.9.9.9:443?security=tls&sni=t.example.com&type=grpc&serviceName=grpcSrv#TR";
        let s = parse_link(link).unwrap();
        assert_eq!(s.params.password.as_deref(), Some("passw0rd"));
        let t = s.params.transport.unwrap();
        assert_eq!(t.kind, TransportKind::Grpc);
        assert_eq!(t.service_name.as_deref(), Some("grpcSrv"));
        assert!(s.params.tls.is_some());
    }

    #[test]
    fn ss_sip002() {
        use base64::Engine;
        let userinfo = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode("aes-256-gcm:secretpw");
        let link = format!("ss://{userinfo}@1.3.3.7:8388#SS%20node");
        let s = parse_link(&link).unwrap();
        assert_eq!(s.protocol, Protocol::Shadowsocks);
        assert_eq!(s.params.method.as_deref(), Some("aes-256-gcm"));
        assert_eq!(s.params.password.as_deref(), Some("secretpw"));
        assert_eq!(s.port, 8388);
    }

    #[test]
    fn ss_legacy_full_b64() {
        use base64::Engine;
        let inner = base64::engine::general_purpose::STANDARD.encode("chacha20-ietf-poly1305:pw@5.6.7.8:443");
        let link = format!("ss://{inner}#old_node");
        let s = parse_link(&link).unwrap();
        assert_eq!(s.host, "5.6.7.8");
        assert_eq!(s.port, 443);
        assert_eq!(s.params.method.as_deref(), Some("chacha20-ietf-poly1305"));
        assert_eq!(s.params.password.as_deref(), Some("pw"));
        assert_eq!(s.name, "old_node");
    }

    #[test]
    fn ss_with_plugin() {
        use base64::Engine;
        let userinfo = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode("aes-128-gcm:pw");
        let link = format!("ss://{userinfo}@2.2.2.2:443?plugin=obfs-local%3Bobfs%3Dhttp%3Bobfs-host%3Dcdn.example.com#p");
        let s = parse_link(&link).unwrap();
        assert_eq!(s.params.plugin.as_deref(), Some("obfs-local"));
        assert_eq!(s.params.plugin_opts.as_deref(), Some("obfs=http;obfs-host=cdn.example.com"));
    }

    #[test]
    fn hysteria2() {
        let link = "hysteria2://secretpw@3.3.3.3:8443?sni=h.example.com&insecure=1&obfs=salamander&obfs-password=obpw#HY2";
        let s = parse_link(link).unwrap();
        assert_eq!(s.protocol, Protocol::Hysteria2);
        assert_eq!(s.params.password.as_deref(), Some("secretpw"));
        assert_eq!(s.params.obfs.as_deref(), Some("salamander"));
        assert_eq!(s.params.obfs_password.as_deref(), Some("obpw"));
        let tls = s.params.tls.unwrap();
        assert!(tls.insecure);
        assert_eq!(tls.alpn, vec!["h3"]);
    }

    #[test]
    fn hy2_short_scheme() {
        let link = "hy2://pw@hy.example.com:443#fast";
        let s = parse_link(link).unwrap();
        assert_eq!(s.protocol, Protocol::Hysteria2);
        assert_eq!(s.host, "hy.example.com");
        assert_eq!(s.name, "fast");
    }

    #[test]
    fn hysteria1() {
        let link = "hysteria://4.4.4.4:36712?auth=str0ng&upmbps=50&downmbps=200&peer=hy1.example.com&insecure=1#HY1";
        let s = parse_link(link).unwrap();
        assert_eq!(s.protocol, Protocol::Hysteria);
        assert_eq!(s.params.auth_str.as_deref(), Some("str0ng"));
        assert_eq!(s.params.up_mbps, Some(50));
        assert_eq!(s.params.down_mbps, Some(200));
        let tls = s.params.tls.unwrap();
        assert_eq!(tls.sni.as_deref(), Some("hy1.example.com"));
        assert_eq!(tls.alpn, vec!["h3"]);
    }

    #[test]
    fn tuic() {
        let link = "tuic://uuid-here:pass@5.5.5.5:443?congestion_control=bbr&udp_relay_mode=native&alpn=h3&sni=tu.example.com#TUIC";
        let s = parse_link(link).unwrap();
        assert_eq!(s.protocol, Protocol::Tuic);
        assert_eq!(s.params.uuid.as_deref(), Some("uuid-here"));
        assert_eq!(s.params.password.as_deref(), Some("pass"));
        assert_eq!(s.params.congestion_control.as_deref(), Some("bbr"));
        assert_eq!(s.params.udp_relay_mode.as_deref(), Some("native"));
    }

    #[test]
    fn socks_and_http() {
        let s = parse_link("socks://user:p%40ss@6.6.6.6:1080#socksy").unwrap();
        assert_eq!(s.protocol, Protocol::Socks);
        assert_eq!(s.params.username.as_deref(), Some("user"));
        assert_eq!(s.params.password.as_deref(), Some("p@ss"));
        let h = parse_link("http://7.7.7.7:8080#httpproxy").unwrap();
        assert_eq!(h.protocol, Protocol::Http);
        assert_eq!(h.port, 8080);
        let hs = parse_link("https://8.8.8.8:8443#securehttp").unwrap();
        assert!(hs.params.tls.is_some());
    }

    #[test]
    fn anytls_and_ssh() {
        let a = parse_link("anytls://pass@9.1.1.1:8443?sni=a.example.com#AnyTLS").unwrap();
        assert_eq!(a.protocol, Protocol::Anytls);
        let sh = parse_link("ssh://root:toor@9.2.2.2:22#sshnode").unwrap();
        assert_eq!(sh.protocol, Protocol::Ssh);
        assert_eq!(sh.params.user.as_deref(), Some("root"));
    }

    #[test]
    fn wireguard() {
        let link = "wireguard://privkeybase64=@9.3.3.3:51820?peerpubkey=PK&address=172.16.0.2%2F32&reserved=1%2C2%2C3#WG";
        let s = parse_link(link).unwrap();
        assert_eq!(s.protocol, Protocol::Wireguard);
        assert_eq!(s.params.peer_public.as_deref(), Some("PK"));
        assert_eq!(s.params.local_addrs, vec!["172.16.0.2/32"]);
        assert_eq!(s.params.reserved, vec![1, 2, 3]);
    }

    #[test]
    fn ssr_recognized_unsupported() {
        assert_eq!(parse_link("ssr://garbage").is_none(), true);
    }

    #[test]
    fn subscription_base64_body() {
        use base64::Engine;
        let links = "vless://u@10.0.0.1:443?a#One\ntrojan://p@10.0.0.2:443#Two\n".to_string();
        let b64 = base64::engine::general_purpose::STANDARD.encode(links);
        let servers = parse_subscription(&b64);
        assert_eq!(servers.len(), 2);
        assert_eq!(servers[0].name, "One");
        assert_eq!(servers[1].protocol, Protocol::Trojan);
    }

    #[test]
    fn subscription_plain_body() {
        let body = "vless://u@10.0.0.1:443#A\nvmess://garbage-not-b64\nhy2://p@10.0.0.3:443#C";
        let servers = parse_subscription(body);
        assert_eq!(servers.len(), 2);
    }

    #[test]
    fn subscription_sip008_json() {
        let body = serde_json::json!({"servers":[
            {"remarks":"n1","server":"1.1.1.1","server_port":443,"type":"vless","uuid":"u1"},
            {"remarks":"n2","server":"2.2.2.2","server_port":8388,"type":"shadowsocks","method":"aes-256-gcm","password":"pw"}
        ]}).to_string();
        let servers = parse_subscription(&body);
        assert_eq!(servers.len(), 2);
        assert_eq!(servers[0].protocol, Protocol::Vless);
        assert_eq!(servers[1].params.method.as_deref(), Some("aes-256-gcm"));
    }

    #[test]
    fn dedup_works() {
        let body = "vless://u@10.0.0.1:443#A\nvless://u@10.0.0.1:443#A\n";
        assert_eq!(parse_subscription(body).len(), 1);
    }

    #[test]
    fn ipv6_host() {
        let s = parse_link("vless://u@[2001:db8::1]:443#v6").unwrap();
        assert_eq!(s.host, "2001:db8::1");
        assert_eq!(s.port, 443);
    }

    #[test]
    fn names_with_spaces_do_not_create_duplicates() {
        // Имя ноды с пробелами без percent-кодирования: раньше split_whitespace
        // порождал вторую, «обрезанную» ноду с именем из одного флага.
        let body = "vless://u@10.0.0.1:443?security=none#\u{1F1E9}\u{1F1EA} Germany 1\nvless://u@10.0.0.2:443#Plain Name";
        let servers = parse_subscription(body);
        assert_eq!(servers.len(), 2, "{servers:?}");
        assert_eq!(servers[0].name, "\u{1F1E9}\u{1F1EA} Germany 1");
        assert_eq!(servers[1].name, "Plain Name");
    }

    #[test]
    fn space_separated_links_on_one_line_still_parse() {
        let body = "vless://u@10.0.0.1:443#A vless://u@10.0.0.2:443#B";
        assert_eq!(parse_subscription(body).len(), 2);
    }

    #[test]
    fn ss_2022_plain_userinfo() {
        let s = parse_link("ss://2022-blake3-aes-256-gcm:c2VjcmV0S2V5MTIzNDU2Nzg5MDEyMzQ1Njc4OTA%3D@1.2.3.4:8388#ss22").unwrap();
        assert_eq!(s.params.method.as_deref(), Some("2022-blake3-aes-256-gcm"));
        assert_eq!(s.params.password.as_deref(), Some("c2VjcmV0S2V5MTIzNDU2Nzg5MDEyMzQ1Njc4OTA="));
        assert_eq!(s.port, 8388);
    }

    #[test]
    fn ss_sip002_base64_with_percent_encoded_padding() {
        use base64::Engine;
        // base64("aes-128-gcm:p") = "YWVzLTEyOC1nY206cA==" — '=' приходит как %3D
        let enc = base64::engine::general_purpose::STANDARD.encode("aes-128-gcm:p").replace('=', "%3D");
        let s = parse_link(&format!("ss://{enc}@5.5.5.5:443#x")).unwrap();
        assert_eq!(s.params.method.as_deref(), Some("aes-128-gcm"));
        assert_eq!(s.params.password.as_deref(), Some("p"));
    }

    #[test]
    fn vless_encryption_is_kept() {
        let s = parse_link("vless://u@1.1.1.1:443?encryption=mlkem768x25519plus.native.0rtt.KEY&security=none#e").unwrap();
        assert_eq!(s.params.encryption.as_deref(), Some("mlkem768x25519plus.native.0rtt.KEY"));
        let n = parse_link("vless://u@1.1.1.1:443?encryption=none#e").unwrap();
        assert_eq!(n.params.encryption, None);
    }

    #[test]
    fn xhttp_mode_and_extra() {
        let s = parse_link("vless://u@1.1.1.1:443?type=xhttp&path=%2Fx&host=h.com&mode=packet-up&extra=%7B%22xPaddingBytes%22%3A%22100-200%22%7D&security=tls&sni=h.com#x").unwrap();
        let t = s.params.transport.unwrap();
        assert_eq!(t.kind, TransportKind::Xhttp);
        assert_eq!(t.mode.as_deref(), Some("packet-up"));
        assert_eq!(t.extra.as_deref(), Some("{\"xPaddingBytes\":\"100-200\"}"));
    }

    #[test]
    fn vmess_tcp_http_obfuscation() {
        use base64::Engine;
        let json = serde_json::json!({"v":"2","ps":"o","add":"5.6.7.8","port":"80","id":"u","aid":"0","net":"tcp","type":"http","host":"a.com","path":"/"}).to_string();
        let b64 = base64::engine::general_purpose::STANDARD.encode(json);
        let s = parse_link(&format!("vmess://{b64}")).unwrap();
        let t = s.params.transport.unwrap();
        assert_eq!(t.kind, TransportKind::Http);
        assert!(t.http_method.is_some(), "должен быть маркер tcp+http-обфускации");
    }
}
