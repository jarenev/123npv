//! TCP-пинг серверов: время установления TCP-соединения (как у большинства
//! мобильных VPN-клиентов — ICMP на Android без root недоступен).

use crate::model::{MeasuredServer, Protocol, Server};
use std::net::{IpAddr, TcpStream, ToSocketAddrs};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

const DEFAULT_TIMEOUT: Duration = Duration::from_secs(3);
const MAX_CONCURRENCY: usize = 16;

/// Условная задержка для UDP-протоколов (hysteria/tuic/wireguard): TCP-пинг к ним
/// невозможен (порт слушает UDP), реальный RTT без протокола не измерить.
/// Берём оценку выше типичного TCP-пинга, чтобы измеримые TCP-серверы
/// выбирались первыми, а UDP-серверы оставались полноценным запасным вариантом.
pub const UDP_ASSUMED_MS: u32 = 150;

/// Протоколы поверх UDP/QUIC: слушают UDP-порт, на TCP connect не отвечают.
pub fn is_udp_protocol(p: Protocol) -> bool {
    matches!(
        p,
        Protocol::Hysteria | Protocol::Hysteria2 | Protocol::Tuic | Protocol::Wireguard
    )
}

/// Резолв имени в IPv4 (предпочтительно) через системный резолвер.
/// IP-литералы возвращаются как есть, без обращения к DNS.
pub fn resolve_ip(host: &str, port: u16) -> Option<IpAddr> {
    if let Ok(ip) = host.parse::<IpAddr>() {
        return Some(ip);
    }
    let addrs: Vec<_> = (host, port).to_socket_addrs().ok()?.collect();
    addrs
        .iter()
        .find(|a| a.is_ipv4())
        .or_else(|| addrs.first())
        .map(|a| a.ip())
}

/// Проверка доступности сервера с учётом типа протокола:
/// TCP-протоколы — TCP connect; UDP-протоколы — резолв адреса (+ условная задержка).
pub fn probe(server: &Server, timeout: Duration) -> Option<u32> {
    if is_udp_protocol(server.protocol) {
        let start = Instant::now();
        resolve_ip(&server.host, server.port)?;
        let resolve_ms = start.elapsed().as_millis().min(u32::MAX as u128 / 2) as u32;
        return Some(UDP_ASSUMED_MS + resolve_ms);
    }
    tcp_ping(&server.host, server.port, timeout)
}

/// Одно измерение: TCP connect. Возвращает мс или None (недоступен).
pub fn tcp_ping(host: &str, port: u16, timeout: Duration) -> Option<u32> {
    // Резолвим домен (в потоке VPN наш UID исключён из VPN — соединения идут напрямую).
    let addrs: Vec<_> = (host, port)
        .to_socket_addrs()
        .ok()?
        .filter(|a| a.is_ipv4()) // ядро-IPv4 стек; AAAA отфильтрованы
        .collect();
    let addrs = if addrs.is_empty() {
        (host, port).to_socket_addrs().ok()?.collect::<Vec<_>>()
    } else {
        addrs
    };

    for addr in addrs {
        let start = Instant::now();
        if TcpStream::connect_timeout(&addr, timeout).is_ok() {
            return Some(start.elapsed().as_millis().min(u32::MAX as u128) as u32);
        }
    }
    None
}

/// Пингует все серверы параллельно, возвращает в исходном порядке.
pub fn ping_all(servers: &[Server]) -> Vec<MeasuredServer> {
    let results: Arc<Mutex<Vec<Option<u32>>>> =
        Arc::new(Mutex::new(vec![None; servers.len()]));
    let mut handles = Vec::new();
    for chunk_start in (0..servers.len()).step_by(MAX_CONCURRENCY) {
        let chunk_end = (chunk_start + MAX_CONCURRENCY).min(servers.len());
        for (i, srv) in servers[chunk_start..chunk_end].iter().enumerate() {
            let results = Arc::clone(&results);
            let idx = chunk_start + i;
            let srv = srv.clone();
            handles.push(std::thread::spawn(move || {
                let ms = probe(&srv, DEFAULT_TIMEOUT);
                results.lock().unwrap()[idx] = ms;
            }));
        }
    }
    for h in handles {
        let _ = h.join();
    }

    let results = results.lock().unwrap().clone();
    servers
        .iter()
        .enumerate()
        .map(|(i, s)| MeasuredServer {
            server: s.clone(),
            latency_ms: results[i],
        })
        .collect()
}

/// Разовая проверка живости (используется failover-монитором).
pub fn is_alive(server: &Server, timeout: Duration) -> bool {
    probe(server, timeout).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn localhost_ping_works() {
        // TCP-эхо на 127.0.0.1: слушатель поднимаем сами
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        std::thread::spawn(move || {
            for c in listener.incoming() {
                drop(c);
            }
        });
        let ms = tcp_ping("127.0.0.1", port, Duration::from_secs(1));
        assert!(ms.is_some());
    }

    #[test]
    fn closed_port_is_none() {
        // порт 9 (discard) на localhost почти наверняка закрыт
        let ms = tcp_ping("127.0.0.1", 9, Duration::from_millis(300));
        assert!(ms.is_none());
    }

    #[test]
    fn udp_protocols_are_not_tcp_probed() {
        // hysteria2 на закрытом TCP-порту: раньше такой сервер считался мёртвым.
        let srv = crate::links::parse_link("hysteria2://pw@127.0.0.1:9?sni=a.com#u").unwrap();
        let ms = probe(&srv, Duration::from_millis(300));
        assert_eq!(ms, Some(UDP_ASSUMED_MS));
        assert!(is_alive(&srv, Duration::from_millis(300)));
        // а TCP-протокол на том же закрытом порту — мёртв
        let tcp = crate::links::parse_link("vless://u@127.0.0.1:9#t").unwrap();
        assert_eq!(probe(&tcp, Duration::from_millis(300)), None);
    }

    #[test]
    fn resolve_ip_literal_and_localhost() {
        assert_eq!(resolve_ip("1.2.3.4", 443), Some("1.2.3.4".parse().unwrap()));
        assert_eq!(resolve_ip("2001:db8::1", 443), Some("2001:db8::1".parse().unwrap()));
        assert!(resolve_ip("localhost", 80).is_some());
        assert_eq!(resolve_ip("no-such-host.invalid", 80), None);
    }
}
