//! Генератор конфига sing-box (схема 1.14.x, проверена по официальной
//! документации sing-box.sagernet.org).

use crate::model::*;
use serde_json::{json, Map, Value};

fn s(v: &Option<String>) -> Value {
    v.as_ref().map(|x| Value::String(x.clone())).unwrap_or(Value::Null)
}

/// TLS-блок sing-box.
fn tls_block(srv: &Server) -> Value {
    let Some(t) = &srv.params.tls else { return Value::Null };
    let mut obj = Map::new();
    obj.insert("enabled".into(), json!(true));
    obj.insert("server_name".into(), t.sni.clone().map(Value::String).unwrap_or(json!(srv.host)));
    obj.insert("insecure".into(), json!(t.insecure));
    if !t.alpn.is_empty() {
        obj.insert("alpn".into(), json!(t.alpn));
    }
    // REALITY в sing-box работает только поверх uTLS — без fingerprint ядро не стартует.
    let fp = t.fingerprint.clone().or_else(|| t.reality_pub.as_ref().map(|_| "chrome".to_string()));
    if let Some(fp) = fp {
        obj.insert("utls".into(), json!({"enabled": true, "fingerprint": fp}));
    }
    if let Some(pbk) = &t.reality_pub {
        obj.insert("reality".into(), json!({
            "enabled": true,
            "public_key": pbk,
            "short_id": t.reality_sid.clone().unwrap_or_default(),
        }));
    }
    Value::Object(obj)
}

/// Транспорт sing-box (только для vmess/vless/trojan; plain TCP = без блока).
fn transport_block(srv: &Server) -> Value {
    let Some(t) = &srv.params.transport else { return Value::Null };
    match t.kind {
        TransportKind::Tcp => Value::Null,
        TransportKind::Ws => {
            let mut o = Map::new();
            o.insert("type".into(), json!("ws"));
            o.insert("path".into(), s(&t.path));
            if let Some(h) = &t.host {
                o.insert("headers".into(), json!({"Host": h}));
            }
            Value::Object(o)
        }
        TransportKind::Grpc => json!({
            "type": "grpc",
            "service_name": t.service_name.clone().unwrap_or_else(|| "grpcSrv".into()),
        }),
        TransportKind::Http => {
            if t.http_method.is_some() {
                // tcp+http-обфускация в sing-box не поддерживается — оставляем tcp
                Value::Null
            } else {
                let mut o = Map::new();
                o.insert("type".into(), json!("http"));
                if let Some(h) = &t.host {
                    o.insert("host".into(), json!([h]));
                }
                o.insert("path".into(), t.path.clone().map(Value::String).unwrap_or(json!("/")));
                Value::Object(o)
            }
        }
        TransportKind::HttpUpgrade => {
            let mut o = Map::new();
            o.insert("type".into(), json!("httpupgrade"));
            o.insert("path".into(), s(&t.path));
            o.insert("host".into(), s(&t.host));
            Value::Object(o)
        }
        TransportKind::Xhttp => {
            // sing-box не знает xhttp — ближайший аналог http
            let mut o = Map::new();
            o.insert("type".into(), json!("http"));
            if let Some(h) = &t.host {
                o.insert("host".into(), json!([h]));
            }
            o.insert("path".into(), s(&t.path));
            Value::Object(o)
        }
    }
}

fn proxy_outbound(srv: &Server) -> Value {
    let server = &srv.host;
    let port = srv.port;
    let mut out = Map::new();
    out.insert("tag".into(), json!("proxy"));

    match srv.protocol {
        Protocol::Vmess => {
            out.insert("type".into(), json!("vmess"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("uuid".into(), json!(srv.params.uuid.clone().unwrap_or_default()));
            out.insert("security".into(), json!(srv.params.security.clone().unwrap_or_else(|| "auto".into())));
            out.insert("alter_id".into(), json!(srv.params.alter_id.unwrap_or(0)));
            let tls = tls_block(srv);
            if !tls.is_null() { out.insert("tls".into(), tls); }
            let tr = transport_block(srv);
            if !tr.is_null() { out.insert("transport".into(), tr); }
            out.insert("packet_encoding".into(), json!("xudp"));
        }
        Protocol::Vless => {
            out.insert("type".into(), json!("vless"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("uuid".into(), json!(srv.params.uuid.clone().unwrap_or_default()));
            if let Some(f) = &srv.params.flow {
                out.insert("flow".into(), json!(f));
            }
            let tls = tls_block(srv);
            if !tls.is_null() { out.insert("tls".into(), tls); }
            let tr = transport_block(srv);
            if !tr.is_null() { out.insert("transport".into(), tr); }
            out.insert("packet_encoding".into(), json!("xudp"));
        }
        Protocol::Trojan => {
            out.insert("type".into(), json!("trojan"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            let tls = tls_block(srv);
            if !tls.is_null() { out.insert("tls".into(), tls); }
            let tr = transport_block(srv);
            if !tr.is_null() { out.insert("transport".into(), tr); }
        }
        Protocol::Shadowsocks => {
            out.insert("type".into(), json!("shadowsocks"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("method".into(), json!(srv.params.method.clone().unwrap_or_else(|| "aes-256-gcm".into())));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            if let (Some(p), Some(o)) = (&srv.params.plugin, &srv.params.plugin_opts) {
                out.insert("plugin".into(), json!(p));
                out.insert("plugin_opts".into(), json!(o));
            }
        }
        Protocol::Socks => {
            out.insert("type".into(), json!("socks"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("version".into(), json!("5"));
            if srv.params.username.is_some() {
                out.insert("username".into(), json!(srv.params.username.clone().unwrap_or_default()));
                out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            }
        }
        Protocol::Http => {
            out.insert("type".into(), json!("http"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            if srv.params.username.is_some() {
                out.insert("username".into(), json!(srv.params.username.clone().unwrap_or_default()));
                out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            }
            let tls = tls_block(srv);
            if !tls.is_null() { out.insert("tls".into(), tls); }
        }
        Protocol::Hysteria => {
            out.insert("type".into(), json!("hysteria"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("auth_str".into(), json!(srv.params.auth_str.clone().unwrap_or_default()));
            // hysteria v1 без лимитов скорости не стартует («missing upload speed»)
            out.insert("up_mbps".into(), json!(srv.params.up_mbps.unwrap_or(50)));
            out.insert("down_mbps".into(), json!(srv.params.down_mbps.unwrap_or(100)));
            if let Some(o) = &srv.params.obfs {
                if !o.is_empty() { out.insert("obfs".into(), json!(o)); }
            }
            let mut tls = tls_block(srv);
            // hysteria требует ALPN h3
            if let Value::Object(ref mut m) = tls {
                m.insert("alpn".into(), json!(["h3"]));
            }
            out.insert("tls".into(), tls);
        }
        Protocol::Hysteria2 => {
            out.insert("type".into(), json!("hysteria2"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            if let (Some(kind), Some(pw)) = (&srv.params.obfs, &srv.params.obfs_password) {
                out.insert("obfs".into(), json!({"type": kind, "password": pw}));
            }
            if let Some(u) = srv.params.up_mbps { out.insert("up_mbps".into(), json!(u)); }
            if let Some(d) = srv.params.down_mbps { out.insert("down_mbps".into(), json!(d)); }
            let mut tls = tls_block(srv);
            if let Value::Object(ref mut m) = tls {
                m.insert("alpn".into(), json!(["h3"]));
            }
            out.insert("tls".into(), tls);
        }
        Protocol::Tuic => {
            out.insert("type".into(), json!("tuic"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("uuid".into(), json!(srv.params.uuid.clone().unwrap_or_default()));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            out.insert("congestion_control".into(), json!(srv.params.congestion_control.clone().unwrap_or_else(|| "cubic".into())));
            out.insert("udp_relay_mode".into(), json!(srv.params.udp_relay_mode.clone().unwrap_or_else(|| "native".into())));
            let mut tls = tls_block(srv);
            if let Value::Object(ref mut m) = tls {
                m.insert("alpn".into(), json!(["h3"]));
            }
            out.insert("tls".into(), tls);
        }
        Protocol::Wireguard => {
            out.insert("type".into(), json!("wireguard"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("local_address".into(), json!(srv.params.local_addrs.clone()));
            out.insert("private_key".into(), json!(srv.params.private_key.clone().unwrap_or_default()));
            out.insert("peer_public_key".into(), json!(srv.params.peer_public.clone().unwrap_or_default()));
            if !srv.params.reserved.is_empty() {
                out.insert("reserved".into(), json!(srv.params.reserved.clone()));
            }
            out.insert("mtu".into(), json!(1408));
        }
        Protocol::Anytls => {
            out.insert("type".into(), json!("anytls"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            let tls = tls_block(srv);
            if !tls.is_null() { out.insert("tls".into(), tls); }
        }
        Protocol::Shadowtls => {
            out.insert("type".into(), json!("shadowtls"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("version".into(), json!(srv.params.method.clone().and_then(|v| v.parse().ok()).unwrap_or(3)));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            // shadowtls использует tls-блок для обёртки (server_name обязателен)
            let mut tls = tls_block(srv);
            if tls.is_null() {
                tls = json!({"enabled": true, "server_name": server});
            }
            out.insert("tls".into(), tls);
        }
        Protocol::Naive => {
            out.insert("type".into(), json!("naive"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("username".into(), json!(srv.params.username.clone().unwrap_or_default()));
            out.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            out.insert("tls".into(), tls_block(srv));
        }
        Protocol::Ssh => {
            out.insert("type".into(), json!("ssh"));
            out.insert("server".into(), json!(server));
            out.insert("server_port".into(), json!(port));
            out.insert("user".into(), json!(srv.params.user.clone().unwrap_or_else(|| "root".into())));
            if let Some(p) = &srv.params.password {
                out.insert("password".into(), json!(p));
            }
            if let Some(hk) = &srv.params.host_key {
                out.insert("host_key".into(), json!([hk]));
            }
        }
        _ => {
            out.insert("type".into(), json!("direct"));
        }
    }
    Value::Object(out)
}

/// Полный конфиг sing-box: SOCKS-вход + прокси-выход (первый = default) + direct.
pub fn build(srv: &Server, socks_port: u16) -> Value {
    json!({
        "log": {"level": "warn"},
        "inbounds": [{
            "type": "socks",
            "tag": "socks-in",
            "listen": "127.0.0.1",
            "listen_port": socks_port,
            "users": []
        }],
        "outbounds": [
            proxy_outbound(srv),
            {"type": "direct", "tag": "direct"}
        ],
        "route": {
            "rules": [
                {"action": "sniff"},
                {"ip_is_private": true, "outbound": "direct"}
            ],
            "final": "proxy"
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn singbox_hysteria2() {
        let srv = crate::links::parse_link(
            "hysteria2://pw@1.2.3.4:8443?sni=h.com&insecure=1&obfs=salamander&obfs-password=o&up=30&down=100#n"
        ).unwrap();
        let cfg = build(&srv, 1080);
        assert_eq!(cfg["inbounds"][0]["type"], "socks");
        assert_eq!(cfg["inbounds"][0]["listen_port"], 1080);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["type"], "hysteria2");
        assert_eq!(out["server"], "1.2.3.4");
        assert_eq!(out["password"], "pw");
        assert_eq!(out["obfs"]["type"], "salamander");
        assert_eq!(out["up_mbps"], 30);
        assert_eq!(out["tls"]["alpn"][0], "h3");
        assert_eq!(out["tls"]["insecure"], true);
        assert_eq!(cfg["route"]["final"], "proxy");
    }

    #[test]
    fn singbox_vless_reality() {
        let srv = crate::links::parse_link(
            "vless://uuid@1.2.3.4:443?flow=xtls-rprx-vision&security=reality&sni=a.com&fp=chrome&pbk=PK&sid=ff&type=tcp#n"
        ).unwrap();
        let cfg = build(&srv, 1080);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["type"], "vless");
        assert_eq!(out["flow"], "xtls-rprx-vision");
        assert_eq!(out["tls"]["reality"]["public_key"], "PK");
        assert_eq!(out["tls"]["reality"]["short_id"], "ff");
        assert_eq!(out["tls"]["utls"]["fingerprint"], "chrome");
    }

    #[test]
    fn singbox_tuic() {
        let srv = crate::links::parse_link(
            "tuic://uid:pw@5.5.5.5:443?congestion_control=bbr&udp_relay_mode=native&sni=t.com#n"
        ).unwrap();
        let cfg = build(&srv, 1080);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["type"], "tuic");
        assert_eq!(out["uuid"], "uid");
        assert_eq!(out["congestion_control"], "bbr");
        assert_eq!(out["udp_relay_mode"], "native");
        assert_eq!(out["tls"]["alpn"][0], "h3");
    }

    #[test]
    fn singbox_vmess_ws() {
        use base64::Engine;
        let json = serde_json::json!({
            "v":"2","ps":"n","add":"5.6.7.8","port":"443","id":"u","aid":"0","scy":"auto",
            "net":"ws","host":"cdn.com","path":"/v","tls":"tls","sni":"cdn.com"
        }).to_string();
        let b64 = base64::engine::general_purpose::STANDARD.encode(json);
        let srv = crate::links::parse_link(&format!("vmess://{b64}")).unwrap();
        let cfg = build(&srv, 10808);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["type"], "vmess");
        assert_eq!(out["transport"]["type"], "ws");
        assert_eq!(out["transport"]["headers"]["Host"], "cdn.com");
        assert_eq!(out["tls"]["server_name"], "cdn.com");
    }

    #[test]
    fn singbox_wireguard() {
        let srv = crate::links::parse_link(
            "wireguard://priv@9.3.3.3:51820?peerpubkey=PK&address=10.7.0.2%2F32&reserved=1,2,3#WG"
        ).unwrap();
        let cfg = build(&srv, 1080);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["type"], "wireguard");
        assert_eq!(out["local_address"][0], "10.7.0.2/32");
        assert_eq!(out["reserved"][0], 1);
        assert_eq!(out["peer_public_key"], "PK");
    }

    #[test]
    fn all_outbound_json_serializes() {
        // Прогоняем через конфиг все распознаваемые протоколы — JSON должен собраться.
        let links = [
            "vless://u@1.1.1.1:443#n",
            "trojan://p@1.1.1.1:443#n",
            "hysteria2://p@1.1.1.1:443#n",
            "hysteria://p@1.1.1.1:443?auth=x#n",
            "tuic://u:p@1.1.1.1:443#n",
            "anytls://p@1.1.1.1:443#n",
            "shadowtls://p@1.1.1.1:443#n",
            "naive://u:p@1.1.1.1:443#n",
            "ssh://u:p@1.1.1.1:22#n",
            "socks://u:p@1.1.1.1:1080#n",
            "http://1.1.1.1:8080#n",
            "wireguard://k@1.1.1.1:51820?peerpubkey=p&address=10.0.0.1/32#n",
        ];
        for l in links {
            let srv = crate::links::parse_link(l).unwrap();
            let cfg = build(&srv, 1080);
            assert!(serde_json::to_string(&cfg).is_ok(), "json fails for {l}");
            assert_eq!(cfg["outbounds"][0]["tag"], "proxy");
            assert_eq!(cfg["outbounds"][1]["type"], "direct");
        }
    }
}
