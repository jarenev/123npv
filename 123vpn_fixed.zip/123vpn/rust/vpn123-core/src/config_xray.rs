//! Генератор конфига xray-core (JSON, формат vnext — совместим со всеми
//! актуальными версиями ядра, включая v26.x).

use crate::model::*;
use serde_json::{json, Map, Value};

fn s(v: &Option<String>) -> Value {
    v.as_ref().map(|x| Value::String(x.clone())).unwrap_or(Value::Null)
}

/// streamSettings из Transport + TlsParams.
fn stream_settings(srv: &Server) -> Value {
    let mut obj = Map::new();
    let transport = srv.params.transport.clone().unwrap_or_default();
    let network = match transport.kind {
        TransportKind::Tcp => "tcp",
        TransportKind::Ws => "ws",
        TransportKind::Grpc => "grpc",
        // http_method = маркер tcp+http-обфускации (см. links.rs); без него — h2
        TransportKind::Http => {
            if transport.http_method.is_some() { "tcp" } else { "http" }
        }
        TransportKind::HttpUpgrade => "httpupgrade",
        TransportKind::Xhttp => "xhttp",
    };
    obj.insert("network".into(), json!(network));

    match transport.kind {
        TransportKind::Ws => {
            let mut ws = Map::new();
            ws.insert("path".into(), s(&transport.path));
            let mut headers = Map::new();
            if let Some(h) = &transport.host {
                headers.insert("Host".into(), json!(h));
            }
            ws.insert("headers".into(), Value::Object(headers));
            obj.insert("wsSettings".into(), Value::Object(ws));
        }
        TransportKind::Grpc => {
            let mut g = Map::new();
            g.insert(
                "serviceName".into(),
                transport.service_name.clone().map(Value::String).unwrap_or(json!("grpcSrv")),
            );
            obj.insert("grpcSettings".into(), Value::Object(g));
        }
        TransportKind::HttpUpgrade => {
            let mut h = Map::new();
            h.insert("path".into(), s(&transport.path));
            if let Some(hst) = &transport.host {
                h.insert("host".into(), json!(hst));
            }
            obj.insert("httpupgradeSettings".into(), Value::Object(h));
        }
        TransportKind::Http => {
            if transport.http_method.is_some() {
                // tcp + http-обфускация (headerType=http)
                let mut tcp = Map::new();
                let mut header = Map::new();
                header.insert("type".into(), json!("http"));
                let mut request = Map::new();
                let path = transport.path.clone().unwrap_or_else(|| "/".into());
                request.insert("path".into(), json!([path]));
                if let Some(hst) = &transport.host {
                    request.insert("headers".into(), json!({"Host": [hst]}));
                }
                header.insert("request".into(), Value::Object(request));
                tcp.insert("header".into(), Value::Object(header));
                obj.insert("tcpSettings".into(), Value::Object(tcp));
            } else {
                // настоящий h2
                let mut h = Map::new();
                h.insert("path".into(), transport.path.clone().map(Value::String).unwrap_or(json!("/")));
                if let Some(hst) = &transport.host {
                    h.insert("host".into(), json!([hst]));
                }
                obj.insert("httpSettings".into(), Value::Object(h));
            }
        }
        TransportKind::Xhttp => {
            let mut x = Map::new();
            x.insert("path".into(), s(&transport.path));
            if let Some(hst) = &transport.host {
                x.insert("host".into(), json!(hst));
            }
            if let Some(mode) = &transport.mode {
                x.insert("mode".into(), json!(mode));
            }
            if let Some(extra) = &transport.extra {
                if let Ok(v) = serde_json::from_str::<Value>(extra) {
                    x.insert("extra".into(), v);
                }
            }
            obj.insert("xhttpSettings".into(), Value::Object(x));
        }
        TransportKind::Tcp => {}
    }

    if let Some(tls) = &srv.params.tls {
        obj.insert("security".into(), if tls.reality_pub.is_some() { json!("reality") } else { json!("tls") });
        if tls.reality_pub.is_some() {
            let mut r = Map::new();
            r.insert("serverName".into(), s(&tls.sni));
            r.insert("fingerprint".into(), tls.fingerprint.clone().map(Value::String).unwrap_or(json!("chrome")));
            r.insert("publicKey".into(), s(&tls.reality_pub));
            r.insert("shortId".into(), s(&tls.reality_sid));
            r.insert("spiderX".into(), tls.spider_x.clone().map(Value::String).unwrap_or(json!("")));
            obj.insert("realitySettings".into(), Value::Object(r));
        } else {
            let mut t = Map::new();
            if let Some(sni) = &tls.sni {
                t.insert("serverName".into(), json!(sni));
            } else if let Some(hst) = Some(&srv.host) {
                t.insert("serverName".into(), json!(hst));
            }
            // `allowInsecure` удалён в xray 26.x (ядро не стартует). Ноды с insecure
            // выбирают sing-box (см. select::choose_core); здесь — только пин/имя.
            if let Some(pcs) = &tls.pinned_sha256 {
                t.insert("pinnedPeerCertSha256".into(), json!(pcs));
            }
            if let Some(vcn) = &tls.verify_name {
                t.insert("verifyPeerCertByName".into(), json!(vcn));
            }
            if let Some(fp) = &tls.fingerprint {
                t.insert("fingerprint".into(), json!(fp));
            }
            if !tls.alpn.is_empty() {
                t.insert("alpn".into(), json!(tls.alpn));
            }
            obj.insert("tlsSettings".into(), Value::Object(t));
        }
    } else {
        obj.insert("security".into(), json!("none"));
    }
    Value::Object(obj)
}

fn proxy_outbound(srv: &Server) -> Value {
    let address = &srv.host;
    let port = srv.port;
    match srv.protocol {
        Protocol::Vmess => {
            let user = json!({
                "id": srv.params.uuid.clone().unwrap_or_default(),
                "alterId": srv.params.alter_id.unwrap_or(0),
                "security": srv.params.security.clone().unwrap_or_else(|| "auto".into()),
            });
            json!({
                "tag": "proxy", "protocol": "vmess",
                "settings": {"vnext": [{"address": address, "port": port, "users": [user]}]},
                "streamSettings": stream_settings(srv),
                "mux": {"enabled": false}
            })
        }
        Protocol::Vless => {
            let mut user = Map::new();
            user.insert("id".into(), json!(srv.params.uuid.clone().unwrap_or_default()));
            // VLESS Encryption (mlkem768x25519plus…) приходит из ссылки; иначе «none»
            user.insert(
                "encryption".into(),
                json!(srv.params.encryption.clone().unwrap_or_else(|| "none".into())),
            );
            if let Some(f) = &srv.params.flow {
                user.insert("flow".into(), json!(f));
            }
            json!({
                "tag": "proxy", "protocol": "vless",
                "settings": {"vnext": [{"address": address, "port": port, "users": [Value::Object(user)]}]},
                "streamSettings": stream_settings(srv),
                "mux": {"enabled": false}
            })
        }
        Protocol::Trojan => {
            let server = json!({
                "address": address, "port": port,
                "password": srv.params.password.clone().unwrap_or_default(),
            });
            json!({
                "tag": "proxy", "protocol": "trojan",
                "settings": {"servers": [server]},
                "streamSettings": stream_settings(srv),
            })
        }
        Protocol::Shadowsocks => {
            let mut server = Map::new();
            server.insert("address".into(), json!(address));
            server.insert("port".into(), json!(port));
            server.insert("method".into(), json!(srv.params.method.clone().unwrap_or_else(|| "aes-256-gcm".into())));
            server.insert("password".into(), json!(srv.params.password.clone().unwrap_or_default()));
            if let (Some(p), Some(o)) = (&srv.params.plugin, &srv.params.plugin_opts) {
                server.insert("plugin".into(), json!(p));
                server.insert("pluginOpts".into(), json!(o));
            }
            json!({
                "tag": "proxy", "protocol": "shadowsocks",
                "settings": {"servers": [Value::Object(server)]},
            })
        }
        Protocol::Socks => {
            let mut server = Map::new();
            server.insert("address".into(), json!(address));
            server.insert("port".into(), json!(port));
            if srv.params.username.is_some() {
                server.insert("users".into(), json!([{
                    "user": srv.params.username.clone().unwrap_or_default(),
                    "pass": srv.params.password.clone().unwrap_or_default(),
                }]));
            }
            json!({
                "tag": "proxy", "protocol": "socks",
                "settings": {"servers": [Value::Object(server)]},
            })
        }
        Protocol::Http => {
            let mut server = Map::new();
            server.insert("address".into(), json!(address));
            server.insert("port".into(), json!(port));
            if srv.params.username.is_some() {
                server.insert("users".into(), json!([{
                    "user": srv.params.username.clone().unwrap_or_default(),
                    "pass": srv.params.password.clone().unwrap_or_default(),
                }]));
            }
            let mut out = Map::new();
            out.insert("tag".into(), json!("proxy"));
            out.insert("protocol".into(), json!("http"));
            out.insert("settings".into(), json!({"servers": [Value::Object(server)]}));
            if srv.is_tls() {
                out.insert("streamSettings".into(), stream_settings(srv));
            }
            Value::Object(out)
        }
        Protocol::Wireguard => {
            let mut peer = Map::new();
            peer.insert("publicKey".into(), json!(srv.params.peer_public.clone().unwrap_or_default()));
            peer.insert("endpoint".into(), json!(if srv.host.contains(':') {
                format!("[{}]:{}", srv.host, srv.port) // IPv6-литерал
            } else {
                format!("{}:{}", srv.host, srv.port)
            }));
            if let Some(psk) = &srv.params.psk {
                peer.insert("preSharedKey".into(), json!(psk));
            }
            let mut settings = Map::new();
            settings.insert("secretKey".into(), json!(srv.params.private_key.clone().unwrap_or_default()));
            settings.insert("address".into(), json!(srv.params.local_addrs.clone()));
            settings.insert("peers".into(), json!([Value::Object(peer)]));
            settings.insert("mtu".into(), json!(1408));
            if !srv.params.reserved.is_empty() {
                settings.insert("reserved".into(), json!(srv.params.reserved.clone()));
            }
            json!({"tag": "proxy", "protocol": "wireguard", "settings": Value::Object(settings)})
        }
        _ => {
            // Не должно случаться: выбор ядра фильтрует протоколы.
            json!({
                "tag": "proxy", "protocol": "freedom",
                "settings": {}
            })
        }
    }
}

/// Собирает полный конфиг xray: SOCKS-вход на 127.0.0.1:port + прокси-выход.
pub fn build(srv: &Server, socks_port: u16) -> Value {
    json!({
        "log": {"loglevel": "warning"},
        "inbounds": [{
            "tag": "socks-in",
            "listen": "127.0.0.1",
            "port": socks_port,
            "protocol": "socks",
            "settings": {"auth": "noauth", "udp": true, "ip": "127.0.0.1"},
            "sniffing": {
                "enabled": true,
                "destOverride": ["http", "tls", "quic"],
                "routeOnly": false
            }
        }],
        "outbounds": [
            proxy_outbound(srv),
            {"tag": "direct", "protocol": "freedom", "settings": {}},
            {"tag": "block", "protocol": "blackhole", "settings": {"response": {"type": "http"}}}
        ]
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn vless_srv() -> Server {
        crate::links::parse_link(
            "vless://uuid-x@1.2.3.4:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=a.com&fp=chrome&pbk=PK&sid=1a2b&type=tcp#t"
        ).unwrap()
    }

    #[test]
    fn xray_vless_reality() {
        let cfg = build(&vless_srv(), 1080);
        assert_eq!(cfg["inbounds"][0]["port"], 1080);
        assert_eq!(cfg["inbounds"][0]["protocol"], "socks");
        assert_eq!(cfg["inbounds"][0]["settings"]["udp"], true);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["protocol"], "vless");
        assert_eq!(out["settings"]["vnext"][0]["address"], "1.2.3.4");
        assert_eq!(out["settings"]["vnext"][0]["users"][0]["id"], "uuid-x");
        assert_eq!(out["settings"]["vnext"][0]["users"][0]["flow"], "xtls-rprx-vision");
        assert_eq!(out["streamSettings"]["security"], "reality");
        assert_eq!(out["streamSettings"]["realitySettings"]["publicKey"], "PK");
        assert_eq!(out["streamSettings"]["realitySettings"]["serverName"], "a.com");
        assert_eq!(cfg["outbounds"][1]["protocol"], "freedom");
    }

    #[test]
    fn xray_vmess_ws_tls() {
        use base64::Engine;
        let json = serde_json::json!({
            "v":"2","ps":"n","add":"5.6.7.8","port":"443","id":"u","aid":"0","scy":"auto",
            "net":"ws","host":"cdn.com","path":"/v","tls":"tls","sni":"cdn.com"
        }).to_string();
        let b64 = base64::engine::general_purpose::STANDARD.encode(json);
        let srv = crate::links::parse_link(&format!("vmess://{b64}")).unwrap();
        let cfg = build(&srv, 10808);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["protocol"], "vmess");
        assert_eq!(out["settings"]["vnext"][0]["users"][0]["alterId"], 0);
        assert_eq!(out["streamSettings"]["network"], "ws");
        assert_eq!(out["streamSettings"]["wsSettings"]["headers"]["Host"], "cdn.com");
        assert_eq!(out["streamSettings"]["tlsSettings"]["serverName"], "cdn.com");
    }

    #[test]
    fn xray_trojan() {
        let srv = crate::links::parse_link("trojan://pw@9.9.9.9:443?sni=t.com&type=grpc&serviceName=g#x").unwrap();
        let cfg = build(&srv, 1080);
        let out = &cfg["outbounds"][0];
        assert_eq!(out["protocol"], "trojan");
        assert_eq!(out["settings"]["servers"][0]["password"], "pw");
        assert_eq!(out["streamSettings"]["grpcSettings"]["serviceName"], "g");
    }

    #[test]
    fn xray_ss() {
        use base64::Engine;
        let userinfo = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode("aes-256-gcm:pw");
        let srv = crate::links::parse_link(&format!("ss://{userinfo}@3.3.3.3:8388#s")).unwrap();
        let cfg = build(&srv, 1080);
        assert_eq!(cfg["outbounds"][0]["protocol"], "shadowsocks");
        assert_eq!(cfg["outbounds"][0]["settings"]["servers"][0]["method"], "aes-256-gcm");
    }

    #[test]
    fn config_is_valid_json_object() {
        let cfg = build(&vless_srv(), 1080);
        let text = serde_json::to_string(&cfg).unwrap();
        let parsed: Value = serde_json::from_str(&text).unwrap();
        assert!(parsed.get("inbounds").is_some());
        assert!(parsed.get("outbounds").is_some());
    }
}
