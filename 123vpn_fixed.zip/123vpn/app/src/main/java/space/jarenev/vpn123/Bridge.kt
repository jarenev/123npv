package space.jarenev.vpn123

import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONObject

/**
 * JS-мост для WebView: window.Android.*
 * Вызывается из фонового потока WebView, поэтому блокирующие операции допустимы.
 */
class Bridge(private val activity: MainActivity) {

    private val ctx: Context get() = activity.applicationContext

    @android.webkit.JavascriptInterface
    fun connect() {
        val sub = Prefs.get(ctx, Prefs.KEY_SUB)
        if (sub.isBlank() || Vpn123Service.isRunning.get()) return
        activity.runOnUiThread {
            activity.requestVpnConsent { ok ->
                if (ok) {
                    val intent = Intent(ctx, Vpn123Service::class.java)
                        .setAction(Vpn123Service.ACTION_START)
                        .putExtra("sub", sub)
                    ctx.startForegroundService(intent)
                }
            }
        }
    }

    @android.webkit.JavascriptInterface
    fun disconnect() {
        val intent = Intent(ctx, Vpn123Service::class.java)
            .setAction(Vpn123Service.ACTION_STOP)
        ctx.startService(intent)
    }

    /** Статус супервизора + трафик + состояние сервиса, единый JSON. */
    @android.webkit.JavascriptInterface
    fun status(): String {
        return try {
            val json = JSONObject(Vpn123Jni.status())
            // Rust-ошибки сильнее; если их нет — причина из сервиса (establish_failed и т.п.)
            // org.json на Android: optString() для JSON null возвращает строку "null",
            // а не fallback — из-за этого в UI вечно светилась ошибка «null».
            val rustErr = if (json.isNull("last_error")) "" else json.optString("last_error", "")
            val lastErr = rustErr.ifBlank { Prefs.get(ctx, Prefs.KEY_LAST_ERR) }
            json.put("last_error", lastErr)
            if (json.isNull("error")) json.remove("error")
            json.put("rx_total", TrafficState.totalRx.get())
            json.put("tx_total", TrafficState.totalTx.get())
            json.put("rx_speed", TrafficState.rxSpeed.get())
            json.put("tx_speed", TrafficState.txSpeed.get())
            // AtomicBoolean нельзя класть в JSON напрямую: сериализуется строкой "false" (truthy в JS)
            json.put("service_running", Vpn123Service.isRunning.get())
            json.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("state", "idle")
                put("error", e.message ?: "unknown")
                put("service_running", false)
            }.toString()
        }
    }

    @android.webkit.JavascriptInterface
    fun getSubscription(): String = Prefs.get(ctx, Prefs.KEY_SUB)

    @android.webkit.JavascriptInterface
    fun setSubscription(url: String) {
        Prefs.set(ctx, Prefs.KEY_SUB, url.trim())
    }

    @Volatile private var refreshResult: String? = null
    @Volatile private var refreshRunning = false

    /**
     * Асинхронная проверка подписки: загрузка + парсинг + пинг могут идти десятки
     * секунд, а JS-мост синхронный — блокирующий вызов вешал бы JS страницы
     * (и опрос статуса). Запускаем в потоке; результат забирает refreshPoll().
     */
    @android.webkit.JavascriptInterface
    fun refreshStart() {
        if (refreshRunning) return
        refreshRunning = true
        refreshResult = null
        Thread({
            val r = try { refreshSubscription() } catch (e: Throwable) {
                JSONObject().apply { put("ok", false); put("error", e.message ?: "error"); put("count", 0) }.toString()
            }
            refreshResult = r
            refreshRunning = false
        }, "sub-refresh").start()
    }

    /** "" — ещё идёт; иначе JSON результата (забирается один раз). */
    @android.webkit.JavascriptInterface
    fun refreshPoll(): String {
        val r = refreshResult ?: return ""
        refreshResult = null
        return r
    }

    /** Проверить подписку (загрузка + парсинг + пинг) без подключения. */
    @android.webkit.JavascriptInterface
    fun refreshSubscription(): String {
        val sub = Prefs.get(ctx, Prefs.KEY_SUB)
        if (sub.isBlank()) {
            return JSONObject().apply {
                put("ok", false); put("error", "empty_sub"); put("count", 0)
            }.toString()
        }
        return try {
            Vpn123Jni.refresh(sub)
        } catch (e: Throwable) {
            JSONObject().apply {
                put("ok", false); put("error", e.message ?: "jni_error"); put("count", 0)
            }.toString()
        }
    }

    @android.webkit.JavascriptInterface
    fun getKillSwitch(): Boolean = Prefs.getBool(ctx, Prefs.KEY_KILL_SWITCH)

    @android.webkit.JavascriptInterface
    fun setKillSwitch(on: Boolean) {
        Prefs.setBool(ctx, Prefs.KEY_KILL_SWITCH, on)
    }

    @android.webkit.JavascriptInterface
    fun getLang(): String = Prefs.get(ctx, Prefs.KEY_LANG, "ru")

    @android.webkit.JavascriptInterface
    fun setLang(lang: String) {
        Prefs.set(ctx, Prefs.KEY_LANG, if (lang == "en") "en" else "ru")
    }

    @android.webkit.JavascriptInterface
    fun getAppVersion(): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) { "1.0.0" }

    /** Уровень заряда батареи — для мелкого индикатора в футере (как часы на jarenev.space). */
    @android.webkit.JavascriptInterface
    fun batteryLevel(): Int = try {
        val bf = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bf?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bf?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) level * 100 / scale else -1
    } catch (e: Exception) { -1 }
}
