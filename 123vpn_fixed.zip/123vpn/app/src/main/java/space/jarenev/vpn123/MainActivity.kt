package space.jarenev.vpn123

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.Manifest
import android.content.pm.PackageManager
import android.net.VpnService
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_VPN_CONSENT = 41
    }

    lateinit var webView: WebView
    private lateinit var bridge: Bridge

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.setBackgroundColor(Color.BLACK)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        webView.webChromeClient = WebChromeClient()

        bridge = Bridge(this)
        webView.addJavascriptInterface(bridge, "Android")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/ui/index.html")

        // Разрешение на уведомления (Android 13+), без него статус-бар VPN молчит.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    /** Запрос системного согласия на использование VPN. */
    fun requestVpnConsent(onResult: (Boolean) -> Unit) {
        val intent = VpnService.prepare(this)
        if (intent == null) {
            onResult(true)
            return
        }
        consentCallback = onResult
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQ_VPN_CONSENT)
    }

    private var consentCallback: ((Boolean) -> Unit)? = null

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN_CONSENT) {
            consentCallback?.invoke(resultCode == Activity.RESULT_OK)
            consentCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Кнопка «назад» не убивает активность (и VPN), а сворачивает приложение.
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("Android")
        super.onDestroy()
    }
}
