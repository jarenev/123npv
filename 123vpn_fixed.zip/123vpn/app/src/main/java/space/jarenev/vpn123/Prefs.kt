package space.jarenev.vpn123

import android.content.Context

/** Простое хранилище настроек: ссылка подписки, язык, Kill Switch. */
object Prefs {
    private const val FILE = "vpn123_prefs"
    const val KEY_SUB = "subscription_url"
    const val KEY_LANG = "lang"
    const val KEY_KILL_SWITCH = "kill_switch"
    /** Причина последней остановки сервиса (establish_failed, tun_failed…) — для UI. */
    const val KEY_LAST_ERR = "last_stop_reason"

    fun get(ctx: Context, key: String, def: String = ""): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(key, def) ?: def

    fun set(ctx: Context, key: String, value: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(key, value).apply()
    }

    fun setBool(ctx: Context, key: String, value: Boolean) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(key, value).apply()
    }

    fun getBool(ctx: Context, key: String, def: Boolean = false): Boolean =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(key, def)
}
