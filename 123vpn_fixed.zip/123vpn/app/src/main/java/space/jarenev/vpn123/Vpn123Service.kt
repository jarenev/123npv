package space.jarenev.vpn123

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * VPN-сервис: оркестрирует связку Kotlin (VpnService/TUN) и Rust
 * (подписка, пинг, выбор сервера, xray/sing-box, tun2proxy).
 *
 * Поток запуска:
 *  1. startCore() — Rust качает подписку, пингует серверы, выбирает лучший,
 *     генерирует конфиг и запускает ядро; до TUN-интерфейса.
 *  2. Ждём state == ready_for_tun (ядро подняло SOCKS-порт).
 *  3. establish() создаём TUN, передаём fd в Rust → tun2proxy.
 *  4. Failover-мониторинг живёт в Rust: если сервер умирает, ядро
 *     перезапускается на другом сервере, TUN не пересоздаётся.
 */
class Vpn123Service : VpnService() {

    companion object {
        const val ACTION_START = "space.jarenev.vpn123.START"
        const val ACTION_STOP = "space.jarenev.vpn123.STOP"
        const val SOCKS_PORT = 1080
        const val MTU = 1500
        private const val CHANNEL_ID = "vpn123_service"
        private const val RECONNECT_DELAY_MS = 3000L
        private const val MAX_RECONNECTS = 3

        @JvmStatic
        var isRunning = AtomicBoolean(false)
    }

    private var tunFd: ParcelFileDescriptor? = null
    private var reconnectAttempts = 0
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var trafficRunnable: Runnable? = null
    @Volatile private var shuttingDown = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAll()
            ACTION_START -> {
                val sub = intent.getStringExtra("sub") ?: Prefs.get(this, Prefs.KEY_SUB)
                // ручной запуск сбрасывает счётчик авто-реконнекта; авто ("auto") — нет
                if (intent.getStringExtra("auto") == null) reconnectAttempts = 0
                if (sub.isNotBlank() && !isRunning.get()) {
                    startAll(sub)
                } else {
                    // startForegroundService() обязывает вызвать startForeground() в течение
                    // нескольких секунд, иначе система убивает приложение
                    // (ForegroundServiceDidNotStartInTimeException) — даже если запускать нечего.
                    startForegroundCompat(getStringStateLine(if (isRunning.get()) "connected" else "idle"))
                    if (!isRunning.get()) stopAll()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startAll(subscription: String) {
        isRunning.set(true)
        shuttingDown = false
        Prefs.set(this, Prefs.KEY_LAST_ERR, "") // новая сессия — прошлая причина не актуальна
        startForegroundCompat(getStringStateLine("fetching"))
        TrafficState.start()

        executor.execute {
            try {
                Vpn123Jni.ensureLoaded()
                val ok = Vpn123Jni.startCore(
                    subscription,
                    filesDir.absolutePath,              // конфиги
                    applicationInfo.nativeLibraryDir,   // libxray.so / libsingbox.so
                    filesDir.absolutePath,              // рабочие файлы, лог ядра
                    SOCKS_PORT
                )
                if (!ok) { shutdown("start_failed"); return@execute }

                // Ждём, пока Rust поднимет ядро и SOCKS-порт будет готов.
                var ready = false
                // Загрузка подписки (до 20 с) + пинг + до нескольких попыток запуска ядра
                // (до 15 с каждая): 60 с не хватало при первом «мёртвом» сервере.
                for (i in 0 until 300) { // до 150 секунд
                    val state = stateOf()
                    if (state == "ready_for_tun" || state == "connected") { ready = true; break }
                    if (state == "error" || state == "idle") break
                    if (Thread.currentThread().isInterrupted) return@execute
                    updateNotification(getStringStateLine(state))
                    Thread.sleep(500)
                }
                if (!ready) { shutdown("no_ready_state"); return@execute }

                val fd = buildTunInterface()
                if (fd == null) { shutdown("establish_failed"); return@execute }
                tunFd = fd
                if (!Vpn123Jni.startTun(fd.fd)) { shutdown("tun_failed"); return@execute }

                startTrafficPolling()
                reconnectAttempts = 0
                updateNotification(getStringStateLine("connected"))
            } catch (e: Exception) {
                shutdown(e.message ?: "exception")
            }
        }
    }

    private inline fun stateOf(): String {
        return try {
            org.json.JSONObject(Vpn123Jni.status()).optString("state", "idle")
        } catch (e: Exception) { "idle" }
    }

    private fun buildTunInterface(): ParcelFileDescriptor? {
        val builder = Builder()
            .setSession("123 VPN")
            .setMtu(MTU)
            .addAddress("10.123.0.1", 32)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)
        // Трафик самого приложения (включая процессы ядер) выводится из-под VPN,
        // иначе пакеты ядра зациклились бы обратно в TUN.
        try {
            builder.addDisallowedApplication(packageName)
        } catch (e: Exception) {
            // Если исключить себя нельзя — поднимаем VPN нельзя безопасно.
            return null
        }
        return builder.establish()
    }

    private fun rustError(): String? = try {
        val j = org.json.JSONObject(Vpn123Jni.status())
        // optString() на Android отдаёт "null" для JSON null — проверяем явно
        listOf("error", "last_error").firstNotNullOfOrNull { k ->
            if (j.isNull(k)) null else j.optString(k, "").ifBlank { null }
        }
    } catch (e: Exception) { null }

    private fun startTrafficPolling() {
        val r = object : Runnable {
            override fun run() {
                TrafficState.tick()
                // Watchdog: после подъёма туннеля Rust-супервизор может завершиться ошибкой
                // (все серверы недоступны). Без этой проверки сервис продолжал бы «жить»
                // с мёртвым туннелем, а Kill Switch (авто-реконнект) никогда бы не сработал.
                val st = stateOf()
                if ((st == "error" || st == "idle") && isRunning.get() && !shuttingDown) {
                    val reason = rustError() ?: "connection_lost"
                    executor.execute { shutdown(reason) }
                    return
                }
                handler.postDelayed(this, 1000)
            }
        }
        trafficRunnable = r
        handler.post(r)
    }

    private fun stopAll() {
        executor.execute { shutdown(null) }
    }

    private fun shutdown(reason: String?) {
        shuttingDown = true
        // Причину сохраняем до сброса состояния Rust (stop() возвращает всё в idle) —
        // UI покажет её на главном экране через Bridge.status() → last_error.
        if (reason != null) Prefs.set(this, Prefs.KEY_LAST_ERR, reason)
        try { Vpn123Jni.stop() } catch (e: Exception) { /* ignore */ }
        trafficRunnable?.let { handler.removeCallbacks(it) }
        trafficRunnable = null
        try { tunFd?.close() } catch (e: Exception) { /* ignore */ }
        tunFd = null
        TrafficState.stop()
        isRunning.set(false)
        if (reason != null) {
            updateNotification(getStringStateLine("error") + " · " + reason)
            // Kill Switch: при внезапном обрыве снова поднимаем VPN (до MAX_RECONNECTS
            // раз с паузой), чтобы трафик не уходил мимо туннеля. Ручная остановка
            // приходит с reason = null и реконнект не запускает.
            if (Prefs.getBool(this, Prefs.KEY_KILL_SWITCH) && reconnectAttempts < MAX_RECONNECTS) {
                val sub = Prefs.get(this, Prefs.KEY_SUB)
                if (sub.isNotBlank()) {
                    reconnectAttempts++
                    handler.postDelayed({
                        if (!isRunning.get()) {
                            val i = Intent(this, Vpn123Service::class.java)
                                .setAction(ACTION_START)
                                .putExtra("sub", sub)
                                .putExtra("auto", true)
                            startForegroundService(i)
                        }
                    }, RECONNECT_DELAY_MS)
                }
            }
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { Vpn123Jni.stop() } catch (e: Exception) { /* ignore */ }
        try { tunFd?.close() } catch (e: Exception) { /* ignore */ }
        isRunning.set(false)
        super.onDestroy()
    }

    // ── Уведомления ──────────────────────────────────────────────

    private fun startForegroundCompat(text: String) {
        createChannel()
        val notif = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this, 1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1, notif)
        }
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(1, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val tap = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(tap)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun getStringStateLine(state: String): String = when (state) {
        "fetching" -> getString(R.string.ntf_fetching)
        "pinging" -> getString(R.string.ntf_pinging)
        "starting" -> getString(R.string.ntf_starting)
        "ready_for_tun" -> getString(R.string.ntf_starting)
        "connected" -> getString(R.string.ntf_connected)
        "reconnecting" -> getString(R.string.ntf_reconnecting)
        "error" -> getString(R.string.ntf_error)
        else -> getString(R.string.ntf_idle)
    }
}
