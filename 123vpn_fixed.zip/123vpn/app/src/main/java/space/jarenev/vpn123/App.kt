package space.jarenev.vpn123

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Нативная библиотека грузится один раз на весь процесс,
        // чтобы JNI-состояние супервизора было общим для Activity и Service.
        Vpn123Jni.ensureLoaded()
    }
}
