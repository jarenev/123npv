package space.jarenev.vpn123

import android.net.TrafficStats
import java.util.concurrent.atomic.AtomicLong

/**
 * Статистика трафика сессии (общесистемные счётчики TrafficStats).
 * Обновляется сервисом раз в секунду, читается JS-мостом.
 */
object TrafficState {
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastTs = 0L

    @JvmField var totalRx = AtomicLong(0)
    @JvmField var totalTx = AtomicLong(0)
    @JvmField var rxSpeed = AtomicLong(0)   // байт/с
    @JvmField var txSpeed = AtomicLong(0)   // байт/с

    fun start() {
        lastRx = TrafficStats.getTotalRxBytes()
        lastTx = TrafficStats.getTotalTxBytes()
        lastTs = System.currentTimeMillis()
    }

    fun stop() {
        totalRx.set(0); totalTx.set(0); rxSpeed.set(0); txSpeed.set(0)
        lastRx = 0; lastTx = 0; lastTs = 0
    }

    fun tick() {
        val now = System.currentTimeMillis()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val dt = (now - lastTs).coerceAtLeast(1) / 1000.0
        if (lastTs > 0) {
            val drx = rx - lastRx
            val dtx = tx - lastTx
            if (drx >= 0) {
                totalRx.addAndGet(drx)
                rxSpeed.set((drx / dt).toLong())
            }
            if (dtx >= 0) {
                totalTx.addAndGet(dtx)
                txSpeed.set((dtx / dt).toLong())
            }
        }
        lastRx = rx; lastTx = tx; lastTs = now
    }
}
