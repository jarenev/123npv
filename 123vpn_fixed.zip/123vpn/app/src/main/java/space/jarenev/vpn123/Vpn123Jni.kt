package space.jarenev.vpn123

/**
 * JNI-мост к Rust-ядру (libvpn123.so).
 *
 * Все вызовы неблокирующие, кроме refresh(): он выполняет загрузку подписки
 * и пинг серверов, поэтому звать его нужно из фонового потока (JS-мост и так
 * работает в отдельном потоке WebView).
 */
object Vpn123Jni {
    @Volatile private var loaded = false

    fun ensureLoaded() {
        if (!loaded) synchronized(this) {
            if (!loaded) {
                System.loadLibrary("vpn123")
                loaded = true
            }
        }
    }

    /** Запустить конвейер: подписка → пинг → выбор сервера → запуск ядра. */
    external fun startCore(
        subUrl: String,
        configDir: String,
        binDir: String,
        workDir: String,
        socksPort: Int
    ): Boolean

    /** Передать fd TUN-интерфейса (после VpnService.establish()). */
    external fun startTun(fd: Int): Boolean

    /** Полностью остановить ядро и туннель. */
    external fun stop()

    /** JSON-статус супервизора (state, server, events, failover...). */
    external fun status(): String

    /** Загрузить и проверить подписку без запуска VPN. Блокирующий. */
    external fun refresh(subUrl: String): String
}
