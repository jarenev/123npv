/* 123 VPN — интерфейс: планета, статус, подписка, RU/EN.
   Один экран без прокрутки: ядро и сервер подбираются автоматически,
   подписка вводится при первом входе, остаются трафик и Kill Switch.
   В браузере (без window.Android) работает демо-режим — имитация моста. */

'use strict';

// ────────────────────────── i18n ──────────────────────────

const I18N = {
  ru: {
    disconnected: 'Отключено',
    connecting: 'Подключение…',
    connected: 'Подключено',
    reconnecting: 'Переключаемся…',
    error: 'Ошибка',
    connect: 'Подключиться',
    disconnect: 'Отключить',
    session: 'Сессия',
    traffic: 'Трафик',
    ks_hint: 'Автоподъём VPN при обрыве',
    ks_toast_on: 'Kill Switch включён: при обрыве VPN поднимется сам',
    ks_toast_off: 'Kill Switch выключен',
    subscription: 'Подписка',
    sub_title: 'Подписка',
    sub_note: 'Вставьте ссылку подписки от провайдера или одиночную ноду (vless://, vmess://, trojan://, ss://…). Сервер и ядро (xray / sing-box) подбираются автоматически.',
    save_check: 'Сохранить и проверить',
    sub_checking: 'Проверяем подписку…',
    sub_result: (count, best) => `Готово: ${count} сервер(ов). Лучший: ${best}`,
    sub_none: 'Серверы не найдены',
    sub_empty: 'Сначала вставьте ссылку подписки',
    err_start_failed: 'Не удалось запустить ядро VPN',
    err_no_ready_state: 'Ядро не поднялось за отведённое время',
    err_establish_failed: 'Android не дал создать VPN-интерфейс. Закройте другие VPN-приложения (например, Happ) — система допускает только один активный VPN — и повторите подключение.',
    err_connection_lost: 'Соединение потеряно. Проверьте подписку и интернет.',
    err_tun_failed: 'Туннель не запустился. Попробуйте переподключиться.',
    close: 'Закрыть',
    ms: (v) => `${v} мс`,
    consent_denied: 'Доступ к VPN не выдан',
    demo_on: 'Демо-режим',
  },
  en: {
    disconnected: 'Disconnected',
    connecting: 'Connecting…',
    connected: 'Connected',
    reconnecting: 'Switching…',
    error: 'Error',
    connect: 'Connect',
    disconnect: 'Disconnect',
    session: 'Session',
    traffic: 'Traffic',
    ks_hint: 'Auto-reconnect on drop',
    ks_toast_on: 'Kill Switch on: VPN restores itself after a drop',
    ks_toast_off: 'Kill Switch off',
    subscription: 'Subscription',
    sub_title: 'Subscription',
    sub_note: 'Paste a subscription link or a single node link (vless://, vmess://, trojan://, ss://…). The server and the core (xray / sing-box) are picked automatically.',
    save_check: 'Save and check',
    sub_checking: 'Checking subscription…',
    sub_result: (count, best) => `Done: ${count} server(s). Best: ${best}`,
    sub_none: 'No servers found',
    sub_empty: 'Add a subscription link first',
    err_start_failed: 'Failed to start the VPN core',
    err_no_ready_state: 'The core did not start in time',
    err_establish_failed: 'Android refused to create the VPN interface. Close other VPN apps (e.g. Happ) — the system allows only one active VPN — and try again.',
    err_connection_lost: 'Connection lost. Check the subscription and your internet.',
    err_tun_failed: 'The tunnel failed to start. Try reconnecting.',
    close: 'Close',
    ms: (v) => `${v} ms`,
    consent_denied: 'VPN permission denied',
    demo_on: 'Demo mode',
  },
};

let lang = 'ru';
function t(key, ...args) {
  const d = I18N[lang] || I18N.ru;
  const v = d[key];
  return typeof v === 'function' ? v(...args) : (v !== undefined ? v : key);
}

// ────────────────────────── мост ──────────────────────────

const Android = window.Android || makeDemoBridge();

function makeDemoBridge() {
  const S = {
    sub: '', lang: 'ru', ks: false,
    state: 'idle', uptime: 0,
    server: null, events: [],
  };
  const srv = {
    name: 'Frankfurt #2', protocol: 'vless', core: 'xray',
    host: 'de-02.demo.net', port: 443, latency_ms: 24,
    country: 'Германия', cc: 'DE', flag: '🇩🇪', lat: 50.11, lon: 8.68,
  };
  let rx = 0, tx = 0, started = 0;
  function json() {
    return {
      state: S.state, server: S.server,
      servers_total: 12, servers_alive: 9, failover_count: S.state === 'connected' ? 1 : 0,
      uptime_s: S.state === 'connected' ? Math.floor((Date.now() - started) / 1000) : null,
      error: S.state === 'error' ? 'demo error' : null,
      last_error: S.lastError || null,
      events: S.events,
      rx_total: rx, tx_total: tx,
      rx_speed: S.state === 'connected' ? 40e3 + Math.random() * 120e3 : 0,
      tx_speed: S.state === 'connected' ? 12e3 + Math.random() * 40e3 : 0,
      service_running: S.state !== 'idle' && S.state !== 'error',
    };
  }
  const steps = ['fetching', 'pinging', 'starting', 'ready_for_tun', 'connected'];
  return {
    connect() {
      if (S.state !== 'idle' && S.state !== 'error') return;
      S.server = null; started = Date.now(); rx = tx = 0;
      let i = 0;
      const next = () => {
        S.state = steps[i];
        if (S.state === 'connected') { S.server = srv; return; }
        setTimeout(() => { i++; next(); }, 900 + Math.random() * 700);
      };
      next();
    },
    disconnect() { S.state = 'idle'; S.server = null; },
    status() { return JSON.stringify(json()); },
    getSubscription() { return S.sub; },
    setSubscription(u) { S.sub = u; },
    refreshSubscription() {
      if (!S.sub) return JSON.stringify({ ok: false, error: 'empty_sub', count: 0 });
      return JSON.stringify({
        ok: true, count: 9, total: 12,
        servers: [
          { name: 'Frankfurt #2', ms: 24, flag: '🇩🇪', country: 'Германия', protocol: 'vless', core: 'xray' },
          { name: 'Amsterdam-1', ms: 31, flag: '🇳🇱', country: 'Нидерланды', protocol: 'vless', core: 'xray' },
          { name: 'Hysteria SPB', ms: 18, flag: '🇷🇺', country: 'Россия', protocol: 'hysteria2', core: 'sing-box' },
        ],
      });
    },
    getKillSwitch() { return S.ks; },
    setKillSwitch(v) { S.ks = v; },
    getLang() { return S.lang; },
    setLang(v) { S.lang = v; },
    getAppVersion() { return '1.1.0-demo'; },
    batteryLevel() { return 87; },
  };
}

// ────────────────────────── DOM ──────────────────────────

const $ = (id) => document.getElementById(id);
const els = {
  stateLabel: $('stateLabel'), serverLine: $('serverLine'), chips: $('chips'),
  latencyChip: $('latencyChip'), coreChip: $('coreChip'), errorLine: $('errorLine'),
  connectBtn: $('connectBtn'), connectLabel: $('connectLabel'),
  sessionTime: $('sessionTime'),
  trafficHint: $('trafficHint'), trafficValue: $('trafficValue'),
  killSwitch: $('killSwitch'),
  subModal: $('subModal'), subCloseBtn: $('subCloseBtn'), subInput: $('subInput'),
  saveSubBtn: $('saveSubBtn'), subResult: $('subResult'), subBtn: $('subBtn'),
  langBtn: $('langBtn'), toast: $('toast'),
  battery: $('battery'), version: $('version'), demoBtn: $('demoBtn'),
};

function toast(msg) {
  els.toast.textContent = msg;
  els.toast.classList.add('on');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => els.toast.classList.remove('on'), 2600);
}

// ────────────────────────── планета ──────────────────────────

const canvas = $('planet');
const ctx2d = canvas.getContext('2d');
const planet = {
  dots: [],          // [lon, lat] в радианах
  rotY: 0,
  speed: 0.15,       // рад/с (текущая, плавно тянется к target)
  targetSpeed: 0.15,
  tilt: -0.32,
  marker: null,      // {x,y,z} точки сервера
  pulse: 0,
  lastTs: 0,
};

const SPEED = { idle: 0.15, busy: 0.85, connected: 0.38 };

async function loadWorld() {
  try {
    // world.js кладёт данные в window.WORLD_DATA: fetch() по file:// в WebView не работает
    const data = window.WORLD_DATA || await (await fetch('world.json')).json();
    planet.dots = data.dots.map(([lon, lat]) => [lon * Math.PI / 180, lat * Math.PI / 180]);
  } catch (e) {
    // Fallback: сетка меридианов/параллелей — планета остаётся читаемой без данных.
    planet.dots = [];
    for (let lat = -75; lat <= 75; lat += 15) {
      const r = Math.cos(lat * Math.PI / 180);
      const n = Math.round(60 * r);
      for (let i = 0; i < n; i++) {
        planet.dots.push([(i / n) * 2 * Math.PI, lat * Math.PI / 180]);
      }
    }
  }
}

function latLonToVec(lat, lon) {
  // Y — вверх (ось вращения), X/Z — экваториальная плоскость
  return {
    x: Math.cos(lat) * Math.cos(lon),
    y: Math.sin(lat),
    z: Math.cos(lat) * Math.sin(lon),
  };
}

function rotate(v, rotY, tilt) {
  // поворот вокруг Y, затем наклон вокруг X
  const cosA = Math.cos(rotY), sinA = Math.sin(rotY);
  const x1 = v.x * cosA + v.z * sinA;
  const z1 = -v.x * sinA + v.z * cosA;
  const y1 = v.y;
  const cosT = Math.cos(tilt), sinT = Math.sin(tilt);
  return {
    x: x1,
    y: y1 * cosT - z1 * sinT,
    z: y1 * sinT + z1 * cosT,
  };
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  canvas.width = Math.round(rect.width * dpr);
  canvas.height = Math.round(rect.height * dpr);
}

function drawPlanet(ts) {
  const dt = planet.lastTs ? Math.min((ts - planet.lastTs) / 1000, 0.016 * 6) : 0.016;
  planet.lastTs = ts;
  planet.speed += (planet.targetSpeed - planet.speed) * Math.min(1, dt * 3);
  planet.rotY += planet.speed * dt;
  if (planet.markerBase) {
    planet.marker = rotate(planet.markerBase, planet.rotY, planet.tilt);
  }

  const w = canvas.width, h = canvas.height;
  ctx2d.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2;
  const R = Math.min(w, h) * 0.40;

  // мягкое свечение сферы
  const glow = ctx2d.createRadialGradient(cx, cy, R * 0.1, cx, cy, R * 1.25);
  glow.addColorStop(0, 'rgba(255,255,255,0.10)');
  glow.addColorStop(0.55, 'rgba(255,255,255,0.035)');
  glow.addColorStop(1, 'rgba(255,255,255,0)');
  ctx2d.fillStyle = glow;
  ctx2d.beginPath();
  ctx2d.arc(cx, cy, R * 1.25, 0, Math.PI * 2);
  ctx2d.fill();

  // контур лимба
  ctx2d.strokeStyle = 'rgba(255,255,255,0.14)';
  ctx2d.lineWidth = Math.max(1, w * 0.0035);
  ctx2d.beginPath();
  ctx2d.arc(cx, cy, R, 0, Math.PI * 2);
  ctx2d.stroke();

  // точки суши
  const rotY = planet.rotY, tilt = planet.tilt;
  const mk = planet.marker;
  for (let i = 0; i < planet.dots.length; i++) {
    const [lon, lat] = planet.dots[i];
    const p = rotate(latLonToVec(-lat, lon), rotY, tilt); // -lat: canvas y вниз
    if (p.z < -0.05) continue;
    const front = p.z > 0;
    const depth = front ? 0.35 + 0.65 * p.z : 0.10 + 0.08 * (1 + p.z);
    let alpha = depth * (front ? 0.9 : 0.28);
    let size = (1.1 + 1.1 * Math.max(0, p.z)) * (w / 320);
    // подсветка точек рядом с сервером
    if (mk && mk.z > 0) {
      const dx = p.x - mk.x, dy = p.y - mk.y, dz = p.z - mk.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist < 0.55) {
        alpha = Math.min(1, alpha + (1 - dist / 0.55) * 0.75);
        size *= 1 + (1 - dist / 0.55) * 0.6;
      }
    }
    ctx2d.fillStyle = `rgba(250,250,250,${alpha.toFixed(3)})`;
    ctx2d.beginPath();
    ctx2d.arc(cx + p.x * R, cy - p.y * R, Math.max(0.6, size), 0, Math.PI * 2);
    ctx2d.fill();
  }

  // маркер сервера + пульс
  if (mk) {
    planet.pulse += dt * (planet.targetSpeed === SPEED.busy ? 2.2 : 1.1);
    const px = cx + mk.x * R, py = cy - mk.y * R;
    if (mk.z > -0.1) {
      const a = mk.z > 0 ? 1 : 0.4;
      ctx2d.fillStyle = `rgba(255,255,255,${a})`;
      ctx2d.beginPath();
      ctx2d.arc(px, py, Math.max(2, 2.6 * (w / 320)), 0, Math.PI * 2);
      ctx2d.fill();
      for (let ring = 0; ring < 2; ring++) {
        const phase = (planet.pulse + ring * 0.5) % 1;
        ctx2d.strokeStyle = `rgba(255,255,255,${(a * (1 - phase) * 0.5).toFixed(3)})`;
        ctx2d.lineWidth = Math.max(1, w * 0.0022);
        ctx2d.beginPath();
        ctx2d.arc(px, py, 4 + phase * R * 0.42, 0, Math.PI * 2);
        ctx2d.stroke();
      }
    }
  }

  requestAnimationFrame(drawPlanet);
}

function setPlanetState(state, server) {
  const busy = ['fetching', 'pinging', 'starting', 'ready_for_tun', 'reconnecting'].includes(state);
  planet.targetSpeed = state === 'connected' ? SPEED.connected : (busy ? SPEED.busy : SPEED.idle);
  planet.marker = null;
  planet.markerBase = null;
  if (server && server.lat != null && server.lon != null) {
    planet.markerBase = latLonToVec(-server.lat, server.lon * Math.PI / 180);
  }
}

// свет за пальцем/курсором
function pointerLight(x, y) {
  document.body.style.setProperty('--mx', x + 'px');
  document.body.style.setProperty('--my', y + 'px');
}
addEventListener('pointermove', (e) => pointerLight(e.clientX, e.clientY), { passive: true });
addEventListener('pointerdown', (e) => pointerLight(e.clientX, e.clientY), { passive: true });

// ────────────────────────── форматирование ──────────────────────────

function fmtBytes(b) {
  if (b < 1024) return `${Math.round(b)} B`;
  if (b < 1024 ** 2) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1024 ** 3) return `${(b / 1024 ** 2).toFixed(1)} MB`;
  return `${(b / 1024 ** 3).toFixed(2)} GB`;
}
function fmtSpeed(b) { return `${fmtBytes(b)}/s`; }
function fmtTime(sec) {
  sec = Math.max(0, sec | 0);
  const h = String(Math.floor(sec / 3600)).padStart(2, '0');
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
  const s = String(sec % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

// ────────────────────────── статусы ──────────────────────────

const ACTIVE = ['fetching', 'pinging', 'starting', 'ready_for_tun', 'connected', 'reconnecting'];

function stateLabel(state) {
  switch (state) {
    case 'fetching': case 'pinging': case 'starting': case 'ready_for_tun':
      return t('connecting');
    case 'connected': return t('connected');
    case 'reconnecting': return t('reconnecting');
    case 'error': return t('error');
    default: return t('disconnected');
  }
}

let lastStatus = null;

// Причины остановки из Vpn123Service (shutdown(reason)) — переводим на язык UI.
const ERR_KEYS = {
  start_failed: 'err_start_failed',
  no_ready_state: 'err_no_ready_state',
  establish_failed: 'err_establish_failed',
  tun_failed: 'err_tun_failed',
  connection_lost: 'err_connection_lost',
};

function renderStatus(s) {
  lastStatus = s;
  const st = s.state || 'idle';
  const server = s.server;
  const active = ACTIVE.includes(st);

  els.stateLabel.textContent = stateLabel(st);
  els.stateLabel.classList.toggle('dim', st === 'idle' || st === 'error');

  if (server) {
    els.serverLine.hidden = false;
    els.serverLine.innerHTML = '';
    const f = document.createElement('span'); f.className = 'flag'; f.textContent = server.flag || '';
    const n = document.createElement('span');
    n.textContent = server.country ? `${server.name} · ${server.country}` : server.name;
    els.serverLine.append(f, n);
    els.chips.hidden = false;
    els.latencyChip.textContent = server.latency_ms != null ? t('ms', server.latency_ms) : '—';
    // ядро подбирается автоматически — просто показываем, что выбрано
    els.coreChip.textContent = `${server.core} · ${server.protocol}`;
  } else {
    els.serverLine.hidden = true;
    els.chips.hidden = true;
  }

  setPlanetState(st, server);

  // причина неудачи: живая ошибка или последняя ошибка сессии.
  // Известные ключи (Kotlin-сервис) переводим, остальное показываем как есть.
  const raw = st === 'error' ? (s.error || s.last_error) : (s.last_error || null);
  const localized = raw && typeof ERR_KEYS[raw] === 'string' ? t(ERR_KEYS[raw]) : raw;
  if (localized && st !== 'connected') {
    els.errorLine.hidden = false;
    els.errorLine.textContent = localized;
  } else {
    els.errorLine.hidden = true;
  }

  // кнопка
  const hasSub = (Android.getSubscription() || '').trim().length > 0;
  els.connectBtn.disabled = !active && !hasSub && st !== 'error';
  els.connectBtn.classList.toggle('is-on', active);
  els.connectLabel.textContent = active ? t('disconnect') : t('connect');

  // трафик
  const on = st === 'connected' || st === 'reconnecting';
  els.trafficValue.textContent = `↓ ${fmtBytes(s.rx_total || 0)} · ↑ ${fmtBytes(s.tx_total || 0)}`;
  els.trafficHint.textContent = `↓ ${fmtSpeed(s.rx_speed || 0)} · ↑ ${fmtSpeed(s.tx_speed || 0)}`;

  // сессия
  els.sessionTime.textContent = on && s.uptime_s != null ? fmtTime(s.uptime_s) : '00:00:00';

  // kill switch
  const ks = Android.getKillSwitch();
  els.killSwitch.setAttribute('aria-pressed', ks ? 'true' : 'false');
}

// ────────────────────────── опрос ──────────────────────────

let pollTimer = null;
function startPolling() {
  if (pollTimer) return;
  pollTimer = setInterval(() => {
    let s;
    try { s = JSON.parse(Android.status()); } catch (e) { return; }
    renderStatus(s);
  }, 500);
}

// ────────────────────────── модалка подписки ──────────────────────────

function openSubModal(locked) {
  els.subModal.hidden = false;
  els.subCloseBtn.hidden = !!locked; // при первом входе нельзя закрыть без ссылки
  els.subInput.value = Android.getSubscription() || '';
  els.subResult.hidden = true;
  setTimeout(() => els.subInput.focus(), 250);
}

function closeSubModal() {
  els.subModal.hidden = true;
}

// Проверка подписки идёт в фоне (десятки секунд): опрашиваем результат, не вешая JS.
function refreshAsync() {
  return new Promise((resolve) => {
    if (!Android.refreshStart) { resolve(JSON.parse(Android.refreshSubscription())); return; } // демо-мост
    Android.refreshStart();
    const t0 = Date.now();
    const timer = setInterval(() => {
      let r = '';
      try { r = Android.refreshPoll(); } catch (e) { r = JSON.stringify({ ok: false, error: String(e) }); }
      if (r) { clearInterval(timer); resolve(JSON.parse(r)); }
      else if (Date.now() - t0 > 90000) { clearInterval(timer); resolve({ ok: false, error: 'timeout' }); }
    }, 400);
  });
}

async function saveAndCheckSubscription() {
  const v = els.subInput.value.trim();
  if (!v) { toast(t('sub_empty')); return; }
  Android.setSubscription(v);
  els.subResult.hidden = false;
  els.subResult.classList.remove('ok');
  els.subResult.textContent = t('sub_checking');
  els.saveSubBtn.disabled = true;
  let res;
  try { res = await refreshAsync(); } catch (e) { res = { ok: false, error: String(e) }; }
  els.saveSubBtn.disabled = false;
  if (res.ok && res.count > 0) {
    const best = res.servers && res.servers[0];
    const bestStr = best ? `${best.flag || ''} ${best.name} ${t('ms', best.ms)}`.trim() : '';
    els.subResult.classList.add('ok');
    els.subResult.textContent = t('sub_result', res.count, bestStr);
    setTimeout(closeSubModal, 700);
    renderStatus(lastStatus || { state: 'idle' });
  } else {
    els.subResult.textContent = res.error ? `${t('sub_none')} (${res.error})` : t('sub_none');
  }
}

// ────────────────────────── обработчики ──────────────────────────

els.connectBtn.addEventListener('click', () => {
  const st = lastStatus && lastStatus.state;
  if (ACTIVE.includes(st)) {
    Android.disconnect();
  } else {
    if (!(Android.getSubscription() || '').trim()) { openSubModal(true); return; }
    Android.connect();
  }
});

els.killSwitch.addEventListener('click', () => {
  const cur = Android.getKillSwitch();
  const next = !cur;
  Android.setKillSwitch(next);
  els.killSwitch.setAttribute('aria-pressed', next ? 'true' : 'false');
  toast(next ? t('ks_toast_on') : t('ks_toast_off'));
});

els.saveSubBtn.addEventListener('click', saveAndCheckSubscription);
els.subBtn.addEventListener('click', () => openSubModal(false));
els.subCloseBtn.addEventListener('click', closeSubModal);

els.langBtn.addEventListener('click', () => {
  lang = lang === 'ru' ? 'en' : 'ru';
  Android.setLang(lang);
  applyLang();
});

function applyLang() {
  document.documentElement.lang = lang;
  els.langBtn.textContent = lang.toUpperCase();
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    const v = I18N[lang][key];
    if (typeof v === 'string') el.textContent = v;
  });
  // перерисовать динамику
  renderStatus(lastStatus || { state: 'idle' });
}

// ────────────────────────── старт ──────────────────────────

async function init() {
  lang = Android.getLang() === 'en' ? 'en' : 'ru';
  if (!window.Android) {
    els.demoBtn.hidden = false;
    els.demoBtn.textContent = t('demo_on');
    els.demoBtn.addEventListener('click', () => Android.connect());
  }
  applyLang();
  els.version.textContent = 'v' + (Android.getAppVersion() || '1.1.0');
  const bat = Android.batteryLevel();
  els.battery.textContent = bat >= 0 ? `🔋 ${bat}% ·` : '';

  await loadWorld();
  resizeCanvas();
  addEventListener('resize', resizeCanvas);
  requestAnimationFrame(drawPlanet);
  startPolling();

  // подписка при первом входе: пусто — открываем модалку без закрытия
  if (!(Android.getSubscription() || '').trim()) {
    openSubModal(true);
  }
}

init();
