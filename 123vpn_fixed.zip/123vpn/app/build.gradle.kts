plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "space.jarenev.vpn123"
    compileSdk = 35

    defaultConfig {
        applicationId = "space.jarenev.vpn123"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.1.2"

        // Ядра xray+sing-box занимают ~115 МБ на каждую архитектуру, поэтому в один
        // APK кладём только arm64-v8a (практически все телефоны). Для эмулятора x86_64
        // или старых 32-битных устройств добавьте "x86_64" / "armeabi-v7a" сюда.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            // Временная подпись debug-ключом, чтобы `assembleRelease` собирался
            // сразу, без своего keystore. Для публикации в Play замените на свой.
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        // Обязательно: нативные библиотеки (включая бинарники xray/sing-box,
        // замаскированные под *.so) распаковываются в nativeLibraryDir,
        // откуда их можно запускать через exec().
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
}
