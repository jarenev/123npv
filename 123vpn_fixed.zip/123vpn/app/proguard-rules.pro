# Правил R8 почти не нужно: JNI-методы грузятся по имени.
-keep class space.jarenev.vpn123.Vpn123Jni { *; }
-keepattributes JavascriptInterface
-keep class space.jarenev.vpn123.Bridge { *; }
