# Изменения

## Подключение / ядра
- xray 26.x: `allowInsecure` удалён → ноды с insecure-TLS выбирают sing-box; добавлены `pcs`/`vcn`.
- Домен сервера резолвится приложением и закрепляется IP в конфиге (`pin.rs`); у Go-ядер на Android нет DNS.
- Пинг/монитор: UDP-протоколы (hysteria, hysteria2, tuic, wireguard) не проверяются TCP.
- sing-box: hysteria v1 получает лимиты по умолчанию, reality — uTLS chrome. Naive исключён (нужна libcronet).
- xray: vless `encryption`, xhttp `mode`/`extra`, wireguard `reserved`/`psk`.

## Парсер подписок
- Нет дублей и обрезанных имён нод; несколько ссылок в одной строке по-прежнему поддерживаются.
- ss-2022 (`method:password` без base64) и `%3D` в base64-userinfo.
- vmess tcp+http-обфускация.

## Супервизор (Rust)
- Состояние `fetching` выставляется синхронно (гонка со Kotlin).
- Обнаружение упавшего процесса ядра за ~2 с, перемер пингов при failover, сброс счётчика после стабильной сессии.
- `RUN` освобождается после ошибки до подъёма туннеля; логи обнуляются на старте.

## Android / UI
- «null» в ошибках (`optString` на JSON null), `AtomicBoolean` в JSON, краш FGS при повторном START.
- Ожидание запуска 150 с; watchdog после подъёма туннеля (работает Kill Switch).
- Асинхронная проверка подписки; многострочное поле подписки; данные планеты через `world.js`.
- В APK только `arm64-v8a` (`ndk.abiFilters` в app/build.gradle.kts).

## Тесты
`cargo test --workspace --exclude vpn123-desktop` (+ `VPN123_TEST_XRAY=/путь/к/xray` включает интеграционный тест супервизора).
